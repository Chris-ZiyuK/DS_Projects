#CS 4 - Correlation
#In this code session, we will both characterize datasets and 
#try to understand some of the key lessons from the lecture with simulations
#As (from now on) per usual: First the skills (S) to do the assignments, then the W tier stuff


import numpy as np # load numpy so we can access the numpy data import functions
data = np.genfromtxt('determinedIncome.csv',delimiter=',') # load the data file, assign it to a data structure called "data", and spell out that the delimiter is a comma
from scipy import stats #If you don't use Anaconda, you have to pip install scipy first. Anaconda takes care of all of this plumbing for you
import matplotlib.pyplot as plt


#%% 1) Classical Pearson correlation 
var1 = 2 #Which is our first variable
var2 = 3 #2nd variable to relate it to
r = np.corrcoef(data[:,var1],data[:,var2]) #Linear correlation between first and second column
#This produces the correlation matrix as introduced in the lecture
#So entry 1,1 represents the correlation between the first variable and itself, has to be 1
#Entry 2,2 represents the correlation between the 2nd variable and itself, has to be 1
#The big advantage of using corrcoef to produce correlations is that you don't have to o a
#nested for loop if you want to calculate the correlations between all possible combinations of
#variables. Corrcoef produces the "fully crossed" correlation matrix
#You can ask for a correlation between an entire matrix - all entries on the diagonal have to be 1
#The off-diagonal entries represent the bivariate linear (Pearson) correlation between two variables
fullCorrelationMatrix = np.corrcoef(data.T) #Full matrix. 
#Due to how corrcoef works, we need to transpose data first to get what we want
#If we don't transpose, Python will correlate the people (row-wise). In other words, we will get
#a gigantic correlation matrix (1500x1500) out, which quantifies how similar the *people* are to each
#other, on the basis of these 4 features (highest correlation = most similar). So that is how you
#could find your soul-mate, if you had data on their preferences for movies, music, etc. - someone
#who likes and dislikes exactly what you like. But Python doesn't know which one you want, correlating
#variables across people, or correlating people across variables, so you have to tell it. 

#We note that there is no meaningful correlation between IQ and hours worked. This is plausible.
#Some people work harder, and others work smarter. Some do both. 
#But - and feel free to explore this, there is a correlation between other variables, e.g.
#Hours worked and compensation, although it won't be 1, as other factors than just merely the hours
#put in affect compensation, e.g. soft skills. 
#Suggestion for exploration: Try different bivariate for yourself and see what you can discover. 
#There are 6 unique bivariate relationships you can characterize (that not with itself - or 1)
#For instance, the correlation between years of formal education and income is high. This makes sense.
#The power of this function is that it will calculate *all* pairwise correlations in a huge matrix
#for you at once. With one line. No nested loops needed. This will be important later when we do
#machine learning. 

#The visual representation of a bivariate correlation is a scatter plot.
#In analogy to the histogram being the univariate visualization.

# Visualize (Make scatterplot):
plt.plot(data[:,var1],data[:,var2],'o') #Make a scatter plot with circles as markers
plt.xlabel('IQ') #Suitable x-axis label
plt.ylabel('Hours worked') #Suitable y-axis label
plt.title('r = {:.3f}'.format(r[0,1])) #Title: Here, we ask for 3 significant digits, 
#f=floating point of the off-diagonal - entry 1 / 2. 
#Note: This is the off-diagonal of the bivariate correlation matrix, not the variables. 
#So this is ok. 
#Visual inspection suggests this scatter plot looks largely plausible and corresponds 
#to the correlation - very blobby
#What of the horizontal lines - why are there horizontal bands? 
#Hours are measured in integers (mostly single sigits actually)
#If we had used hours worked as our predictor (x-axis), we would have vertical bands
#So all of the bands we see is owed to the granularity of the data. Only income is a float. 
#It would be better if we had years of education in months, or hours worked in minutes, but we don't


#%% 2) Spearman's rank correlation
#Now do the same with Spearmans rank correlation rho
rho = stats.spearmanr(data[:,var1],data[:,var2]) #Rho is relatively advanced, 
#so that is in "stats" in scipy. Pearson's r was in numpy
print(rho.correlation) #The rho object contains other values as well, in addition to the index
rhoValue = rho.correlation #This is another example of a scipy object, 
#so we have to get the correlation out explicitly

#Rho and r seem to be very close. 
#Is this surprising? Remember: Rho is the rank correlation, 
#where the data is first transformed to ranks
#This should not be surprising, as we would not expect serious non-linearities here. 
#But the data will not always be this nice.
#If you have seriously nonlinear or non-normally distributed data, 
#then you can expect serious deviations

#%% 3) On that note, speaking of ill-behaved data: 
#Anscombe's quartet nice illustrates that, and the importance of doing EDA:

#Usually, we don't hardcode input the actual data values into the code, we read in a datafile
#But here, we make an exception, because these are the classic - Anscombe's quartet values from 1971    
x = [10, 8, 13, 9, 11, 14, 6, 4, 12, 7, 5]
y1 = [8.04, 6.95, 7.58, 8.81, 8.33, 9.96, 7.24, 4.26, 10.84, 4.82, 5.68]
y2 = [9.14, 8.14, 8.74, 8.77, 9.26, 8.10, 6.13, 3.10, 9.13, 7.26, 4.74]
y3 = [7.46, 6.77, 12.74, 7.11, 7.81, 8.84, 6.08, 5.39, 8.15, 6.42, 5.73]
x4 = [8, 8, 8, 8, 8, 8, 8, 19, 8, 8, 8]
y4 = [6.58, 5.76, 7.71, 8.84, 8.47, 7.04, 5.25, 12.50, 5.56, 7.91, 6.89]

#After inputting the values, we arrange them into a labeled data structure "data"
data = {
    '1': (x, y1),
    '2': (x, y2),
    '3': (x, y3),
    '4': (x4, y4)
}

#This is also the first time in this class that we introduce a multi-panel figure
fig, axs = plt.subplots(2, 2, sharex=True, sharey=True, figsize=(6, 6),
                        gridspec_kw={'wspace': 0.04, 'hspace': 0.04})

#First 2 numbers: How many rows and columns of panels
#sharex and sharey simply means that redundant axes (e.g. the top x row, or the 2nd y column)
#don't get their own label, because it would crowd the figure with redundant axis labels
#Obviously, you can only do this if they have a common axis. But these do. 
#Figsize just makes the figure a certain size (we didn't strictly need this), but
#this ensure a square figure. If you want a landspace or portrait format, just change
#the aspect ratio between the first number (width) and the 2nd number (height)
#If you have a grid of panels, you will want to specify how much whitespace is there between 
#panels - for instance, if you have non-shared axes, you'll want some space to label them. 
#But that eats into the "screen real estate" that the actual panels can take up. 
#It's a tradeoff. And you dial this up independently in x (width) and y (height)
#If you have a figure with many panels, you might need the space for the actual panels, 
#not whitespace between them. But some people like the sparse aesthetic.
#In general, you can take control of every aspect of a figures appearance. We will
#gradually build this up throughout the course. The more you can do in Python, the 
#less you'll need to do in Photoshop or Illustrator, for publication quality figures.
#Imagine if you made a really nice figure by post-production editing in Illustrator
#and then you want to change something about the underlying calculation. 
#Oh no - you'll have to do it all again - better to do everything in Python. 
#But to do that, you have to take full control of the figure appearance.  

axs[0, 0].set(xlim=(0, 20), ylim=(2, 14))
axs[0, 0].set(xticks=(0, 10, 20), yticks=(4, 8, 12))


for ax, (label, (x, y)) in zip(axs.flat, data.items()):
    ax.text(0.1, 0.9, label, fontsize=20, transform=ax.transAxes, va='top')
    ax.tick_params(direction='in', top=True, right=True)
    ax.plot(x, y, 'o')

 #  add legend to each plot to indicate the descriptive statistics
 #  Make sure to do this in the loop, (for each of the 4 plots), so keep the indent 
    descStats = (f'$\\mu$ = {np.mean(y):.2f}\n'
            f'$\\sigma$ = {np.std(y):.2f}\n'
            f'$r$ = {np.corrcoef(x, y)[0][1]:.2f}')
    bbox = dict(boxstyle='round', fc='blanchedalmond', ec='orange', alpha=0.5)
    ax.text(0.95, 0.07, descStats, fontsize=9, bbox=bbox,
            transform=ax.transAxes, horizontalalignment='right')
    
plt.show()

#Here, the issue is not clear yet. All 4 distributions/situations have the same summary statistics
#but so what? Fair enough. But very soon, this will matter - for instance, we will use the correlation
#to make predictions and we we will use mean and SD to compare whether two samples are drawn from
#the same underlying distribution or not. If the summary statistics are not a good representation
#of the underlying distribution, we will quite literally draw the wrong conclusion. 
#Worse: No one will tell us. Python won't tell us. Statistics won't tell us, nothing will tell us.
#The only way to avoid this is to do EDA first. So - technically it is optional - you can compute
#the summary statistics without looking at the raw data first, but I really don't recommend that. 
#Because if something is off, e.g. panel 2: non-linear relationship, 3: Outlier in the y-direction,
#4: Outlier in the x-direction, we might have a problem without even knowing it. 
#Do you really want to gamble on everything being ok, magically?
#I *always* first do EDA. Always. Just to make sure that we are not going down a path that is
#treacherous. Processed data can hide many problems that easier to see in raw form. 
#Don't just assume everything will be normal and linear. That's just what professors do in classes
#to make the teaching easier. But in real life, that is not something to count on. 


#%% W1: A linear algebra view on correlation
# This is going to be a big deal when we get to machine learning. Many algorithms in ML
# are based on this insight. 
# So far, we have only treated correlation from a purely statistical perspective.
# Both in the lecture (we actually derived it, using only statistical concepts like covariance)
# And so far, in this session.
# But - as you now know (and I mentioned in the lecture), 
# the correlation between 2 variables can also be 
# interpreted as a relationship between elements of vectors
# Or rather, the correlation between two variables corresponds to their relative orientation 
# to each other. In other words the cosine of the angle between them. 
# In other words, the dot product is going to make an appearance.

# Let's illustrate this with some sata:
mu = 0 #Mean
sigma = 1 #SD
n = 100 #Sample size - the higher the sample size, the slower the code, 
#but the more consistent the outcomes between multiple runs of the code segment.
scaleFactor = 1 #This dials the magnitude of the noise up and down
#We use sata that has zero mean and SD = 1, so this is drawing from a standard normal distribution
X = np.random.normal(mu,sigma,n) #Because we ask for numbers from a normal distribution. 
#100 of such numbers, but no hard-coding of the sample size.
Y1 = np.random.normal(mu,sigma,n) #Drawing Y1 also from the same distribution - same mean, SD, 
#same sample size. But we draw randomly and independently. So the expected correlation between these
#two variables/vectors is 0. It won't be exactly 0 because we have a finite sample size
#If the sample size was infinite, it would be exactly 0
#Computing it in 2 steps: 
temp = np.corrcoef(X,Y1) #Correlation matrix between X and Y
r = temp[0,1] #Linear correlation between off-diagonal entry of the correlation matrix
#To get the Pearson correlation r out of the correlation matrix
print(r)
#Suggestion for exploration: Try running this a couple of times - r will come out to close to 0
#each time, but the actual value will vary, because we draw numbers at random each time. 
#X and Y1 are statistically independent. 

#Now what if - instead - we don't just draw the Ys randomly from a standard normal distribution, 
#what if we did that, but also added it to the X values we already got

Y2 = X + (scaleFactor * np.random.normal(mu,sigma,n)) #We take the random X values, and add more normally 
#distributed noise to it. Now, X and Y2 are no longer statistically independent. They
#are statistically dependent. 

#If the scaleFactor is 0, then Y2 = X, correlation between them would be 1, 
#if Y = np.random.normal only, the correlation would be 0.
#Here, we titrate in some X and some np.random.normal. 
#So we would expect some correlation, but not 0 or 1. 
#In other words, we mix sata in here, so you learn how to create sata with a certain correlation 
#level. To build models. This will be important later. Synthetized.


#Computation and plotting:
temp = np.corrcoef(X,Y2) #Correlation matrix between X and Y
r = temp[0,1] #Linear correlation between off-diagonal entry of the correlation matrix
plt.plot(X,Y2,'o',markersize=5) #Plotting it. We vary the size of the markers with the markersize property (attribute)
plt.title('r = {:.3f}'.format(r))

#Now you know how to create synthetic data with specific levels of intercorrelation 
#between the variables. That will come in handy when you're calibrating a ML model or sth like that

#%%

# Now for the linear algebra perspective on correlation
# As usual, linear algebra provides an alternative/complementary view that is completely
# consistent with the classical/statistical view, but can provide enlightening to some.
# So far, we considered variables X and Y as two variables, with 100 entries (replicates)
# In this LA view, we are looking at the relationship between 2 (two)
# 100-dimensional vectors. For those, the correlation between them is given
# as their dot product. If they are unit vectors. 
# So lets' reduce them to unit vectors first. Then take the dot product.

xUnit = X/np.linalg.norm(X) # Convert x to its unit vector by dividing by the euclidian norm
yUnit = Y2/np.linalg.norm(Y2) # Convert y to its unit vector by dividing by the euclidian norm
rVec = np.dot(xUnit,yUnit) # Take the dot product
print(rVec)
print(abs(r-rVec)) # Close enough - within numerical precision

#We observe that both the statistical approach and the linear algebra approach yield the same result.


# Recall from the lecture that the dot product is the cosine of the angle between 
# the vectors times their respective unit vectors
# If the two vectors that represent the data point in exactly the same direction,
# the angle between them will be 0, so cos(0) will be 1, times the unit vectors will be 1
# So the correlation will be 1, if they point in the same direction. 
# If the two vectors that represent the data are completely orthogonal 
# (offset by 90 degrees, perpendicular in some space), cos(90) will be 0, 
# so the dot product will be 0, so they are statistically independent. 
# This is a big deal because almost all of machine learning is based on this insight. 
# Where do vectors point and what is the relationship between them? 
# We can use the dot product to characterize this and interpret it as a correlation, fast. 
# This will become more clear why this is a big deal after we cover machine learning. 
# For now, just recognize that there is a deep link 
# between correlation and the dot product between vectors.

#%% W2 - Simulation: Aleatory calculations to understand correlation magnitude 
# (as in the lecture, where we did this with 2 and 3 gears because our screen size was limited)
# Aleatory = latin for "pertaining to the throwing of dice" (meaning depending on chance / random)
# As usual, we use gears for our calculations (calculus = gear)
    
# 1. Initialize parameters:
numReps = 1000 # Number of repeats of the random experiment (to determine the average correlation)
numGears = 100 # We are looping from 0 to 100 gears that we spin again 
#(as opposed to just look again) - the outcome is their sum in the first spin vs. 2nd spin
m = 10 # Number of mutually exclusive events (slots) per gear
empVsExp = np.empty([numGears+1,4]) # Initialize container to store the resulting correlations
empVsExp[:] = np.NaN # Convert to NaN
counter = 0 # Initialize counter
  
# 2. Run simulation:  
for c in range(numGears+1): # Loop through each situation (from 0 to 100) 
#to represent more and more gears we spin again, as we go through the loop
    
    # Simulate aleatory observations:
    ratio = c/numGears # relative to total - proportion of gears in 2nd observation 
    #that change (are spun again)
    observation1 = np.random.randint(m+1,size=(numGears,numReps)) # first observation; 
    #m slots (mutually exclusive events) per gear
    observation2 = np.copy(observation1) # second observation - same as first
    observation2[0:c,:] = np.random.randint(m+1,size=(c,numReps)) # randomly change c gears 
    #in second observation
    
    # Compute Pearson r for each repeat of the random experiment:
    temp = np.empty([numReps,1]) # initialize empty container to store each r value
    temp[:] = np.NaN # convert to NaN
    for ii in range(numReps): # Loop through each experimental repeat
        r = np.corrcoef(observation1[:,ii],observation2[:,ii]) # compute the Pearson correlation r
        temp[ii] = r[0,1] # store Pearson's correlation coefficient in temp variable
    
    # Compute Spearman rho for each repeat of the random experiment:
    temp2 = np.empty([numReps,1]) # initialize empty container to store each rho value
    temp2[:] = np.NaN # convert to NaN
    for ii in range(numReps): # Loop through each experimental repeat 1 to 1000
        r = stats.spearmanr(observation1[:,ii],observation2[:,ii]) # Compute Spearman rho per run
        temp2[ii] = r[0] # store coefficient in temp2 variable
    
    # Store data:
    empVsExp[counter,0] = ratio
    empVsExp[counter,1] = np.mean(temp) # take mean r for all experimental repeats
    empVsExp[counter,2] = 1 - ratio
    empVsExp[counter,3] = np.mean(temp2) # take mean rho for all experimental repeats
    counter = counter + 1 # Increment the counter
    
    # Plot data:
    plt.plot(sum(observation1),sum(observation2),'o',markersize=3)
    plt.title('Ratio = {:.2f}'.format(empVsExp[c,0]) + ', r = {:.3f}'.format(empVsExp[c,1]) + ', rho = {:.3f}'.format(empVsExp[c,3]))
    plt.xlim(300,700)
    plt.ylim(300,700)
    plt.pause(.01) # pause (in seconds) between iterations

#What this is showed us is that what I was asserting in the lecture is actually true. 
#All gears are just read off again (for the 2 measurements), then r = 1
#All gears are re-spun (to produce the 2 measurements), then r = 0
#Otherwise, the magnitude of r represents the proportion of gears that is *not* respun.     
#The upshot of this simulation is that the higher the fraction (or ratio) of the gears
#that is spun again (as opposed to just looked at again), the lower the correlation between
#the random variables that represent the first vs. the 2nd outcome is.     
#Another upshot is that for something like this - where both distributions are so well behaved
#r will basically be very close to rho. We will later see situations where this is not the case.