# CS 8: Canonical data analysis cascade.  

# We will continue this script to actually do the significance tests 
# For today, we'll focus on creating the basic data analysis cascade for hypothesis testing
# We'll build on this next time.


#%% In this script, we will analyze real data from a published article. 
# Well, a subset of it. The point is specifically to illustrate hypothesis testing 
# in Python, implementing the Canonical Data Analysis cascade. 
# This is toy example, so the full power of this won't be apparent until you do the capstone project
# But once you do, you will understand. There, the loading/cleaning/formatting will
# pay dividends to answer the specific questions. 
# The advantage of this is that you'll be free of the limitations of canned
# packages like Excel or SPSS. Once you loaded the data into whatever format
# you use in Python (usually an array or a dateframe), you "own" it. You can 
# do whatever you want. This represents "computational freedom". 
# "Computational empowerment."
# With data. Very powerful. 
# Specifically, we will test the hypothesis that Matrix I was the best of
# the Matrix movies (it's a trilogy). 
                    
# Before we do that in code, lets revisit the logic of the null hypothesis significance
# testing framework at least once (just once). 
# It is a bit arcane. It made sense to Fisher.
# Today will be light on software engineering, but heavy on logic. 
# To make sure that this makes sense.                  
                    
# 1) Start with a hypothesis (something about the world you would wish to
# know the truth status of (whether it is true or not). 
# The research participants ("participants", from now on)
# are the unit of analysis that gives you the data here, but be prepared that
# in the future, unit of analysis could be city or country or whatever else. 
# By convention, the "replicates" or "units of analysis" that give us the data are in the rows.
# The features/variables that they give us on (the movies) are in columns, by convention. 
# Here, I'm giving you the data in this format, but that's because I already did the preprocessing.
# In real life, someone might hand you a very long text file that you have to parse and arrange in 
# this way. Important point of note: The rows are fully indepedendent - the participants in the study
# completed the study on their own, they did not communicate and they were recruited and enrolled
# randomly. The columns are not independent - the data comes from the same people. All participants
# rate the same movies (if they saw them). This will be very important later. Right here, what the
# numbers represent matters. Python does not know this. What the right thing to do is depends on 
# how the data were recorded (independently / dependently, etc.) - that's not in the numbers. 
# As a reminder: Theoretical hypothesis (for instance): Matrix I is the best movie in the trilogy.
# Highest rated by people who saw it = A testable version ("operationalized") 
# of the theoretical hypothesis. Needs to be something quantifiable. 
# That might seem like a minor point, but you will need to break all of your theoretical questions
# down into testable ones (this is called "operationalization"). 

# 2) State a null hypothesis and assume that it is 100% true (that there is
# no difference in the conditions of 1), e.g. here Matrix I rated the same
# as Matrix II and III). This is essential to NHST. Seems counterintuitive. 
# If you already suspect that Matrix I is the best of the movies, why would you assume
# that you're wrong? [Explicit and strong formulation of the advocatus diaboli]
# This is about the burden of proof and guards against confirmation bias (and other biases).
# Most social organizations do not do this. They just run with their confirmation bias to jump to
# conclusions. The whole point of the scientific method is to institutionalize falsification. 
# Shifting the burden of proof - we assume that there is no difference in the quality of the movies
# unless the data forces us to give up that assumption - because it has become implausible in light
# of the data. 

# 3) This is - on the face of it - an odd thing to do, because naively you
# would think that scientists look for probability (Hypothesis | Data). 
# This would be nice to have. 
# But as you saw in the lecture on hypothesis testing, that is unknowable. 
# Which is why we do the study in the first place.
# What is calculable: Probability (Data | NULL hypothesis)
# We can assess the probability of the data given the null hypothesis is true
# In other words, we do this because we can calculate this probability. 
# The first thing would be nice to have, but is unattainable. So we do this, which can be done. 

# 4) To calculate this probability, we represent the entire sample (at least one variable of it)
# by a statistic like the sample mean, then we transform the sample mean 
# into a test statistic that has a known null distribution.
# The null distribution is the distribution of the test statistic assuming the null hypothesis
# is true. 
# You can find this null distribution at the back of every statistics textbook, 
# e.g. z, t, F, Chi-squared, etc.

# 5) We then have to obtain the p-value by considering the area under the null distribution curve 
# of test statistic in the tail (or both tails, if it is a 2-tailed test) 
# This is the p value, in other words the probability of the result (or a more extreme one)
# given chance alone (ie if the null hypothesis is true).

# 6) We compare this p value to the significance level alpha (typically 5% or 1%)
# The significance level is chosen to reflect a level of chance that is absurdly implausible. 
# Something like one would only expect this outcome 1 in 1000 times or 1 in a million times by
# chance. However, for the sake of convenience (see Fisher), science settles for a standard of 
# "absurdly implausible" of 1 in 20. Basically - how surprised are you to see this result. 
# Mildly surprised - 1 in 20? 

# 7) Decision point (Choice - not proof!)
# a) If the p-value is smaller than alpha, we decide to reject our assumption that the 
# null hypothesis is true. We acknowledge that we were wrong. Why? Because assuming the null
# hypothesis, we obtained a result that is implausible (unlikely). In other words, the scientific 
# method is a reductio ad absurdum. Sherlock Holmes uses this a lot. Making certain assumptions, you
# arrive at implausible conclusions. If the reasoning is sound, the conclusion has to be to drop
# the assumption that led you to the contradiction. 
# b) If the p-value is not smaller than alpha, we don't do anything because we already
# assumed that the null hypothesis is fully true. So nothing changes.                      
                    
# Paraphrased logic, in english: We explicitly acknowledge any outcome could be due to
# chance. [This is a chance acknowledgment.]. Every scientific investigation starts by an 
# acknowledgment. And that acknowledgment is that our results could be entirely due to chance 
# alone. And we state is as the null hypothesis. The only question is how likely that is 
# by chance. If it is implausibly unlikely, we reject the assumption that it was just due to
# chance. And either the null hypothesis is true or not, so if we reject that it
# is plausible, it probably means that our treatment did have an effect. 
# Implementation of what implausibly unlikely means: alpha level.     

# This logic is somewhat counterintutive, as you basically use the probability of being 
# wrong about being wrong.
# To make your conclusions. But it is the logic that is used in 90+% of all science, today.

# This makes it impossible to say that you proved OR disproved something with data. 
# Even if you reject the null hypothesis, you did not disprove it. You falsified it.
# But only with a certain probability. You could be wrong. 
# Even rejecting it or "failing" (not a bad thing) to the H0 is not a proof or disproof. 
# All of this is entirely probabilistic. 
# This is not semantics. If you prove something, you cannot be wrong. A proof yields certainty. 
# You can be woefully wrong. And will be blindsided if you don't understand this. 
# You could lose all of your money. 
# This is more like statistical decision theory. And decisions can be wrong. 
# I can't emphasize this enough. (I guess)             
                    
#%% Before we (finally) do the stats, let's talk about the interplay of 
# the psychology and statistics of rating movies of a movie trilogy:
    
# Hypothesis 1: First is best. Because that's usually true for trilogies
# (with the exception of Star Wars). That's probably true just because of
# regression to the mean (hit movie is made somewhat by chance, 2nd one = a cash grab, 
# but they can't recapture the "lightning in a bottle" / zeitgeist of the original).
# Also expectations. If the first one is great, it's hard to beat expectations. 
# So the 2nd movie in a trilogy might be experienced as worse than it actually is.

# Hypothesis 2: Ratings for later movies in a trilogy will be better than earlier ones.
# Production quality improves over time (special effects). Also, if the first movie was a hit
# and encouraged to make a 2nd one, they usually have more money for the 2nd one. 
# Also, only fans might watch all of them.
# People who didn't like the 1st one might drop out and never watch the
# other ones, so the RATINGS might be higher. [Survivorship bias, because people who
# didn't like the first one won't watch the 2nd one, only fans will. More on this later]
# If this is true, it threatens our operationalization of movie quality as user ratings. Focusing 
# on ratings could yield misleading results. The only solution if this is the case would be to do
# an experiment and intentionally expose people to certain movies (regardless of what they normally)
# would prefer to watch.

# Make sure that you actually have 2 plausible outcomes before doing the study. 
# If the outcome is a foregone conclusion, it's not science. 
# If you are scientist, you have to be open to any possible outcome.
# Tricky, as people who go into a certain field usually have a reason to do so.
# Understandable from a psychological perspective, that people go into a certain field with
# an agenda, but deadly for science. 
# Try to keep an open mind. If you want to do science with integrity. 
# If you already know the outcomes of your research before you do the research, it is not research. 
# It could be many things, e.g. ideology, activism, a statement of belief, etc. but not science. 
# Science is about finding the answers to questions where the answer is not already known. 

# Null hypothesis (as always): There is no difference in ratings. 

# Let's implement the canonical data analysis cascade

#%% 0 Initialization ("Birth")

# Here, we set all of the constants we will reuse throughout the code. 
# A good example for a constant that we will troughout the code is the alpha level. 
# The reason you want to set *all* of your constant right here is maintainability. If you do 30
# statistical tests in one analysis (the average value for your typical project), you will use alpha
# 30 times. Imagine if you set it in various places, want to change it, then forget to update one
# of them. That would be a problem, no? [An estimated 30% of research papers have flawed conclusions
# just from this kind of coding issue. I'll upload the paper to the W tier materials.]
# You will save yourself a *lot* of headaches, if you declare all of the things you will use more
# than once right here, up front. In a block. So you can see all constants in the code up front 
# and change them at will. 
# Also all "flags" that we will use throughout the code. 
# A flag in the analysis of code with data is a variable that represents a choice of the analyst 
# as to how to analyze the data. For instance, today we will make at least 2 choices:
# 1) how to "prune" the data, 2) Whether to use parametric or nonparametric tests. 
# But this could be anything, what baseline to use, whether to smooth the data, whether to 
# normalize, how to normalize (e.g. by z-scoring), etc. 
# Flags are usually used in an if statement later. 
# This will make for more maintainable code, as usual. For instance, if you set flags throughout
# the code, you will quickly forget about them, and not be able to update them, should sth change
# Keep all of them in one place, up top. [In other words, this makes dependencies explicit]
# A statement (a paragraph of comments) as to what the code is doing, 
# what it produces (files, plots) and what it assumes (e.g. what data files exist and where they are)
# is not a mistake either. 

# a) "Predispositions:"
startColumn = 177 #This is the column that contains data from matrix I
# matrix II is column 178 and matrix III is column 179
numMovies = 3 #Data from how many movies (it's a trilogy)
alpha = 0.05 #Fisher would be so happy. This is a good example of a constant
pruningMode = 1 # This is a good example of a "flag". This flag is a variable that determines how 
#we will handle nans. It's important to be mindful of this, as it will determine what analyses 
#are even possible later on. It's not as simple as "dropping" them. It will also determine what the
#data even means. 
#1 = element-wise removal, 2 = row-wise removal, 3 = naive imputation, 4 = "smart imputation"
#Removal = some kind of way to eliminate missing data (values) from the dataset.
#Imputation = Some kind of guess as to what the missing number might have been. This is obviously 
#extremely sketchy to do in science because this number did not come from measurement. Also, what
#should the number be? We will have to handle missing data at scale here, because most people did not
#see most of the movies. Pretty much all of the functions we'll be using presume that there are no
#missing values. Even taking the mean of a variable that contains a single nan, usually just returns
#a nan, if it even runs (and doesn't just throw an error). But I have a question for you, up front. 
#Sometimes, data is missing randomly and rarely. Here - again - what does missing data mean? 
#A user did not see a particular movie. In other words, it might reflect either a choice by the user
#not to see it, or it might reflect that they were unaware of it. Maybe they were unaware of it 
#because it is bad. Maybe they didn't want to see it because they knew they wouldn't like it. 
#If that is true - and something like this is almost certainly true if you have ever watched movies -
#would it be a good idea to impute the missing value as the mean of the ratings of the people who 
#did see the movie? It would not be. Because the people who rated it on some base level decided to
#see it. Those are fundamentally different populations. So what to impute then? A 0 as an implied
#rating for "chose not to see it"? That seems a bit extreme. A blend of 0 and the mean? Or even if 
#you do the mean - what mean? The row - the average rating of that user (if they are particularly 
#cheerful or harsh, that might matter), the column mean (of everyone else who did see the movie), 
#a blend between row and column mean? In other words, imputation is a very dark art. In science, it
#is frowned upon, for this reason. But it is very common in engineering. In defense of engineering, 
#they usually try to validate their choices somehow. What I mean by "smart imputation" is to build a
#prediction model as to what the missing value should be, from the entire rest of the dataset. 
#For now, I just want to note that right here - how we will decide how to handle missing data with
#this flag sets up the entire rest of the analysis.    
 

# We should set another flag for parametric vs. nonparametric statistics, 
# then use it in the code later
# But I'll leave that as an exercise. For now, let's just do both. 

# A third flag could pertain to whether you want to use numpy arrays or pandas dataframes 
# We will do this next time.

# b Load/import - *all* of the libraries/packages we will be using:
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

#Why use numpy, and not pandas? [next time, we will use pandas]:
#Students keep saying: I already learned pandas in DS4E. It seems awesome. Why do we use numpy? 
#1) Numpy is much, much faster. Orders of magnitude. This won't matter today, or probably for 
#anything you have ever done, but if you have a huge dataset, it could cut execution time 
#from months to hours. Simply by switching to numpy. 
#2) Yes, pandas is "awesome", meaning it does a lot of things for you that are cumbersome to do 
#by hand. However, in order to do so, it makes a lot of assumptions that you 
#might not even be aware of that it is making. For instance, a lot of students simply call "dropna"
# with drops nans from a dataframe. They also usually follow that by
#saying "lol". But there are many ways to remove nans, all of which have drastic implications 
#for the analysis. It's almost like using a function vs. doing some computation
#by hand. Functions are great, but if you want to understand, 
#it is better to do it by hand, "beforehand". To know what the options even are, or why they matter.
#3) You just said that you already know how to use pandas. 
#Is it a criminal offense to learn something new? Is it specifically prohibited by the 
#constitution of the United States? No, it is not. So why not learn something? 
#That's the point of a class. You are paying for this. 
#4) It is generally a good idea in coding to have multiple ways of doing the same thing.
#Having more available tools is rarely a mistake. Think of this as a toolkit.     
#5) Pandas is best for tabular data (think spreadsheets). 
#If the data is anything else (time series, vectors, images, sounds), 
#things will be very hard in pandas, but very straightforward in numpy. 

#For these reasons, if you want to be a data scientist, I strongly encourage you to also learn 
#numpy. Doesn't mean to not learn pandas. And we'll start mixing it in. But you told me that you
#already know pandas. So...

#%% 1 Loader ("Transducer"): 
# Taking the inputs from their native form (whatever they might be) and putting it into 
# something Python can use: an array

# There are 2 common standards: comma-separated value (csv) files and SQL databases. We'll do both
# in this class, but don't be surprised if - on the job - you have to parse a text file first. 
# If this was anything more complicated, it would not be a bad idea to set the file path or file name
# as a variable up in "initialization". Here, we always use the same file 
data = np.genfromtxt('movieRatingsDeidentified.csv', delimiter = ',' , skip_header = 1)
# We want just the data, so skip the first row / header. No strings attached. 
dataMatrix = data[:,startColumn:startColumn+numMovies] # The matrix data, haha. 
#Should yield a n x 3 matrix
#Colon (:) in absence of any delimiters, simply means "all", here all rows, 
#because it is the first dimension
#The data comprises "star ratings" of these movies, which is a typical rating scale for movies.
#Rows: Participants, people who rated the movies, there are 3204 raters
#Columns: Movies, there are 209 movies

# Just this time:
# Decompose dataMatrix back into separate arrays, one for each movie:
# This seems backwards, as we just assembled the matrix data in this array, and it is.
# But it will be necessary for element-wise removal of nans, as you will see. 
    
M1 = dataMatrix[:,0] #Reach into the array and take out the ratings of the first movie
M2 = dataMatrix[:,1] #Dito, but mutatis mutandis for the 2nd one
M3 = dataMatrix[:,2] #Dito, but for the 3rd one

# They are all the same length because if the participant did not respond
# the element is represented with NaN.
# Why represent missing data with nans in the first place? 
# Because 1) Arrays can't have holes (for reasons of alignment of stacking, see a previous lab), 
# why not 0s? Because that would imply a 0 rating. 
# [Which by the way: Could be true. You anticipated that the movie was going to be so bad, 
# that it would correspond to a rating of 0 if you actually watched]
# If that is true, using 0s would be better. But without testing for that, be careful.
 


#%% 2 Preprocessing/Cleaning ("Thalamus") stage: We need to get rid of "bad" data. 
# Bad = unusable, sometimes known to be corrupt. 
# Here, we have to deal with missing data somehow. If we leave it in, we cannot do the rest of 
# the analysis. But how we deal with the missing data to a large extent determines the rest of the
# analysis. The stakes are high. 

# Importantly, "bad" does not mean "data I don't like because it shows I'm wrong". 
# That is one form of "p-hacking" (more on this in the lecture), and it is a form of cheating
# As this is science, and science is about finding truth, subverting that is a cardinal sin 
# in science. Putting the sin in science. Do not do it. There will be temptation to do so. 
# Sometimes even pressure. Do not do it. 
# This is not data we don't like the results of. 
# It's data that if it entered the analysis stream would ruin our analysis
# By p-hacking, you can *guarantee* that the data always supports your hypothesis. 
# But that defeats the point. Don't do it. Please. 

# For instance, if someone straight up tells you that they only gave joke ratings to troll you.
# To be clear: There are many ways to remove nans.
# One way is not necessarily bad or good or anything like that.
# Which way makes more sense depends on what you do, but there are tradeoffs.

# By visual inspection, the matrix of movie ratings contains numbers from 0
# to 4, representing "star ratings", and "nans". 
# What could the nans be? What do they mean?

# It could be people not doing the task. There are many ways to detect this.
# People who press buttons not in the instructions, people responding too
# fast, people responding too slow. 

# Why might "too slow" be a problem? In one study, we were interested in
# reaction time as a dependent variable. But once, a participant went to the
# restroom in the middle of the experiment and didn't come back for 30
# minutes. What would happen to the mean reaction time for the condition
# that the trial was in, in which this participant used the restroom. If we
# included this, it would be meaningless. As the mean is sensitive to outliers.
# The rest of the reactions are in milli-seconds. This is 4 orders of
# magnitude higher. Another example from neuroscience: Voltages of
# electrodes are usually in mV or microV (depending on eeg vs.
# microelectrode). What if for one trial there was voltage surge that hit
# the building - all measurements from that trial are invalid. You need to
# exclude that BEFORE looking at the results. All results will be thrown off
# by that.

# Given that these are movie ratings, it is not implausible that most of
# these nans represent missing data due to the rater not watching the
# movie in question. [That's a good thing - you don't want people to give ratings
# on movies they did not see.]
# The reason we have to deal with this is that once this data is in the
# analysis stream, it will make the rest of the interpretation hard. If
# there is a single nan in the data, we can't take the mean. 
# So "filtering" or removing of ill-formed data will mean "removal of
# missing data" in this case.
# But here is the catch: Remove them how?

# There are at least 3 ways to handle this, and depending on how we do this,
# it will set up the entire rest of the analysis (and what it means). 

# 1) Element-wise removal of nans: We remove nans from each column in the matrix
# representing one variable of the dataset, here ratings of one movie. 
# Where we find it. But we are starting with an equal n for each movie. 3204
# rows in all 3 arrays. Once we start removing data element-wise, due to
# the fact that there are an unequal number of nans for each movie, this
# will result in unequal n, which will make some analyses impossible. Some
# analyses presume equal n. It could also introduce bias. If we remove
# people who have not seen the latter ones, but that was a choice (their
# choice), we would inflate the ratings of the earlier movies artificially. 
# This is a form of survivorship bias (or experimental mortality, here).

# 2) Row-wise (participant-wise) removal of nans: If a participant has not
# seen even one of the movies, we remove all of the data from this
# participant. Good: We keep n the same. Bad: We will lose a lot of data.
# Probably most of the data. This usually looks suspicious, also: Loss of much
# statistical power. [More on this the lecture] 

# 3) Imputation: We replace the missing data with our guess of what the 
# rating would have been, if there had been a rating. 
# This is more commonly done in engineering than in science. 
# However, there are lots and lots of ways to impute.
# Sometimes, people replace the missing value with the mean. But which mean?
# The participant-wise mean (the average rating of this rater) 
# or the movie-wise mean (if most people like this movie, they probably did too)
# - or a blend of the two means? (participant-wise and row-wise) 
# But: We could take these means, but is that fair? Those raters potentially chose
# not to watch a given movie - they were not randomly assigned to watch the movies.
# This suggests that their rating would have been lower than those means (both participant and movie)
# But how much lower? 0? Probably too extreme. Maybe they just didn't get around to watching it yet.
# Or didn't know about it.
# What the best way of imputation is depends on the question. And how much computational power is
# available. Arguably, the best way to do imputation is to build a whole prediction model to impute
# each of the missing values.
# In business data science, there is often no way around it - for instance, spotify even with 
# 100 million users and a million songs, most ratings are missing (99.99%+). 
# So they have to do some sophisticated modeling
# to guess at what the missing ratings might be to do anything.
# But in academic science, data only comes from measurement, so imputation is frowned upon.

# In real life, pick the option that makes the most sense for what you are trying to do
# and then just do that. For teaching purposes, we'll do all of them, 
# just so you see how that would play out.

# Importantly, we'll do this step by step. In real life, you can use vectorized one-liners of 
# chained/nested logical operations to do this.

# 1) Element-wise:
if pruningMode == 1: #Here, we now use the flag we set in the initialization
#Just fyi: There are many doing this, for instance, we could also find the indices of the nans, then eliminate those from the array
#or we could create a new array that copies the elements, but only if they exist. 
   M1 = M1[np.isfinite(M1)] # only keep the finite elements (not infinity or NaN)
   M2 = M2[np.isfinite(M2)] # only keep the finite elements (not infinity or NaN)
   M3 = M3[np.isfinite(M3)] # only keep the finite elements (not infinity or NaN)
# Outcome: It worked, no more nans in the new arrays, but exactly as we suspected,
# n is unequal now, and we have concerns about the psychological interpretation of this, as we only have the
# ratings of die-hard fans who watched all 3 for the third one.
# Most casual watchers stopped after the 1st, or 2nd one. There is a lot of dropout
# Also, we can no longer use an array to represent all 3, because they don't align. 

# 2) Row wise: (and showing off isnan, as a different way of doing this)
elif pruningMode == 2:
    temp = np.array([np.isnan(M1),np.isnan(M2),np.isnan(M3)],dtype=bool) #Create a temporary array that represents where the nans are, in the 3 arrays
    temp2 = temp*1 # convert boolean to int, because either it is nan, or not (true or false), so we can compute - there are ways to use the booleans straight up, but this is easier
    temp3 = sum(temp2) # take sum of nans that represent missing values for each participant
    #We can get away with naming these variables "temp" here, because they are just waypoints, we don't need them for anything outside of this computation. We might even package this logic as a function later, if we want to reuse it
    missingData = np.where(temp3>0) # find the indices of participants with any missing data (who have at least 1 missing rating)
    #"where" is a very helpful function. It finds the indices of elements of an array that fulfill certain logical conditions
    #Now we can use this index to remove data row-wise
    #By the way: There are way more efficient efficient to do this, but bear with us for didactic purposes
    M1 = np.delete(M1,missingData) # Remove missing data from the array M1 by using the np.delete function, with the indices of those who have at least one nan as an argument
    M2 = np.delete(M2,missingData) # Dito, mutatis mutandis
    M3 = np.delete(M3,missingData) # Dito
    
# Good: It worked and we have equal n now. The remaining people are the same people. 
# Only people who saw all 3 movies. 
# Bad: We only have 1493 out of 3204 we started with left. In other words, we lost most of the data.
# That is a) suspicious, b) we lost a lot of power
# But we can now do the statistical test we should have done all along - pairwise t-test

#%% 3 Reformatting "V1 - or primary sensory cortex": 
# Put the data into a format/representation that lends itself to your analysis
# Usually, this is the step that will take most of the time. But it will pay
# ample dividends. Once properly formatted, most subsequent steps are very
# "natural". Importantly, do *all* of this reformatting in this step. As the specialized
# analyses will build on it. 

# I did most of the work for you already. Before even giving it to you. 
# In other words, I took the ratings that came in over time by participant 
# and broke them up, so they are now ordered by movie. I already abstracted over time.
# There is still something we can do that will make our life easier, which
# is to put this into a format we can loop over (to do all these tests). Why
# is the current format not great? Because M1 and M3 are of different length
# they can't align. But calling M1 vs. M3, etc. by name is not great
# because we won't be able to use loops. 
# Wouldn't it be better to have a matrix "DATA" that contains the remaining
# ratings (without nans) of all 3 movies?
# It would be. Why can't it be a matrix now, given we removed missing data
# element-wise? Because n is unequal. So let's instead make it an array of arrays

if pruningMode == 1:
    combinedData = np.transpose(np.array([M1,M2,M3])) # array of arrays
elif pruningMode == 2:
    combinedData = np.transpose(np.array([M1,M2,M3])) # 2D array
    # We can now put the data into a simple 2D array (not an array of arrays)
    #because we have an equal number of rows for M1, M2 and M3

#Usually, this step will be a lot longer, but here it is not, because most of the 
#"preprocessing" was already taken care of before you even got the "raw" data.
#Plus, we are only looking at Matrix I vs. Matrix III ratings, not - e.g. the
#difference between horror movies and comedies (which would require reformatting
#to do efficiently)
    
#%% 4a) Specialized computations: ("Extrastriate cortex": 

# Descriptive statistics - we are looking for very special numbers that
# capture the essence of the entire dataset - the expected value or typical number 
#(central tendency) and the dispersion. Usually mean and SD. 

# Initialize container to store descriptives:
descriptivesContainer = np.empty([numMovies,4]) #Initialize as empty
descriptivesContainer[:] = np.NaN  #Filling them with nans to begin with

# 1. Element-wise:
if pruningMode == 1:
    for ii in range(numMovies):
        descriptivesContainer[ii,0] = np.mean(combinedData[ii]) # Mean
        descriptivesContainer[ii,1] = np.std(combinedData[ii]) # SD
        descriptivesContainer[ii,2] = len(combinedData[ii]) # n
        descriptivesContainer[ii,3] = descriptivesContainer[ii,1]/np.sqrt(descriptivesContainer[ii,2]) # SEM

# 2. Row-wise:
elif pruningMode == 2:
    for ii in range(numMovies):
        descriptivesContainer[ii,0] = np.mean(combinedData[:,ii]) # Mean
        descriptivesContainer[ii,1] = np.std(combinedData[:,ii]) # SD
        descriptivesContainer[ii,2] = len(combinedData[:,ii]) # n
        descriptivesContainer[ii,3] = descriptivesContainer[ii,1]/np.sqrt(descriptivesContainer[ii,2]) # sem
        
# As we suspected, row-wise (participant-wise) elimination of nans did yield higher ratings overall
# because only the most committed fans (or othewise forgiving people) watched all 3.         
        
#%% 4b) Extrastriate cortex part II: Inferential statistics

# So far, so good. The mean rating of matrix 1 is higher than that of matrix
# 2, and the mean of matrix 2 is higher than matrix 3. 

# The question now is whether the differences we saw in the descriptives -
# usually the means - are "statistically significant". 
# In other words, whether these differences are plausibly consistent with chance
# (ie that the numbers that represent the ratings just came out of a RNG)

# 1) Assert a null hypothesis: We assume that the data came out of a RNG -
# strictly by chance. The mean ratings of all the movies are the same.

# 2) We compute the probability that this is the case - assuming chance. 

# 3) If this probability is implausibly low, we DECIDE to concede that we
# were wrong in 1) - that it is probably not solely due to chance. 

# It's a choice, it's a decision. You have not falsified the null hypothesis
# or "proven" to be wrong. We made a choice that it is implausible. But we
# could be wrong (type I and type II errors). 

# In science, we consider things that happen only 1 in 20 times to be "too
# implausible" to be consistent with chance. This corresponds to getting
# heads (or tails) 5 times in a row (if you flip coins). Is that terribly
# implausible? There is now a movement afoot to lower this to 1 in 200. To
# avoid false positives. The "1 in 20" standard yielded too many false positives.
# So results won't reproduce. This gave p values a bad reputation. 
# But there is nothing wrong with p-values, if they are understood and used properly. 
# Properly = using a conservative enough criterion of implausibility while retaining sufficiently high statistical power
 

# So our question now is: Assuming that there is no difference in reality, how
# likely is it to get this mean difference just by chance (sampling error).    

# Analogy: We are doing a crime scene investigation. Null hypothesis is the
# presumption of innocence (the person died of natural causes).
# We only reject that presumption if forced by the data (in other words, if the evidence (fingerprints, DNA, etc.) 
# suggests that there was foul play (potentially implicating a suspect). 
# But it is always possible to be wrong. 
# The unreasonable doubt (that your evidence got there just by chance always persists). 
# There is no proof (in the mathematical sense). 

# We need to do a t-test because we want to assess how likely this observed
# mean difference is by chance, and we do not know the population parameters. 
# We have to do an independent samples t-test because we eliminated missing data in a 
# way that yields unequal n. We have no choice (if we want to do a t-test)

# 1. Element-wise:
if pruningMode == 1:
    t1,p1 = stats.ttest_ind(combinedData[0],combinedData[1])
    # t is the t-statistic
    # How likely is such a t-value by chance
    # That is given by the p-value
    # There is a significant difference. 
    # In english: The difference between the samples (specifically the sample 
    # means) is too large to be reasonably consistent with chance. 
    # So we conclude that Matrix 1 is indeed the better movie (relative to Matrix 2)

    # Now let's compute the degrees of freedom (N1 + N2 - 2):
    df = int(descriptivesContainer[0,2] + descriptivesContainer[1,2] - 2)
    # The p-value depends on it (as the t-distribution is a family that depends on df)

    # How likely was our mean difference assuming chance? 
    # The p-value is really small. An alpha of 5% is an extremely liberal threshold.
    # p-values of real effects are very close to 0, if you have sufficient
    # power. They are distributed as a beta-distribution. Like this one.

    # Degrees of freedom for an independent samples t-test is:
    # Sample size1 + sample size2 - 2 (2 because we calculate 2 sample means and
    # we lose 1 df per sample mean). So the general equation for df is not n -
    # 1, it is n - k. 
    
    # To check manually whether the function is correct:
    # Compute the pooled SD (with equations from textbook):
    num = (descriptivesContainer[0,1]**2)*(descriptivesContainer[0,2]-1) + (descriptivesContainer[1,1]**2)*(descriptivesContainer[1,2]-1) 
    denom = (descriptivesContainer[0,2]-1) + (descriptivesContainer[1,2]-1)       
    pooledSD = np.sqrt(num/denom) 
    SE = pooledSD * np.sqrt(1/descriptivesContainer[0,2]+1/descriptivesContainer[1,2])
    t = (descriptivesContainer[0,0]-descriptivesContainer[1,0])/SE #Compare t with t1 from function
    
    # The independent samples t-test is the only one we can do, once we have
    # unequal n, but is it the right test? Did the data about the 2 movies come
    # from different populations? No. They are the same people. In reality, we
    # probably have much fewer df than that. Oh no. We made a mistake.
    
    # We might have made another mistake. Visual inspection of the descriptivesContainer
    # suggests that the variances of Matrix I and the other Matrix movies are not really equal
    # So we need a Welch t-test instead. This is how we ask for one:
    t1W,p1W = stats.ttest_ind(combinedData[0],combinedData[1],equal_var=0) #Turning equal_var off    

    # Mean of Matrix 2 and 3 seem rather close. 
    # Question: Plausibly due to chance alone?
    # In other words, are the differences in mean we see just due to sampling error?
    t2,p2 = stats.ttest_ind(combinedData[1],combinedData[2])
    
    # This p-value (that corresponds to this t-value at df) is also less than alpha, 
    # so even the difference in mean rating between Matrix 2 and 3 is statistically significant. 
    # So we conclude that Matrix 2 is a better movie than Matrix 3. 

    # We can do as many t-tests as we want. We will have to adjust the
    # alpha-level from 0.05 to 0.05/c, where c is the number of tests
    # (comparisons), that's called the "Bonferroni correction". 

    # Even this comparison is significant, even after the Bonferroni correction,
    # so we conclude that this observed difference in ratings is not due to
    # chance alone. In other words, Matrix 2 is a better movie than Matrix 3. 
    # Expectation: The p-value will be even lower than 1 vs. 2, because the
    # mean difference is larger, but it might not be, because the df will be
    # less (fewer people saw M3). The p value comes from the t-value in light of
    # the df (because the t-distribution is a family of distributions which
    # differs as df - that's a parameter).
    t3,p3 = stats.ttest_ind(combinedData[0],combinedData[2])
    
    #It's fine to do all of these t-tests. 3 t-tests to assess all pair-wise differences
    #You can do that. But if one did this for like 100 movies and did all pair-wise comparisons
    #one could be worried about making too many comparisons. If you do make many comparisons, you
    #are more likely to get a false positive, as the alpha level controls the false positive risk
    #*per* comparison. This is called "alpha inflation". 
    #A way around that is the ANOVA, a statistical test that controls for false positives 
    #by doing all comparisons at once.

    # Do this with ANOVA - allows to compare more than 2 sample means without 
    # inflating alpha (from multiple comparisons)
    f,pA = stats.f_oneway(combinedData[0],combinedData[1],combinedData[2])
    #ANOVAs yield an "f" value as a test statistic
    #The question we have for this f value is what p-value is associated with it
    #The question we have for the p-value is whether it is smaller than the alpha level
    #If it is, we call the difference "statistically significant".
    #Here, we conclude that the matrix movies in the trilogy are of inconsistent quality
    #Importantly, we did this with a single test - the ANOVA, not 3 t-tests.
    #In general, an ANOVA replaces pairwise tests - however many you have.
    #In other words, the cumulative sum of 1:n-1, where n = number of movies.
    
    #However, if the t-test was not an appropriate test (due to the presumed inequality of psychological distances)
    #and the ANOVA is an extension of the t-test to more than 2 groups (or group means), then
    #the ANOVA was probably also not the right test. We should have used a 
    #nonparametric 
    
    
    # Nonparametric tests equivalent to t-tests - Mann-Whitney U test:
    # Frankly the test you should usually be using if you are unsure if your data
    # have linear properties (ratings data in general don't).
    # In addition, t-tests assume that data is normally distributed. 
    # Aside: A histogram that shows that ratings data is not normally distributed 
    # for most movies. Definitely for Matrix I: 
    plt.hist(combinedData[0],bins=9) #Ratings from 0 to 4 in 0.5 steps = 9 bins        
    
    # So in general, non-parametric analogues of these tests are more suitable
    # Test for comparing medians of ordinal data (such as movie ratings)
    # from 2 groups:
    u1,p1 = stats.mannwhitneyu(combinedData[0],combinedData[1]) #1 vs. 2
    u2,p2 = stats.mannwhitneyu(combinedData[0],combinedData[2]) #1 vs. 3 
    u3,p3 = stats.mannwhitneyu(combinedData[1],combinedData[2]) #2 vs. 3

    # Nonparametric test analogous to the ANOVA - "Kruskal-Wallis test":
    # Same assumptions as above, non-parametric and works for more than 2 groups
    h,pK = stats.kruskal(combinedData[0],combinedData[1],combinedData[2])
    # Question for h, our test statistic: How likely is that by chance
    # Question for p, our p-value: Whether it is smaller or larger than alpha
    # Significant: If smaller than alpha: Significant --> Movies are of inconsistent quality
    

# These are not different people. So we have to do a "within subjects"
# design (repeated measures) - in other words do a paired samples t-test. 
# But to do that, we need to do row-wise removal of missing data 

# 2. Row-wise:
elif pruningMode == 2:
    # Because our n's are now equal, we can now do a t-test for dependent
    # groups (which is much more appropriate, because our data came from the
    # *same* people, the groups WERE dependent, we previously inflated df)
    t1,p1 = stats.ttest_rel(combinedData[:,0],combinedData[:,1])
    df = len(combinedData) - 1
    # Df HERE is now n-1, because the t-test for dependent groups first
    # converts all scores to differences, then takes ONE mean, so we only
    # lose 1 df. Overall, we have much fewer df, than in the independent
    # samples t-test.
    # The p-value is *even* lower! 
    # How is that possible, given that df is much lower too (less power)? 
    # In an independent samples t-test individual differences (some people
    # just don't like anything, or everything) all goes into the
    # denominator, in other words is interpreted as error. That lowers the
    # t-value. In a paired-samples t-test, everyone is their own control. So
    # the individual differences go away. In english: A paired samples
    # t-test is usually much more powerful, even if the df is lower.
    # So you should do this one, whenever you can. 
    t2,p2 = stats.ttest_rel(combinedData[:,1],combinedData[:,2]) #Matrix II vs. III?
    t3,p3 = stats.ttest_rel(combinedData[:,0],combinedData[:,2]) #Matrix I vs. III
    
    #Is participant-wise pruning necessarily always better? 
    #It was here, because the data is not independent. 
    #But that is not always the case. 
    #In fact, one could argue that the differences between the movies were minimized
    #because we only considered people who managed to bear to watch all of them.
    #Those people are a very special breed. Are you sure that they are representative
    #of all people who watch movies? 
    #Every time (always!) when you are handling missing data, you have to be extremely careful
    #There are all kinds of tradeoffs in statistical properties, meaning, etc. - that you might not even be aware of
    #when you simply use default. In other words, the default is not always best. 
    #There is no winner take all situation that is always best - there are always tradeoffs.
    #That will be true for all data analysis we do from now on (beyond toy examples)
    #So an analyst can do whatever they want, but they need to be aware of and - be able to - justify their choice
    #That's why this is such a lucrative field. Anyone can call the functions. 
    #Few truly understand what they are doing. High demand, short supply = Value
    #Few understand
    #Few
    
    # Let's do an ANOVA instead:
    f,p = stats.f_oneway(combinedData[:,0],combinedData[:,1],combinedData[:,2])
    
    #Missing: We should do the nonparametric versions for the row-wise pruning here.
    #It's missing from the code. 
    #Exercise for the reader: Add it, so it works with the "nonparametric" flag
    #All you have to do is change the code from the element-wise pruning so it
    #works with a 2D array, not array of arrays
    
#%% 5 Motor cortex: Plot the data 
# Here we are going to plot the data from our ANOVA and add a title
# that contains the f- and p-values

# First, let's run our ANOVA once again:
if pruningMode == 1:
    f,p = stats.f_oneway(combinedData[0],combinedData[1],combinedData[2])
elif pruningMode == 2:
    f,p = stats.f_oneway(combinedData[:,0],combinedData[:,1],combinedData[:,2])
    
# Now, let's plot it:
x = ['Matrix 1', 'Matrix 2', 'Matrix 3'] # labels for the bars
xPos = np.array([1,2,3]) # x-values for the bars
plt.bar(xPos,descriptivesContainer[:,0],width=0.5,yerr=descriptivesContainer[:,3]) # bars + error  
plt.xticks(xPos, x) # label the x_pos with the labels
plt.ylabel('Mean rating') # add y-label
plt.title('f = {:.3f}'.format(f) + ', p = {:.3f}'.format(p)) # title is the test stat and p-value
# Note: we round our p-value to the nearest thousandth, which in our case is 0.000
# In reality, it is much smaller than that. Instead, we could have chosen to use
# scientific notation in our title. More on that later.

#%% W1: An alternative approach: Representing the data with a Pandas dataframe 

import pandas as pd

# 1. Load data:
df = pd.read_csv('movieRatingsDeidentified.csv',skipinitialspace=True)
# Fill empty strings with NaN; skip spaces after delimiter 
# Now we have the headers AND the data in one object, a data frame
# dataFrames are optimized for handling tabular data.
# Tabular data: Data that is organized in a table with rows and columns
# I fully concede that handling this kind of data with a data frame *is* easier. 
# But not all data is tabular. An image, for instance. Numpy handles that just fine.

# 2. Let's get a handle on our movie titles:
titles = df.columns 
print(titles)
# We won't use this for subsequent analyses, but it's nice to see all the titles at once

# 3. Find the Matrix data:
#This is much easier - we simply give it the title we ask for, no need to     
movieTitle = 'Matrix' # or any other title, for that matter 
theMatrix = df.loc[:,df.columns.str.contains(movieTitle)] # Access group of rows and columns by label(s)
#"Loc" is the analogous dataframe command to numpy's "where" - if finds the location in the dataframe where these conditions are true

# 4. Perform descriptives:
magic = theMatrix.describe() #The method "describe" of the data frame gets all of the descriptives at once
# We don't have to run a loop or initialize a container
# We are still missing the SEM, so let's add it:
temp = magic.iloc[2,:]/np.sqrt(magic.iloc[0,:]) # Access group of rows and columns by integer position(s)
magic.loc['sem'] = temp # add as bottom row of descriptives dataframe

#We can now redo the rest of the analysis - easily - within a dataframe context
#It's just a couple of lines of code
#Straightforward

#%% W2 Doing a two-way ANOVA and showing an ANOVA table

import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.graphics.factorplots import interaction_plot as meansPlot

df = pd.read_csv('twoWayAnovaExample.csv',skipinitialspace=True) # load new data set
df.info() # What is the structure of the data frame?

model = ols('Value ~ X1 + X2 + X1:X2', data=df).fit() #Build the two-way ANOVA model. Value = y, X1,X2 = Main effects. X1:X2 = interaction effect
anova_table = sm.stats.anova_lm(model, typ=2) #Create the ANOVA table. Residual = Within
print(anova_table) #Show the ANOVA table

#Show the corresponding means plot
fig = meansPlot(x=df['X1'], trace=df['X2'], response=df['Value'])