# CS 8: Canonical data analysis cascade.  

# We will continue this script to actually do the significance tests 
# For today, we'll focus on creating the basic data analysis cascade for hypothesis testing
# We'll build on this next time.


#%% In this script, we will analyze real data from a published article. 
# Well, a subset of it. The point is specifically to illustrate hypothesis testing 
# in Python, implementing the Canonical Data Analysis cascade. 
# This is toy example, so the full power of this won't be apparent until you do the capstone project
# But once you do, you will understand. There, the loading/cleaning/formatting will
# pay dividends to answer the specific questions. 
# The advantage of this is that you'll be free of the limitations of canned
# packages like Excel or SPSS. Once you loaded the data into whatever format
# you use in Python (usually an array or a dateframe), you "own" it. You can 
# do whatever you want. This represents "computational freedom". 
# "Computational empowerment."
# With data. Very powerful. 
# Specifically, we will test the hypothesis that Matrix I was the best of
# the Matrix movies (it's a trilogy). 
                    
# Before we do that in code, lets revisit the logic of the null hypothesis significance
# testing framework at least once (just once). 
# It is a bit arcane. It made sense to Fisher.
# Today will be light on software engineering, but heavy on logic. 
# To make sure that this makes sense.                  
                    
# 1) Start with a hypothesis (something about the world you would wish to
# know the truth status of (whether it is true or not). 
# The research participants ("participants", from now on)
# are the unit of analysis that gives you the data here, but be prepared that
# in the future, unit of analysis could be city or country or whatever else. 
# By convention, the "replicates" or "units of analysis" that give us the data are in the rows.
# The features/variables that they give us on (the movies) are in columns, by convention. 
# Here, I'm giving you the data in this format, but that's because I already did the preprocessing.
# In real life, someone might hand you a very long text file that you have to parse and arrange in 
# this way. Important point of note: The rows are fully indepedendent - the participants in the study
# completed the study on their own, they did not communicate and they were recruited and enrolled
# randomly. The columns are not independent - the data comes from the same people. All participants
# rate the same movies (if they saw them). This will be very important later. Right here, what the
# numbers represent matters. Python does not know this. What the right thing to do is depends on 
# how the data were recorded (independently / dependently, etc.) - that's not in the numbers. 
# As a reminder: Theoretical hypothesis (for instance): Matrix I is the best movie in the trilogy.
# Highest rated by people who saw it = A testable version ("operationalized") 
# of the theoretical hypothesis. Needs to be something quantifiable. 
# That might seem like a minor point, but you will need to break all of your theoretical questions
# down into testable ones (this is called "operationalization"). 

# 2) State a null hypothesis and assume that it is 100% true (that there is
# no difference in the conditions of 1), e.g. here Matrix I rated the same
# as Matrix II and III). This is essential to NHST. Seems counterintuitive. 
# If you already suspect that Matrix I is the best of the movies, why would you assume
# that you're wrong? [Explicit and strong formulation of the advocatus diaboli]
# This is about the burden of proof and guards against confirmation bias (and other biases).
# Most social organizations do not do this. They just run with their confirmation bias to jump to
# conclusions. The whole point of the scientific method is to institutionalize falsification. 
# Shifting the burden of proof - we assume that there is no difference in the quality of the movies
# unless the data forces us to give up that assumption - because it has become implausible in light
# of the data. 

# 3) This is - on the face of it - an odd thing to do, because naively you
# would think that scientists look for probability (Hypothesis | Data). 
# This would be nice to have. 
# But as you saw in the lecture on hypothesis testing, that is unknowable. 
# Which is why we do the study in the first place.
# What is calculable: Probability (Data | NULL hypothesis)
# We can assess the probability of the data given the null hypothesis is true
# In other words, we do this because we can calculate this probability. 
# The first thing would be nice to have, but is unattainable. So we do this, which can be done. 

# 4) To calculate this probability, we represent the entire sample (at least one variable of it)
# by a statistic like the sample mean, then we transform the sample mean 
# into a test statistic that has a known null distribution.
# The null distribution is the distribution of the test statistic assuming the null hypothesis
# is true. 
# You can find this null distribution at the back of every statistics textbook, 
# e.g. z, t, F, Chi-squared, etc.

# 5) We then have to obtain the p-value by considering the area under the null distribution curve 
# of test statistic in the tail (or both tails, if it is a 2-tailed test) 
# This is the p value, in other words the probability of the result (or a more extreme one)
# given chance alone (ie if the null hypothesis is true).

# 6) We compare this p value to the significance level alpha (typically 5% or 1%)
# The significance level is chosen to reflect a level of chance that is absurdly implausible. 
# Something like one would only expect this outcome 1 in 1000 times or 1 in a million times by
# chance. However, for the sake of convenience (see Fisher), science settles for a standard of 
# "absurdly implausible" of 1 in 20. Basically - how surprised are you to see this result. 
# Mildly surprised - 1 in 20? 

# 7) Decision point (Choice - not proof!)
# a) If the p-value is smaller than alpha, we decide to reject our assumption that the 
# null hypothesis is true. We acknowledge that we were wrong. Why? Because assuming the null
# hypothesis, we obtained a result that is implausible (unlikely). In other words, the scientific 
# method is a reductio ad absurdum. Sherlock Holmes uses this a lot. Making certain assumptions, you
# arrive at implausible conclusions. If the reasoning is sound, the conclusion has to be to drop
# the assumption that led you to the contradiction. 
# b) If the p-value is not smaller than alpha, we don't do anything because we already
# assumed that the null hypothesis is fully true. So nothing changes.                      
                    
# Paraphrased logic, in english: We explicitly acknowledge any outcome could be due to
# chance. [This is a chance acknowledgment.]. Every scientific investigation starts by an 
# acknowledgment. And that acknowledgment is that our results could be entirely due to chance 
# alone. And we state is as the null hypothesis. The only question is how likely that is 
# by chance. If it is implausibly unlikely, we reject the assumption that it was just due to
# chance. And either the null hypothesis is true or not, so if we reject that it
# is plausible, it probably means that our treatment did have an effect. 
# Implementation of what implausibly unlikely means: alpha level.     

# This logic is somewhat counterintutive, as you basically use the probability of being 
# wrong about being wrong.
# To make your conclusions. But it is the logic that is used in 90+% of all science, today.

# This makes it impossible to say that you proved OR disproved something with data. 
# Even if you reject the null hypothesis, you did not disprove it. You falsified it.
# But only with a certain probability. You could be wrong. 
# Even rejecting it or "failing" (not a bad thing) to the H0 is not a proof or disproof. 
# All of this is entirely probabilistic. 
# This is not semantics. If you prove something, you cannot be wrong. A proof yields certainty. 
# You can be woefully wrong. And will be blindsided if you don't understand this. 
# You could lose all of your money. 
# This is more like statistical decision theory. And decisions can be wrong. 
# I can't emphasize this enough. (I guess)             
                    
#%% Before we (finally) do the stats, let's talk about the interplay of 
# the psychology and statistics of rating movies of a movie trilogy:
    
# Hypothesis 1: First is best. Because that's usually true for trilogies
# (with the exception of Star Wars). That's probably true just because of
# regression to the mean (hit movie is made somewhat by chance, 2nd one = a cash grab, 
# but they can't recapture the "lightning in a bottle" / zeitgeist of the original).
# Also expectations. If the first one is great, it's hard to beat expectations. 
# So the 2nd movie in a trilogy might be experienced as worse than it actually is.

# Hypothesis 2: Ratings for later movies in a trilogy will be better than earlier ones.
# Production quality improves over time (special effects). Also, if the first movie was a hit
# and encouraged to make a 2nd one, they usually have more money for the 2nd one. 
# Also, only fans might watch all of them.
# People who didn't like the 1st one might drop out and never watch the
# other ones, so the RATINGS might be higher. [Survivorship bias, because people who
# didn't like the first one won't watch the 2nd one, only fans will. More on this later]
# If this is true, it threatens our operationalization of movie quality as user ratings. Focusing 
# on ratings could yield misleading results. The only solution if this is the case would be to do
# an experiment and intentionally expose people to certain movies (regardless of what they normally)
# would prefer to watch.

# Make sure that you actually have 2 plausible outcomes before doing the study. 
# If the outcome is a foregone conclusion, it's not science. 
# If you are scientist, you have to be open to any possible outcome.
# Tricky, as people who go into a certain field usually have a reason to do so.
# Understandable from a psychological perspective, that people go into a certain field with
# an agenda, but deadly for science. 
# Try to keep an open mind. If you want to do science with integrity. 
# If you already know the outcomes of your research before you do the research, it is not research. 
# It could be many things, e.g. ideology, activism, a statement of belief, etc. but not science. 
# Science is about finding the answers to questions where the answer is not already known. 

# Null hypothesis (as always): There is no difference in ratings. 

# Let's implement the canonical data analysis cascade

#%% 0 Initialization ("Birth")

# Here, we set all of the constants we will reuse throughout the code. 
# A good example for a constant that we will troughout the code is the alpha level. 
# The reason you want to set *all* of your constant right here is maintainability. If you do 30
# statistical tests in one analysis (the average value for your typical project), you will use alpha
# 30 times. Imagine if you set it in various places, want to change it, then forget to update one
# of them. That would be a problem, no? [An estimated 30% of research papers have flawed conclusions
# just from this kind of coding issue. I'll upload the paper to the W tier materials.]
# You will save yourself a *lot* of headaches, if you declare all of the things you will use more
# than once right here, up front. In a block. So you can see all constants in the code up front 
# and change them at will. 
# Also all "flags" that we will use throughout the code. 
# A flag in the analysis of code with data is a variable that represents a choice of the analyst 
# as to how to analyze the data. For instance, today we will make at least 2 choices:
# 1) how to "prune" the data, 2) Whether to use parametric or nonparametric tests. 
# But this could be anything, what baseline to use, whether to smooth the data, whether to 
# normalize, how to normalize (e.g. by z-scoring), etc. 
# Flags are usually used in an if statement later. 
# This will make for more maintainable code, as usual. For instance, if you set flags throughout
# the code, you will quickly forget about them, and not be able to update them, should sth change
# Keep all of them in one place, up top. [In other words, this makes dependencies explicit]
# A statement (a paragraph of comments) as to what the code is doing, 
# what it produces (files, plots) and what it assumes (e.g. what data files exist and where they are)
# is not a mistake either. 

# a) "Predispositions:"
startColumn = 177 #This is the column that contains data from matrix I
# matrix II is column 178 and matrix III is column 179
numMovies = 3 #Data from how many movies (it's a trilogy)
alpha = 0.05 #Fisher would be so happy. This is a good example of a constant
pruningMode = 1 # This is a good example of a "flag". This flag is a variable that determines how 
#we will handle nans. It's important to be mindful of this, as it will determine what analyses 
#are even possible later on. It's not as simple as "dropping" them. It will also determine what the
#data even means. 
#1 = element-wise removal, 2 = row-wise removal, 3 = naive imputation, 4 = "smart imputation"
#Removal = some kind of way to eliminate missing data (values) from the dataset.
#Imputation = Some kind of guess as to what the missing number might have been. This is obviously 
#extremely sketchy to do in science because this number did not come from measurement. Also, what
#should the number be? We will have to handle missing data at scale here, because most people did not
#see most of the movies. Pretty much all of the functions we'll be using presume that there are no
#missing values. Even taking the mean of a variable that contains a single nan, usually just returns
#a nan, if it even runs (and doesn't just throw an error). But I have a question for you, up front. 
#Sometimes, data is missing randomly and rarely. Here - again - what does missing data mean? 
#A user did not see a particular movie. In other words, it might reflect either a choice by the user
#not to see it, or it might reflect that they were unaware of it. Maybe they were unaware of it 
#because it is bad. Maybe they didn't want to see it because they knew they wouldn't like it. 
#If that is true - and something like this is almost certainly true if you have ever watched movies -
#would it be a good idea to impute the missing value as the mean of the ratings of the people who 
#did see the movie? It would not be. Because the people who rated it on some base level decided to
#see it. Those are fundamentally different populations. So what to impute then? A 0 as an implied
#rating for "chose not to see it"? That seems a bit extreme. A blend of 0 and the mean? Or even if 
#you do the mean - what mean? The row - the average rating of that user (if they are particularly 
#cheerful or harsh, that might matter), the column mean (of everyone else who did see the movie), 
#a blend between row and column mean? In other words, imputation is a very dark art. In science, it
#is frowned upon, for this reason. But it is very common in engineering. In defense of engineering, 
#they usually try to validate their choices somehow. What I mean by "smart imputation" is to build a
#prediction model as to what the missing value should be, from the entire rest of the dataset. 
#For now, I just want to note that right here - how we will decide how to handle missing data with
#this flag sets up the entire rest of the analysis.    
 

# We should set another flag for parametric vs. nonparametric statistics, 
# then use it in the code later
# But I'll leave that as an exercise. For now, let's just do both. 

# A third flag could pertain to whether you want to use numpy arrays or pandas dataframes 
# We will do this next time.

# b Load/import - *all* of the libraries/packages we will be using:
import numpy as np
from scipy import stats
import matplotlib.pyplot as plt

#Why use numpy, and not pandas? [next time, we will use pandas]:
#Students keep saying: I already learned pandas in DS4E. It seems awesome. Why do we use numpy? 
#1) Numpy is much, much faster. Orders of magnitude. This won't matter today, or probably for 
#anything you have ever done, but if you have a huge dataset, it could cut execution time 
#from months to hours. Simply by switching to numpy. 
#2) Yes, pandas is "awesome", meaning it does a lot of things for you that are cumbersome to do 
#by hand. However, in order to do so, it makes a lot of assumptions that you 
#might not even be aware of that it is making. For instance, a lot of students simply call "dropna"
# with drops nans from a dataframe. They also usually follow that by
#saying "lol". But there are many ways to remove nans, all of which have drastic implications 
#for the analysis. It's almost like using a function vs. doing some computation
#by hand. Functions are great, but if you want to understand, 
#it is better to do it by hand, "beforehand". To know what the options even are, or why they matter.
#3) You just said that you already know how to use pandas. 
#Is it a criminal offense to learn something new? Is it specifically prohibited by the 
#constitution of the United States? No, it is not. So why not learn something? 
#That's the point of a class. You are paying for this. 
#4) It is generally a good idea in coding to have multiple ways of doing the same thing.
#Having more available tools is rarely a mistake. Think of this as a toolkit.     
#5) Pandas is best for tabular data (think spreadsheets). 
#If the data is anything else (time series, vectors, images, sounds), 
#things will be very hard in pandas, but very straightforward in numpy. 

#For these reasons, if you want to be a data scientist, I strongly encourage you to also learn 
#numpy. Doesn't mean to not learn pandas. And we'll start mixing it in. But you told me that you
#already know pandas. So...

#%% 1 Loader ("Transducer"): 
# Taking the inputs from their native form (whatever they might be) and putting it into 
# something Python can use: an array

# There are 2 common standards: comma-separated value (csv) files and SQL databases. We'll do both
# in this class, but don't be surprised if - on the job - you have to parse a text file first. 
# If this was anything more complicated, it would not be a bad idea to set the file path or file name
# as a variable up in "initialization". Here, we always use the same file 
data = np.genfromtxt('movieRatingsDeidentified.csv', delimiter = ',' , skip_header = 1)
# We want just the data, so skip the first row / header. No strings attached. 
dataMatrix = data[:,startColumn:startColumn+numMovies] # The matrix data, haha. 
#Should yield a n x 3 matrix
#Colon (:) in absence of any delimiters, simply means "all", here all rows, 
#because it is the first dimension
#The data comprises "star ratings" of these movies, which is a typical rating scale for movies.
#Rows: Participants, people who rated the movies, there are 3204 raters
#Columns: Movies, there are 209 movies

# Just this time:
# Decompose dataMatrix back into separate arrays, one for each movie:
# This seems backwards, as we just assembled the matrix data in this array, and it is.
# But it will be necessary for element-wise removal of nans, as you will see. 
    
M1 = dataMatrix[:,0] #Reach into the array and take out the ratings of the first movie
M2 = dataMatrix[:,1] #Dito, but mutatis mutandis for the 2nd one
M3 = dataMatrix[:,2] #Dito, but for the 3rd one

# They are all the same length because if the participant did not respond
# the element is represented with NaN.
# Why represent missing data with nans in the first place? 
# Because 1) Arrays can't have holes (for reasons of alignment of stacking, see a previous lab), 
# why not 0s? Because that would imply a 0 rating. 
# [Which by the way: Could be true. You anticipated that the movie was going to be so bad, 
# that it would correspond to a rating of 0 if you actually watched]
# If that is true, using 0s would be better. But without testing for that, be careful.