#Last time, we worked with single predictors and single confounds (simple linear regression) and 
#partial correlation. Now we will extend that to multiple predictors/confounds:
#What if we have more than one potential confound that we want to control for at the same time
# or what if we simply want to know how much each factor matters (while controlling for all the others in the model), 
#in a phenomenon that has many contributing causal factors?
# Both use cases call for multiple regression, an implementation of the general linear model

#%% 0. Importing the libraries we  need for this session
import numpy as np #Always good to be able to do linear algebra
import matplotlib.pyplot as plt #Always good to be able to make plots
from sklearn.linear_model import LinearRegression # We'll use the regression functions of this scientific computing package today

#%% 1. Load the data 
# As usual, we start the analysis cascade by loading the data:
data = np.genfromtxt('determinedIncome.csv',delimiter=',') # IQ, hours worked per day, total years of formal education, income
#Idea: The raw data might be in any format. Who knows? But whatever it is (here, a csv file), 
#we need to bring it into a python data structure (here: an array), so we can do something with it.
#In this lab, we have actually kept overwriting the "data" structure, and just named it "data" throughout. 
#That is actually not a good idea. We should have been more specific. 
#I literally did this for a simple lab, just to save some typing time. 
#Going forward, we will use more specific names for these variables, as both is bad:
#Overwriting variables, and not being specific enough with the variable name. 
#For instance, if we put what is in the data into the name, we could have saved ourselves some comments

#%% 2. Descriptives and EDA

# As usual, we then explore the data a little bit, by computing the summary statistics:
#By the way: Naming these "D1 to D5" is also terrible. Don't do this. 
#Same idea: I saved some time typing and they are all descriptives, hence "D", and we only
#need it for EDA and it's only us, so we'll be ok. But going forward, just don't. 
#For instance, I would call D1 "columnMeans" or something like that    
D1 = np.mean(data,axis=0) # take mean of each column
D2 = np.median(data,axis=0) # take median of each column
D3 = np.std(data,axis=0) # take std of each column
D4 = np.corrcoef(data[:,0],data[:,1]) # correlate IQ and hours worked
D5 = np.corrcoef(data.T) #The full correlation matrix 
#The full correlation matrix contains all pair-wise correlations between all columns
#Which is very neat if you have - for instance - 100 variables and want to know which have the highest (or lowest or whatever) bivariate correlation.
#Importantly, this is a single line, and a vector operation at that, so it is very fast. No nested loop is necessary (although you could write one, just to understand this, it would just be very slow)
#We know that this is what we want because it is a 4x4 (and we have variables), and all entries on the diagonal are 1.
#However, there is an idiosyncracy here. 
#The idiosyncracy is that the numpy corrcoef function is that this somewhat violates the convention and performs row-wise correlations by default
#data.T transposes the matrix. If we don't transpose it, numpy interprets the rows as the variables.
#That could be interesting. Say if you want to know which individuals are most similar to each other. 
#And Python doesn't know which one you want - the pairwise correlation between individual attributes or the correlation between variables. 
#Try it without the transpose and confirm that it yields a 1500x1500 matrix of correlation coefficients. 

#EDA: Visual inspection of the full correlation matrix confirms that the numbers broadly make sense.
#The pattern of correlations is consistent with what one would expect from common sense (e.g. people who work more make more money, but the correlation is not perfect)
 

#%% 3. Modeling: One predictor
#Now, let's model income as a function of predictors, implementing the general linear model
#Advice: If you build a complex model with many predictors, it is recommended that you build the model one predictor at a time, so you can see how the model performance evolves

# Our model: Starting with a single predictor, let's pick IQ (the choice of starting predictor is somewhat arbitrary)
x = data[:,0].reshape(len(data),1) #Reshape to get a column, explicitly, as above/before
y = data[:,3] #Outcome is now income (that always sounds strange when saying it out loud, but it's true)
singleFactorModel = LinearRegression().fit(x,y) #Fitting it, like above
#Here, reusing x and y throughout is ok because it follows convention. Everyone knows that
#y means outcome and x means predictors. This just makes the code more readable. 
#If it is important to store x and y somewhere (for later), then don't overwrite it. 
#But we literally only use them as *inputs*, never as outputs. Never overwrite outputs. 
#And inputs neither, if you want to re-use them. But we don't, at least not here. 
#In other words, naming variables is always a delicate balance between pithiness (pithy), so you have to type less
#convention (so that people can read your code), tradition, creativity and many other considerations (like whether you will re-use the variables or not)

rSqrSingle = singleFactorModel.score(x,y) #Variance in outcome accounted for in the outcome, by this model
print(rSqrSingle)
#Our IQ-only model accounts for about 11% of the variability in income
#We want to explain why some people earn more and some people earn less.
#That is the variability in income. The question that this single variable model
#answers is how much of that variability is due to IQ only. 
#First of all, it is interesting that IQ accounts for only 11% of the outcome (income). 
#Which sounds small, but is actually consistent with the literature. 
#However, if we actually want to predict projected income, we have to do better. Not being able to
#account for 90% of the variability is not good. In terms of practical utility of this model. 
#In addition, we don't know if IQ is even to be taken at face value. Maybe IQ is only spuriously linked (as a marker) to the outcome.
#For both reasons, we need to introduce more predictor variables ("features" in ML lingo) to the model

#%% 4. Modeling: 2 predictors at once
# 2 predictor model: IQ and hours worked jointly as predictors (2)
# Why was it a smart choice to add hours worked to IQ as the 2nd predictor?
# Why not years or formal education?
# We want to add predictors that add as much independent information as possible.
# Both to avoid collinearity concerns and because we want to increase our r^2 as much as possible. 
# Now, our EDA now pays off. We know from the EDA (looking at the full correlation matrix) that the lowest correlation with IQ is hours worked, suggesting independence (might be nonlinear, but ok)

X = data[:,:2] #Note the syntax: Instead of picking the first column and then telling pyton explicitly that the result is to be treated as column vector, this is now using some of the advanced slicing that we introduced 2 weeks ago: Take all the rows, but only the first two columns. Note that this is the (exclusive) ending index. 0 and 1, but not 2. Everything up to 2, but not 2
# X now contains 2 columns, and we will use both of them as predictor variables. Upshot: The predictor is now a matrix of predictors.
# Let's use uppercase X for the predictors from now on, because the convention if X is a matrix is that it is uppercase. Leverage conventions whenever possible.
# y = data[:,3] Again, income
# As we re-use the same y (income, in all cases, because that is what we care about), we can comment this out

twoFactorModel = LinearRegression().fit(X,y) #Literally the same syntax, just now with a matrix of predictors
rSqrTwo = twoFactorModel.score(X,y)
print(rSqrTwo)
#Now, this two-factor model accounts for about 26% of the variance in incomes
#It more than doubled. Because income and hours worked are basically independent, and hours worked was a better predictor (stronger correlated with income)
#Still, we are unsatisfied. ~3/4 of the variance is still unaccounted for. Let's throw everything we have at the problem.

#%% 5. Modeling: The full model with all predictors
# "Full model": Using all available factors (variables) as predictors
X = data[:,:3] #Same syntax as above, take all rows, but slice it so we get the first 3 columns: 0, 1 and 2. This will yield a matrix with 3 columns. Automatically. 
#Importantly, don't include income as a predictor of income. Whereas that is obviously the best predictor (if I know what your income is, I can predict it perfectly)
#it is also beyond useless. Misleading. Trivial. So make sure not to include the outcome as the predictors. 
#"data" contains all variables, both predictors and outcomes, so we have to slice it. 
#y = data[:,3] #Again, can be commented out, as it is the same outcome, earnings
fullModel = LinearRegression().fit(X,y)
rSqrFull = fullModel.score(X,y) #All literally same syntax as before
print(rSqrFull)
#Our full model accounts for about 47%, or just a little below half of the variability of the outcome. 
#Given the the outcome (earnings) is really hard to predict and dependent on many things, this is actually quite decent. 

b0, b1 = fullModel.intercept_, fullModel.coef_ #Reach into the model object and get betas and intercept out
#The remarkable thing about the full model is that we can now read off from the array of betas (b1, here)
#how much a unit increase in that predictor variable matters for the outcome, while *controlling* for all other predictors in the model. 
#For instance, it appears that the beta for "years of formal schooling" is about 4.88. 
#This means that for every additional year of formal schooling, an individual can expect to earn
#an additional $4.88k/year, controlling for intelligence and work ethic. 
#In other words, you can *directly* interpret these coefficients. 

#%% 6. Visualization
#Now for the trick - visualizing the performance of a model with many predictors, as seen in lecture
#With more than 2 predictors. 1 = line, 2 = plane. 3 = oh no? 
#No. We can use the trick. The trick is to subsume all predictors under "yhat" and plot the outcomes
#as a function of that. In other words, on the x-axis will be the model predictions
#On the y-axis will be the actual outcomes. And the closer to a line this scatter plot is,
#The better the model is.

#Actual vs. predicted income (from model)
yHat = b1[0]*data[:,0] + b1[1]*data[:,1] + b1[2]*data[:,2] + b0 #Evaluating the model: First coefficient times IQ value + 2nd coefficient * hours worked and so on, plus the intercept (offset)
plt.plot(yHat,data[:,3],'o',markersize=4) 
plt.xlabel('Prediction from model') 
plt.ylabel('Actual income')  
plt.title('R^2 = {:.3f}'.format(rSqrFull))
#The resulting plots looks accurate/reasonable, but a bit "blobby", not continuous.
#This is due to the fact that some of the variables (hours worked, years of formal schooling) are very granular
#There is restricted range and they are all integers. 