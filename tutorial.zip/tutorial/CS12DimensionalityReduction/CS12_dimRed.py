#In this session, we will explore Dimensionality Reduction methods
#As you recall, in the lecture, we did this after the classification methods.
#But there is a reason to bring it now in the code session because whereas it makes more conceptual
#sense to start with supervised learning ("we have the labels, everything is great"), it does make
#sense to start this portion of the code session with dimensionality reduction because in practice
#like when you are doing actual projects, this is usually the first step.
#We will chase this session with one on clustering and classification next week. 
#So let's start with dimensionality reduction. As you saw in the previous capstone projects - and
#this one, that is usually the very first step, right after pre-processing ("cleaning", "munging",)

#%% 0 Init - import packages
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.decomposition import PCA #This will allow us to do the PCA efficiently
from PIL import Image #These packages will allow us to do some basic
import requests #imaging of matrices and web scraping


#%% Dimensionality reduction with PCA

# Here, we will illustrate dimensionionality reduction principles with a real example. 
# That was introduced in the lecture. 
# Example: Real student evaluation data from an NYU Department in the last year.

# Issue: We ask students a lot of questions per class, so many students don't respond at all.
# So the response rate is low. 
# This is a problem due to representativeness concerns. Unless we hear at least from the majority
# of the students, the validity of this feedback is in question. 

# Suspicion: It is low because a typical student has to answer close to a hundred 
# questions per semester around finals week if they take several classes. 
# This is actually a big ask for nothing in return. There is literally no incentive for a student
# to do this. Other than "getting even with the professor".  

# Question: Can we reduce the number of questions we ask without losing any relevant information?
# To remind everyone of the underlying philosophy of PCA: Just because you ask students a lot of 
# questions about the class does not mean that they consider the class in all of those terms. 
# There might be a few underlying factors that account for all of the data. We already saw this in 
# the depression diagnostics. The Beck Depression Inventory (BDI) asks 21 questions, but upon 
# closer inspection, they break down into emotional (affective), cognitive and somatic symptoms. 
# In general, the PCA allows us to drill down into the "essence" of a dataset, ie
# 1) How many factors are the students considering when making judgments about classes
# 2) How much do these factors matter relatively to each other?
# 3) What are these factors that the students are considering? 

# Now to the code:

#%% 1) Loader
# Load questions into dataframe (Latin-1 encoding = every character fits into a byte):
questions = pd.read_csv('evaluationQuestions.csv', encoding='latin-1', header=None)

# Display the questions:
print(questions.values)

# Looking at this, we can confirm that we ask a lot of the students.
# For instance, we ask both about the course and the instructor quality.
# Whether the students can differentiate and do differentiate is an empirical question. 
# Several other questions are also very similar ("was effective at helping me learn" vs. 
# "increased my knowledge of the subject" - is there any way in which one could be true without
# the other also being true?)

#Load course evaluation data
data = np.genfromtxt('courseEvaluationData.csv', delimiter=',')

# We have data from 40 courses and 17 measures (variables) per course
print(data.shape)

#%% 2) Looking at the raw data: Exploratory data analysis (EDA)
#PCA is a pretty hard-core form of data processing. It is worth looking at the raw data first, 
#before doing that. Heavily processed data can hide many problems, much like processed food.

plt.imshow(data) # Visualize the array as an image (heatmap)
plt.xlabel('Question')
plt.ylabel('Course')
plt.colorbar() # Add color bar 
plt.show() 

# Some observations:   
# We note that there are some courses (e.g. #7 or #35) where there is very
# little variability. Those happen to be courses with very low enrollment,
# so there isn't enough data (as per CLT) to be useful. Those are also advanced seminar type classes
# that are highly self-selective. Hard to compare with mandatory intro lectures. 
# We should probably exclude them. For now, we'll keep them.

#%% 3) Compute and visualize the correlation matrix

# The reason this matters is so you can understand the output of the PCA.
# The output of the PCA will can be anticipated from inspecting the correlation matrix. 
# If there are clusters in the data here, there will be factors in the PCA
# This is true because the PCA leverages the information in the correlation matrix so heavily. 

# Compute correlation between each varible (question) across all courses:
# True = variables are rowwise; False = variables are columnwise
corrMatrix = np.corrcoef(data,rowvar=False) #Compute the correlation matrix
# Column-wise is appropriate here because we want to know how similar questions were answered
# and questions are in the columns. We are not asking whether courses are similar to each other.

# Plot the data:
plt.imshow(corrMatrix) 
plt.xlabel('Question')
plt.ylabel('Question')
plt.colorbar()
plt.show()

# Observation 1: Most variables are very highly correlated with each other
# Observation 2: There is probably going to be a 2nd factor, but that one
# will be very narrow, basically question 10
# Observation 3: There might be a 3rd factor, but it's not as clear, around
# question 6
# Observation 4: This is a symmetric square matrix, so asking for the correlation matrix
# worked and Eigendecomposition will work particularly well

#%% 4) Actually do the PCA
# In the interest of time, we'll use a function that jumps right to the result:
# The PCA module from scikit-learn (sklearn). This is defensible because that is what you
# will be using in real life. When doing this. 

# On the issue of z-scoring: The PCA works best (in fact, it assumes) that you give it data
# that is normally distributed and that different variables have equal variance. Obviously,
# that is often not the case, so we have to z-score it first. In addition, the PCA assumes
# that the data has been mean-calibrated. In other words, the mean of each variable is zero.
# If that is not the case, the results can be meaningless/disastrous. In fact, not taking
# care of this problem is the most common mistake I see. Even in relatively prestigious 
# blog posts on PCA (data science blogs). The standard way to take care of this problem
# is z-scoring. This step is often forgotten. That's actually how I can tell if someone
# who does the capstone project watched this recording or not. It's not obvious that it 
# is needed. 
  
# However, note that if you give the PCA non-z-scored data, there are two problems:
# 1) The first principal component will point to the mean (offset)
# 2) If variables have unequal variance, they won't contribute 1 to the Eigensum, which 
# means that the Kaiser criterion will not be usable. Also, the relative contribution of 
# the factors becomes hard to interpret.    
# So that is why we strongly recommend to z-score the data first. In fact, never run a 
# PCA without doing this:

# Let's first do it right, to see what the correct answer is. We will then run the 
# same PCA on the same data, but not z-scored, you will see what the issue is.
     
# 1. Z-score the data:
zscoredData = stats.zscore(data) #Subtract the mean, divide by SD, yields data with 
#mean 0 and SD = 1, in other words, z-scores. 

# 2. Initialize PCA object and fit to our data:
pca = PCA().fit(zscoredData) #Actually create the PCA object
pca2 = PCA().fit(data) #Not z-scored - oh no - don't do this. 

# 3a. Eigenvalues: Single vector of eigenvalues in decreasing order of magnitude
eigVals = pca.explained_variance_
eigVals2 = pca2.explained_variance_
# This is a single vector of the eigenvalues associated with the eigenvectors, in order
# One per eigenvector
# If we order the eigenvectors in decreasing order of eigenvalue, we call them "Principal components"
# The eigenvectors are all orthogonal to each other. 
# In other words, the eigenvector matrix forms a orthonormal base for the data.

# 3b. "Loadings" (eigenvectors): Weights per factor in terms of the original data. Where do the
# principal components point, in terms of the 17 questions? What are the coordinates of the
# eigenvectors, in terms of the original 17 variables? Colloquially: "In which directions do the
# eigenvectors point" - this is a bit hard to visualize in 17 dimensions, but it is true.
loadings = pca.components_ #Rows: Eigenvectors. Columns: Where they are pointing
loadings2 = pca2.components_ #Not mean-centered, only one factor dominates, it is pointing at the mean of each variable. Negative as it may be, but you can multiply with -1
# In other words, not mean centered, not-z-scored data will yield nonsense, if fed to a PCA. 

# 3c. Rotated Data: Simply the transformed data - we had 40 courses (rows) in
# terms of 17 variables (columns), now we have 40 courses in terms of 17
# factors ordered by decreasing eigenvalue (principal components), so this will also be
# a 40x17 matrix
rotatedData = pca.fit_transform(zscoredData)

# 4. For the purposes of this, you can think of eigenvalues in terms of 
# variance explained:
varExplained = eigVals/sum(eigVals)*100

# Now let's display this for each factor:
for ii in range(len(varExplained)):
    print(varExplained[ii].round(3))

# We note that there is a single factor (!) - something like class quality 
# or overall student experience - that explains most (~80%) of the data.
# This is a bit extreme. Don't get used to it. Solutions where the first 5 principal components
# together account for something like 60% of the variance in the data are much more common.

#%% 5) Making a scree plot

# It is up to the (data) scientist to decide how many factors to interpret meaningfully.
# All dimension reduction methods are exhaustive (loss-less), i.e. if you put 17
# variables in, you get 17 factors back. If you put 100 variables in, you
# get 100 factors back. But these are not all created equal. Some account for a
# lot more of the data than others. So some principal components matter a lot more than others.
# The fundamental question that the scree plot answers is how much each component matters and at
# what point we make a cutoff, ie "those factors don't matter enough to be considered". 

# What a scree plot is: A bar graph of the sorted Eigenvalues
numQuestions = len(questions)
x = np.linspace(1,numQuestions,numQuestions)
plt.bar(x, eigVals, color='gray')
plt.plot([0,numQuestions],[1,1],color='orange') # Orange Kaiser criterion line for the fox
plt.xlabel('Principal component')
plt.ylabel('Eigenvalue')
plt.show()

#%% 6) There are 3 criteria by which people commonly pick the number of factors.
# The idea: How many matter sufficiently to be interpreted meaningfully (as opposed to just)
# being noise. 

# 1) Kaiser criterion: Keep all factors with an eigenvalue > 1
# Rationale: Each variable adds 1 to the sum of eigenvalues. The eigensum. 
# We expect each factor to explain at least as much as it adds to what needs
# to be explained. The factors have to carry their own weight.
# By this criterion, we would report 2 meaningful factors. Generally speaking, this is
# a liberal criterion, i.e. Kaiser yields many meaningful factors
kaiserThreshold = 1
print('Number of factors selected by Kaiser criterion:', np.count_nonzero(eigVals > kaiserThreshold))

# 2) The "elbow" criterion: Pick only factors left of the bend. 
# Here, this would yield 1 factor.
print('Number of factors selected by elbow criterion: 1') #Due to visual inspection by primate
# Visual inspection is not great - next week, we will learn a better way to do that for clusters

# 3) Number of factors that account for 90% of the variance (Eigenvalues that 
# add up to 90% of the Eigensum. To account for at least 90% of the variability 
# in this data, we need 3 factors.
threshold = 90 #90% is a commonly used threshold
eigSum = np.cumsum(varExplained) #Cumulative sum of the explained variance 
print('Number of factors to account for at least 90% variance:', np.count_nonzero(eigSum < threshold) + 1)

#%% 7) Interpreting the factors - this is perhaps the step that requires the most "finesse"

# Now that we realize that 1, 2 or 3 are reasonable solutions as to how many factors to interpret 
# meaningfully, we have to do the actual interpreting. What do they mean?
# This is perhaps where (data) scientists have the most leeway.
# You do this - in principle - by looking at the loadings.
# In which direction does the principal component point? Wherever the PC points jointly (towards
# and away from) is together the "meaning" of that principal component

whichPrincipalComponent = 1 # Select and look at one factor at a time, in Python indexing
plt.bar(x,loadings[whichPrincipalComponent,:]*-1) # note: eigVecs multiplied by -1 because the direction is arbitrary
#and Python reliably picks the wrong one. So we flip it.
plt.xlabel('Question')
plt.ylabel('Loading')
plt.show() # Show bar plot
print(questions.values) # Display questions to remind us what they were
#We note that PC 2 is basically how hard a class is. 
#If we do not multiply with -1 above, the interpretation of that plot will be how "easy" the class is
#The polarity of the valence of all of the loadings is not obvious to Python. The eigenvector is the
#same whether it points in one direction or 180 degree from it. In other words, the eigendecomposition
#yields a unique solution with the understanding that the polarity is not interpretable. So you 
#have to pick one. It's the same pattern though - PC 2 is hardness, but it can also be seen as
#"not easiness". Same for PC 3 - it means "class is well organized". Because it loads highly positively
#onto those questions. If we don't multiply with -1, it would mean "class is not disorganized", which
#is the same thing. 


# Observations: 
# PC1: The first one accounts for almost everything, so it will probably point 
# in all directions at once - overall course quality?
# PC2: Challenging/informative - hardness?
# PC3: Organization/clarity: Pointing to 6 and 5, and away from the last ones - structure?

# General principle to find meaning: 
# Looking at the highest loadings (positive or negative) and looking for commonalities.

#%% 8) Finally: Visualize our data in the new coordinate system

# For instance, let's say students want to figure out which courses are
# good or needlessly hard - they can now do so, in this actionable space

plt.plot(rotatedData[:,0]*-1,rotatedData[:,1]*-1,'o',markersize=5) #Again the -1 is for polarity
#good vs. bad, easy vs. hard
plt.xlabel('Overall course quality')
plt.ylabel('Hardness of course')
plt.show()

# In this sense, PCA can help in decision making - are there some classes
# that are under/over-performing, given their characteristics?
# If we had more than 40 courses, looking at the 3rd dimension would be
# interesting too. As is, it is a bit sparse. So we will leave it at that.
# But students might have questions about the courses in the upper left quadrant
# the Dean too. This is now actionable. 

#%% 9) The SVD - another way to decompose matrices - more generally
#The singular value decomposition does not assume a square matrix, or a particular distribution
#any matrix will do.
A=np.array([[1, 2, 3], [-1, 0, 1]])
U, sigma, V = np.linalg.svd(A)
#Note: In contrast to other packages, e.g. MATLAB that returns a diagonal matrix with the singular values
#in the diagonal, Python returns a vector (!) with the singular values. If you want to reconstitute the original
#matrix with matrix multiplication, you need to put those back into a diagonal matrix. You can't just use the vector.

#%% 10) W tier: The SVD for image compression
#Why do the SVD in the first place? This question came up in the AAA. It's a good question. 
#It's most readily seen in image compression. You literally can just look at the results
#Load image as  𝑛×𝑚  matrix of [RGB] values and grayscale it so we are left with  𝑛×𝑚  matrix of pixel intensity values:

#Two ways to load the image: One locally, and one from online    
# img = Image.open('fox.jpeg') # load if image is local on your harddisk 
img = Image.open(requests.get('http://www.nwf.org/-/media/NEW-WEBSITE/Shared-Folder/Wildlife/Mammals/mammal_red-fox-kit-nebraska_william-wiley_600x300.ashx', stream=True).raw)
imggray = img.convert('LA') # convert the image to shades of gray to avoid having to deal with color
imgmat = np.array(list(imggray.getdata(band=0)), float) # convert the image to a numpy array
#At this point, this image is a list of 180000 pixels (picture element) with grey values from 0 to 255 (0 = black, 255 = white, all positive. Unsigned integers)
imgmat.shape = (imggray.size[1], imggray.size[0]) # get handle on dimensions
#Now we reconstituted the original dimensionality (300 x 600)
plt.figure(figsize=(9, 6))
plt.imshow(imgmat, cmap='gray')
#plt.grid() #This is adding grid lines
plt.show()
#In general, you can do all kinds of interesting image manipulations with Python once you have it in this format. 
#You don't need Photoshop. For instance, you could make the whole image a bit brighter by adding some number to all pixel values. Or darker. 
#Or blurrier. Or whatever. But that's for another course. 
    
#%%
U, S, V = np.linalg.svd(imgmat)
print("img: {}; U: {}; S: {}; V: {}".format(imgmat.shape, U.shape, S.shape, V.shape))

#%% Iterate over number of singular vectors and plot the reconstructed image for each value:
for ii in [2, 4, 8, 16, 32, 64, 128]:
    reconstruct_img = np.matrix(U[:, :ii]) * np.diag(S[:ii]) * np.matrix(V[:ii, :])
    print("img: {}\nU': {}\nS': {}\nV': {}".format(imgmat.shape, U[:, :ii].shape, np.diag(S[:ii]).shape,V[:ii, :].shape))
    print("Memory consumption by original image: {} kB".format(imgmat.nbytes/1000.0))
    print("Memory consumption by compressed image: {} kB".format((U[:, :ii].nbytes+S[:ii].nbytes+V[:ii, :].nbytes)/1000.0))
    print("Compression Ratio: %.3f" % (imgmat.nbytes/(U[:, :ii].nbytes+S[:ii].nbytes+V[:ii, :].nbytes)))
    plt.figure(figsize=(6, 4))
    plt.imshow(reconstruct_img, cmap='gray')
    title = "n = %s" % ii
    plt.title(title)
#    plt.grid()
    plt.show()