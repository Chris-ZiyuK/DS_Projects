#In this code session, we will explore clustering and classification
#It builds on the last code session, dimensionality reduction
#And assumes that code was run

#%% 0 Init - import packages
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_samples
from sklearn.cluster import DBSCAN
from sklearn.linear_model import LogisticRegression
from scipy.special import expit # this is the logistic sigmoid function
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

#%% 1 Clustering

# We'll use the toy example from the lecture. 
# Imagine you work for the wellness exchange
# at NYU. You want to predict who will get depressed while in college. 
# So you can allocate suitable resources. 


#%% 2a) Loader
students = pd.read_csv('mlDataset.csv')

#%% 2b) Exploring data frames

# We have used arrays to represent matrices throughout the course.
# Those work fine, but imagine we have a matrix with 100 columns 
# that represent features/attributes of the data. 

# Immediate question: What does each column actually represent?
# That's where data frames come in, as the columns are inherently labeled and allow for mixed contents (e.g. strings/numbers)

# The data frame "students" is an object. It has fields and each field for
# each member of the data frame has a value

print(students.loc[21]) # Outputs an entire row
print(students.age.loc[1713]) # Just the value of that field
studentAges = students.age # This is a series
ages = studentAges.to_numpy() # Convert to array

# Coding principle: Organisms store information with DNA. But organisms
# compute with RNA - that's what makes the actual proteins.
# Strong advice: STORE your data in data frames, as they will be inherently labeled. 
# But do your computations with arrays because they are faster/more flexible. 
# That's at least what we recommend (and do).

#%% 2c) Extract what we need from the students structure to do the job
# We're going to extract 6 predictors and 1 outcome
# For the time being, we won't extract gender because it is categorical. It
# can be used, but it complicates thing. 
# We also don't extract age because we will have a restricted age problem. 
# In general, ML methods are not magic. If the data going in has
# limitations, ML won't be able to rescue you. If the data is problematic,
# ML methods could make the situation worse. 

yOutcomes = students.depression.to_numpy()
predictors = students[["friends","fbfriends","extraversion",
                       "neuroticism","stress","cortisol"]].to_numpy()

# If this was the 20th century, we would now do classical statistics.
# Null hypothesis significance testing. But: What will that tell you you?
# You could test 6 relationships here. Say we find that mean number of
# friends is significantly different between people with or without
# depression.

# This approach can still be meaningfully done, but it tells us about the
# population, i.e. the relationship between the constructs, i.e. between
# friendship and depression.

# What do we want to know? Our question is different. Of these specific 
# students, who is likely to become depressed?
# Related: We want to use all predictors at once, for a given individual

# Taking a closer look: Are the predictors uncorrelated?
# By common sense, these variables are very unlikely to be independent

#%% 2d) To ascertain whether a PCA is indicated, let's look at the correlation heatmap
r = np.corrcoef(predictors,rowvar=False)
plt.imshow(r) 
plt.colorbar()
plt.show()

# The variables are not uncorrelated. There is a correlation structure
# The correlation structure suggests that there will be 2 meaningful.
# factors. 1-3 are correlated (1 cluster) and 4-6 are correlated (2nd
# cluster), but they are not correlated between clusters.
# The intercorrelations in one cluster are slightly higher than in
# another, so we predict that eigenvalues in 1 are going to be slightly
# higher.

#%% 2e) PCA is indicated, and we have an expectation of the results. So let's do a PCA.

# Z-score the data:
zscoredData = stats.zscore(predictors)

# Initialize PCA object and fit to our data:
pca = PCA().fit(zscoredData)

# Eigenvalues: Single vector of eigenvalues in decreasing order of magnitude
eigVals = pca.explained_variance_

# Loadings (eigenvectors): Weights per factor in terms of the original data.
loadings = pca.components_*-1

# Rotated Data - simply the transformed data:
origDataNewCoordinates = pca.fit_transform(zscoredData)*-1

# Scree plot:
numPredictors = 6
plt.bar(np.linspace(1,numPredictors,numPredictors),eigVals)
plt.title('Scree plot')
plt.xlabel('Principal Components')
plt.ylabel('Eigenvalues')
plt.show()

# Looking at the corrected scree plot, we get 2 meaningful factors, both by 
# Kaiser criterion and Elbow.

#%% 2f) Next step: Look at the loadings to figure out meaning:
plt.subplot(1,2,1) # Factor 1: 
plt.bar(np.linspace(1,numPredictors,numPredictors),loadings[0,:]) # "Challenges"
plt.title('Challenges')
plt.subplot(1,2,2) # Factor 2:
plt.bar(np.linspace(1,numPredictors,numPredictors),loadings[1,:]) # "Support"
plt.title('Support')
plt.show()

#%% 2g) Visualize our data in the new coordinate system:
plt.plot(origDataNewCoordinates[:,0],origDataNewCoordinates[:,1],'o',markersize=1)
plt.xlabel('Challenges')
plt.ylabel('Support')
plt.show() 

#%% 2h) The actual clustering - doing quantitatively what can be seen intuitively

# Clustering answers - in a data-driven way - which subgroup a datapoint belongs to.
# The "kMeans clustering" is like pca of clustering. It's not the only clustering 
# method, but it is the most commonly used one.

# Algorithm: Minimize the summed distances between a cluster center and its
# members. Once the minimum has been found (regardless of starting
# position), it stops. "Converging".

# Store our transformed data - the predictors - as x:
x = np.column_stack((origDataNewCoordinates[:,0],origDataNewCoordinates[:,1]))

#%% 2i) How many clusters k to ask for? Silhouette: 
# How close are points to other points in the cluster, vs. the neighboring cluster, to quantify
# the arbitrariness of the clustering

# Remember: each data point gets its own silhouette coefficient ranging 
# from 0 (arbitrary classification) to 1 (ideal classification).

# Init:
numClusters = 9 # how many clusters are we looping over? (from 2 to 10)
sSum = np.empty([numClusters,1])*np.NaN # init container to store sums

# Compute kMeans for each k:
for ii in range(2, numClusters+2): # Loop through each cluster (from 2 to 10)
    kMeans = KMeans(n_clusters = int(ii)).fit(x) # compute kmeans using scikit
    cId = kMeans.labels_ # vector of cluster IDs that the row belongs to
    cCoords = kMeans.cluster_centers_ # coordinate location for center of each cluster
    s = silhouette_samples(x,cId) # compute the mean silhouette coefficient of all samples
    sSum[ii-2] = sum(s) # take the sum
    # Plot data:
    plt.subplot(3,3,ii-1) 
    plt.hist(s,bins=20) 
    plt.xlim(-0.2,1)
    plt.ylim(0,250)
    plt.xlabel('Silhouette score')
    plt.ylabel('Count')
    plt.title('Sum: {}'.format(int(sSum[ii-2]))) # sum rounded to nearest integer
    plt.tight_layout() # adjusts subplot 

# Plot the sum of the silhouette scores as a function of the number of clusters, to make it clearer what is going on
plt.plot(np.linspace(2,numClusters,9),sSum)
plt.xlabel('Number of clusters')
plt.ylabel('Sum of silhouette scores')
plt.show()

# kMeans yields the coordinates centroids of the clusters, given a certain number k 
# of clusters. Silhouette yields the number k that yields the most unambiguous clustering 
# This number k is the maximum of the summed silhouette scores. 

#%% 2j) Now that we determined the optimal k, we can now ask kMeans to cluster the data for us, 
#assuming that k

# kMeans:
numClusters = 4
kMeans = KMeans(n_clusters = numClusters).fit(x) 
cId = kMeans.labels_ 
cCoords = kMeans.cluster_centers_ 

# Plot the color-coded data:
for ii in range(numClusters):
    plotIndex = np.argwhere(cId == int(ii))
    plt.plot(x[plotIndex,0],x[plotIndex,1],'o',markersize=1)
    plt.plot(cCoords[int(ii-1),0],cCoords[int(ii-1),1],'o',markersize=5,color='black')  
    plt.xlabel('Challenges')
    plt.ylabel('Support')
    
#%% 2k) Now let's move on to a different example. Here, we want to cluster the stars of
# a spiral galaxy, as seen in lecture. Enter the DBSCAN clustering algorithm.

# Load the data:
data = np.genfromtxt('spiralGalaxyData.csv', delimiter=',')
print(data[:10])

# Here, the first column is our x-coordinate, the second column is our y-coordinate,
# and the third column is which spiral it belongs to (0 or 1). For now, since we 
# are doing unsupervised learning, we will pretend we do not have the labels. Instead,
# we will use DBSCAN to find them.     

# Let's plot our data to see what they look like
plt.plot(data[:,0],data[:,1],'o',markersize=1)
plt.show()

#%% 2l) Run the DBSCAN and plot the color-coded data

# Format data:
x = np.column_stack((data[:,0],data[:,1]))

# Fit model to our data:
dbscanModel = DBSCAN().fit(x) # Default eps = 0.5, min_samples = 5

# Get our labels for each data point:
labels = dbscanModel.labels_

# Plot the color-coded data:
numSpirals = 2
for ii in range(numSpirals):
    labelIndex = np.argwhere(labels==ii)
    plt.plot(data[labelIndex,0],data[labelIndex,1],'o',markersize=1)
    
#%% 3 Finally: Classification
# First, logistic regression using the example from the lecture
# So, we will use logistic regression to predict whether a
# given applicant will be admitted to grad school based on their GRE score.

# Of course, there are other factors that determine whether someone will
# be accepted, but here we want to use GRE scores as the predictor for 
# our binary outcome--whether that person will be accepted.

#%% 3a) Load data
data = np.genfromtxt('greData.csv',delimiter=',')

#Inspect the data
print(data[:10])

print('Total number of students:',len(data))

# Admitted students descriptives:
numAdmitted = len(np.argwhere(data[:,1]==1))
avgAdmissionScore = np.mean(data[np.argwhere(data[:,1]==1),0])
admissionStd = np.std(data[np.argwhere(data[:,1]==1),0])
print('Number of admitted students:',numAdmitted)
print('Avg admitted score:',avgAdmissionScore.round(3))
print('Std admitted score:',admissionStd.round(3))

# Rejected students descriptives:
numRejected = len(np.argwhere(data[:,1]==0))
avgRejectionScore = np.mean(data[np.argwhere(data[:,1]==0),0])
rejectionStd = np.std(data[np.argwhere(data[:,1]==0),0])
print('Number of rejected students:',numRejected)
print('Avg rejected score:',avgRejectionScore.round(3))
print('Std rejected score:',rejectionStd.round(3))

# Plot data:
import matplotlib.pyplot as plt
plt.scatter(data[:,0],data[:,1],color='black')
plt.xlabel('GRE score')
plt.xlim([260,345])
plt.ylabel('Admitted?')
plt.yticks(np.array([0,1]))
plt.show()

#%% Actually run the logistic regression
# Format data:
x = data[:,0].reshape(len(data),1) 
y = data[:,1]

# Fit model:
model = LogisticRegression().fit(x,y)
    
#%% Plot the model

#Format the data
x1 = np.linspace(260,345,500)
y1 = x1 * model.coef_ + model.intercept_
sigmoid = expit(y1)

# Plot:
plt.plot(x1,sigmoid.ravel(),color='red',linewidth=3) # the ravel function returns a flattened array
plt.scatter(data[:,0],data[:,1],color='black')
plt.hlines(0.5,260,345,colors='gray',linestyles='dotted')
plt.xlabel('GRE score')
plt.xlim([260,345])
plt.ylabel('Admitted?')
plt.yticks(np.array([0,1]))
plt.show()

#%% Use the fitted model to make predictions:
testScore = 330
probGettingIn = sigmoid[0,np.abs(x1-testScore).argmin()]
print('Probability of getting accepted:',probGettingIn.round(3))

#%% 3b) Finally: Classifying depression with random forests
# First:
# Mixing in the labels Y (we know the outcomes):
X = np.column_stack((origDataNewCoordinates[:,0],origDataNewCoordinates[:,1]))
plt.plot(X[np.argwhere(yOutcomes==0),0],X[np.argwhere(yOutcomes==0),1],'o',markersize=2,color='green')
plt.plot(X[np.argwhere(yOutcomes==1),0],X[np.argwhere(yOutcomes==1),1],'o',markersize=2,color='blue')
plt.xlabel('Challenges')
plt.ylabel('Support')
plt.legend(['euthymic','depressed'])
plt.show()    

#Note: There is a trend, but the outcomes are not fully determined by these factors - there is variability

#%% Actually doing the random forest
numTrees = 100
clf = RandomForestClassifier(n_estimators=numTrees).fit(X,yOutcomes) #bagging numTrees trees

# Use model to make predictions:
predictions = clf.predict(X) 

# Assess model accuracy:
modelAccuracy = accuracy_score(yOutcomes,predictions)
print('Random forest model accuracy:',modelAccuracy)

# We are able to predict ~100% of the outcomes with this model. There are 
# close to no errors. Even the strange cases, we got. The problem is that if 
# you have results that are too good to be true, they probably are not true. 
# We committed the sin of "overfitting", due to the fact that we used the
# same data to both fit ("train") the model and test it.

# The problem is that results from overfit models won't generalize because
# some proportion of the data is due to noise. If you fit perfectly, you fit
# to the noise. The noise will - by definition - not replicate. 

# Prescription: "Don't do that". Use one set of data to build the model and
# another to train it.

# Best solution: Get new data. Rarely practical.
# Most common solution: Split the dataset. There are many ways to do this,
# such as 80/20 (at random). The most powerful - but most computationally
# expensive - is to use leave-one-out: use the entire dataset to build the 
# model, expect for one point. Predict that point from n-1 data. Do that 
# many times - at random - and average the results. 

