# CS 11: This session focuses on 
# a) Bayesian methods
# b) Power and effect size

import numpy as np # Numpy is never a bad import
import matplotlib.pyplot as plt #So we can make figures


#%% 1 Bayes Theorem:
# a) The simple form
# This code calculates a posterior p(A|B) from a "prior" p(A), 
# the "likelihood" of B given A, and the "baserate" p(B)
# p(A|B) = p(A) * p(B|A) / P(B)
prior = 0.05 #Prior probability of the event we're looking for
likelihood = 1 #In the lecture, if *every* spam message contains the keyword
baserate = 0.0625 #Prior probability of the event we know happened. This prior is known as "baserate"
posterior = prior*likelihood/baserate #Still not 1. Not = likelihood. 
print(posterior)

# Suggestion for exploration: Try different numbers for prior, likelihood
# and baserate to see how it affects the posterior. As seen in the lecture, 
# low priors are hard to turn into a meaningfully high posterior. 
# Note that the posterior probability can never be larger than 1
# So clip at 1

# Suggestion for exploration: Turn this into a function, so you have a "Bayesian calculator" 
# So this is more accessible. 

#But in practice, we rarely have the "baserate", so we usually use the "explicit form" 
#of Bayes theorem, where we replace the baserate with a term that contains just the prior 
#and the two likelihoods:
    
#%% 2 The explicit form of Bayes theorem
# This code implements the explicit version of Bayes theorem. 
# It calculates a posterior p(A|B) from a prior p(A), the likelihood of B
# given A (likelihood1) and likelihood of B given not A (likelihood2). 
# p(A|B) = p(A) * p(B|A) / ( p(A) * p(B|A) + (1-p(A)) * p(B|~A) )
# This looks scary, but we derived it in the lecture. 

prior = 0.01 #The prior probability 
likelihoodGivenA = 0.9 #The likelihood of B if A happened - if you have condition, p(test positive)
likelihoodGivenNotA = 0.25 #The likelihood of B is A did not happen - the FP rate
posterior = (prior*likelihoodGivenA)/(prior*likelihoodGivenA+(1-prior)*likelihoodGivenNotA)
print(posterior)

# Suggestion for exploration: Can you package segments 1) and 2) as 
# functions - so you have a ready made Bayesian calculator?  
# For the homework problems, you will have to calculate many of these, might be worth it

# Suggestion for exploration: Change the likelihood differential and see how the posterior
# rises - from the prior, the higher this differential is. However, be careful: 
# All of these numbers have to be between 0 and 1, as they represent probabilities.   

# Another suggestion: Also note that it is devilishly hard to raise very low priors  
# So if you are in the business of detecting rare signals (e.g. hidden weapons), you must have
# very diagnostic predictors - that are close to 1 if the condition is given and close to 0.

# The big life lesson here is that you cannot simply take the likelihood and say it is the posterior.
# You have to take the prior into account. That is perhaps the most common and most well documented
# error in quantitative judgment that one sees, even with high profile cases (e.g. medical testing).

#%% 3 Simulation: Probabilistic modeling of finding drunks in bars 
#Philosophy: Proper coding, which enables simulations saves thinking

#The most important considerations in a simulation are what has to be represented in code
#What has to be represented here is
#Whether the person is drinking on a given day
#If they are drinking, which bar they are going to

#Segment 1: What the drunk is doing
n = int(3e4) # Number of iterations - how many times are we running the simulation
#30k = average life expectancy. And we're being generous here. If someone drinks so much and spends
#their life in bars, they are likely to live considerably less long than that. It's conditional. 
proportionOfDaysDrinking = 0.9 #How often is the drinker drinking?
pDrinkingThreshold = 1-proportionOfDaysDrinking # Probability of drinking = being in a bar = this is the *threshold*
randomNumbers = np.random.uniform(0,1,n) # Draw random numbers from a uniform distribution 
#between 0 to 1. This will be used to represent their propensity to drink that day.
#We could do this with integers from 1 to 10 instead, but this allows for better granularity
barAttendance = np.zeros([n,3]) # Initial state of the bars, with 0s, as they represent 
#(is not at this bar - the drunk will be at the bar, if they go to this bar). 
#Initially, the drunk is at home. So the bars are empty (of the drunk)
for ii in range(n): #Go through all cases
    temp = randomNumbers[ii] #Pick the iith random number out of the array, assign it to temp
    #temp is ok here, because we don't do anything with it per se. We just use it as a way point
    #to determine if they are drinking that day or not
    if temp > pDrinkingThreshold: # Determine if he is drinking on a given day. 
    #If the random number at index ii is larger than the threshold, 
    #we determine that they are in fact drinking. So now we need to figure out which bar they attend.
    #Only if they are drinking, we have to determine where they are going. If they are not drinking, 
    #they don't go to the bar.
    #Remember from the problem prompt in the lecture: They determine at random which bar to go to. 
    #So we have to emulate this random process here
        temp2 = np.random.randint(3) # draw random integer from 0 to 2. In a better world, we would
        #also make the number of bars a variable. But here, let's stick with 3, for simplicity.
        if temp2 == 0: # If temp2 is 0, then go to bar 1
            barAttendance[ii,0] = 1 #Change the bar state of bar 1 from 0 to 1. 
            #If they are there, they can be found there.
        elif temp2 == 1: # If temp2 is 1, then go to bar 2
            barAttendance[ii,1] = 1 #Change the bar state of bar 2 from 0 to 1. 
            #If they are there, they can be found there.
        elif temp2 == 2: # If temp2 is 2, then go to bar 3
            barAttendance[ii,2] = 1 #Change the bar state of bar 3 from 0 to 1. 
            #If they are there, they can be found there.
            
#%% After running the code in the previous segment, we now have sata from a large 
# number of days, representing which bar they ended up in, if any of them.
# In fact, we should just do 30,000 days because that's the average life expectancy. 
# We would be simulating the entire life of the drinker. 1 million days is overkill. 
# This allows us to implement the idea that the prior gets constantly updated with 
# new information, as we don't find the drunk in bars.
# In other words, we now need to represent the situation (as per problem prompt)
# of not finding the drunk in 2 out of the 3 bars, and if that is the case, count how often
# they are in the last one, in those situations.

# In other words, in addition to representing the actions of the drunk 
# - which we did in the code block above
# We now need to also represent the actions of the social workers. 
# I recommend to separate the two logically. 
# Segment 2: What the social workers are doing

howManyTimesNeedToCheckLastCounter = 0 #Initialize a counter - keep track of how many times the 
#drunk was not in the first 2 bars. Only in those case, does the last bar need to be checked.
howManyTimesFoundInLastBarCounter = 0 #Initialize another counter - keep track of how many times 
#the drunk was found in the last bar if they were not in the first 2
for ii in range(n): # Sequentially checking the bars, day by day and bar by bar. 
#Keeping track of where the individual was located
    if int(sum(barAttendance[ii,0:2])) == 0: # If he is not in the first two bars 
    #(remember that the indexing range is *not* inclusive). So this checks whether the sum of the
    #first two elements of the vector that represents the bar attendance is 0 or not. If it was not
    #zero, he was in one of the first two bars (doesn't matter which one)
        howManyTimesNeedToCheckLastCounter = howManyTimesNeedToCheckLastCounter + 1 
        #Number of times this happened - they went to the first 2 bars and didn't find him there 
        #So every time the condition is met, we increment this counter by 1
        #Importantly, we initialized it with 0 (as 0) before the loop. 
        howManyTimesFoundInLastBarCounter = howManyTimesFoundInLastBarCounter + barAttendance[ii,2] 
        #Number of times they were in the last bar. That's why it was good to represent the state
        #of the bar with 0s and 1s. If the drinker is not in the last bar, we add a zero here, if 
        #he is (and only if that is the case), we increment this counter
probabilityBeingInThirdBarIfNotInFirstTwo = howManyTimesFoundInLastBarCounter/howManyTimesNeedToCheckLastCounter #Literally just a proportion, as per definition of probability
print('Probability of being in the last bar, if *not* found in first 2:',probabilityBeingInThirdBarIfNotInFirstTwo)  

#Suggestion for exploration: 
#See how this number changes if there are more bars (e.g. if there are 100 bars)
#Or if the drunk drinks on more or fewer days - by changing the threshold          
            

#%% 4 Simulation: p-values as a random variable 
#(and their distribution as a function of effect size and power)
# As seen in the lecture. The "p-curve"
# Contrasting true vs. false null hypothesis (H0)
# True null: try 0 for mean difference
# False null: try 0.1, 0.25, 0.5 and 1 for mean difference

# In case stats wasn't already imported
from scipy import stats
import numpy.matlib # to use repmat 


# Initialize variables:
sampleSize = 200 # This is our sample size - representing power - we will play with this in a moment
numReps = int(1e4) # Number of repetitions in our simulation. For teaching purposes, this is ok.
numBins = 23 #How many bins in our histogram
meanDifference = 0.5 # We'll be comparing two means. This will effectively be a measure of effect size
alpha = 0.05 # Significance threshold. 


# Randomly draw numbers from a standard normal distribution to create the sata:
# The good news is that if we draw from a standard normal distribution, 
# the unit of mean difference is basically d. So we don't have to worry about the denominator 
# This would generalize to other distributions, but is more complicated    
sata1 = np.random.normal(0,1,[sampleSize,numReps]) #This is our - simulated - first sample
#We do that sampleSize times numReps times. Drawing from the standard normal for sample 1.

# Our 2nd sample. Same distribution, different mean:
sata2 = np.random.normal(0,1,[sampleSize,numReps]) + meanDifference
#Again, we draw sampleSize times numReps times from a standard normal distribution. 

# Independently. So the question is: Can an independent samples t-test detect this mean difference?
# Of course, if the effect size (the mean difference) is actually 0, the null hypothesis is true, 
# so all significant results represent / indicate that by chance, the significance threshold was
# exceeded and if we use that as a decision criterion, this will be a false positive or type I error
# Let's see how often that happens.    

# Run a t-test, a lot of times (numReps, to be precise):
t = np.empty([numReps,1]) # initialize empty array for t
t[:] = np.NaN # then convert to NaN
p = np.empty([numReps,1]) # initialize empty array for p
p[:] = np.NaN # then convert to NaN
for ii in range(numReps): # loop through each repetition 
    t[ii],p[ii] = stats.ttest_ind(sata1[:,ii],sata2[:,ii]) # do the t-test for each repetition
    
# Plot the p-values from the numReps t-tests we did:
plt.hist(p,numBins)
plt.xlabel('p-value')
plt.ylabel('frequency')
sigs = p<alpha #Determine significance
sigs = 1*sigs #Convert to ints
proportionSig = sum(sigs)/len(sigs) #Proportion of significant results. If the effect is non-zero, this is the statistical power to detect it

print('Min p-value:',np.min(p))
print('Max p-value:',np.max(p))
print('Proportion of significant p values:',proportionSig[0])

#As we can see, if the null hypothesis is true, the proportion of p-values that
#is less than alpha is about 5%
#That is the idea - if there is no effect, rejecting the null hypothesis if
#the p-value is less than alpha gives us 5% false positives
#Impressively, Fisher's logic holds. And he did not have a digitical computer to figure this out. 

#Also, we can see that under these conditions (H0 = true), p-values are distributed uniformly 

#If you have a large effect size, e.g. d = 1, AND a large sample size, 100% power is attainable. 
#Not without reach. Also, real p-values are quite small, not anywhere near 0.05.
 
#Insight: If you do have large n, even tiny mean differences are easily detectable
#by - effectively - all p-values being close to 0, much lower than alpha

#But you need a lot of power to detect subtle effects reliably. 
#Counterintuitively, dropping effect size drops powers a lot more than increasing sample size
#raises it. 



#%% 5 Simulation: The relationship between mean differences, effect sizes and significance
# Effect sizes as salvation?
# Central take home message: The same p value can correspond to dramatically
# different effect sizes.
# So the point of this excursion/simulation is that a p-value can NOT be interpreted as a proxy
# for effect size. That's another common mistake. A lot of people say that "our p-value was so low,
# so our effect size must have been large." - that is not true. What this simulation shows is that
# p-values map onto effect sizes in a very complex fashion. It is not one to one or straightforward
# or even linear. Too many other things go into that. 

# A. Initialize variables:
numReps = 500 # Number of repetitions in our simulation
sata = np.empty([numReps,3,2]) # Initialize empty 3D array for sata
sata[:] = np.NaN # then convert to NaN 
PvsE = np.empty([numReps,5]) # Initialize empty 2D array for PvsE
PvsE[:] = np.NaN # then convert to NaN

# B. Generate and analyze sata:
for ii in range(numReps): # loop through each rep
    p = 0 # set p to 0 to initialize
    while abs(p - 0.04) > 0.01: # Find datasets that are just about significant
        temp = np.random.normal(0,1,[3,2]) # Draw n = 3 (mu = 0, sigma = 1), again from standard normal
        t,p = stats.ttest_rel(temp[:,0],temp[:,1]) # paired t-test
    sata[ii] = temp # store temp in sata array
    
    # sample size:
    PvsE[ii,0] = len(sata[ii,:,:]) # Capturing sample size of the iith run, in the first column of
    #the PvsE container, by taking the length of the z-stack dimension
    
    # significance level:
    t,p = stats.ttest_rel(sata[ii,:,0],sata[ii,:,1]) # paired t-test
    PvsE[ii,1] = p #Capturing p of the iith run, put it in the 2nd column of the PvsE container
    
    # effect size (computing cohen's d by hand to take standard deviation into account):
    mean1 = np.mean(sata[ii,:,0]) # mean of sample 1
    mean2 = np.mean(sata[ii,:,1]) # mean of sample 2
    std1 = np.std(sata[ii,:,0]) # std of sample 1
    std2 = np.std(sata[ii,:,1]) # std of sample 2
    n1 = len(sata[ii,:,0]) # size of sample 1
    n2 = len(sata[ii,:,1]) # size of sample 2
    numerator = abs(mean1-mean2) # absolute value of mean difference
    denominator = np.sqrt((std1**2)/2 + (std2**2)/2) # equation for the pooled std
    d = numerator/denominator #Calculating d explicitly
    PvsE[ii,2] = d #Capturing d of the iith run, put it in the 3rd column of the PvsE container
    
    # mean differences:
    PvsE[ii,3] = abs(np.mean(sata[ii,:,0]) - np.mean(sata[ii,:,1]))
    #Also capture the actual the actual mean difference in the 4th column
    
    # pooled standard deviation:
    PvsE[ii,4] = np.sqrt((std1**2)/2 + (std2**2)/2) #And the pooled SD in the 5th column
    
# C. Plot slices of one vs. the other (of these), to show what is going on:
plt.subplot(2,3,1)
plt.hist(PvsE[:,1],numBins)
plt.title('p value')
plt.subplot(2,3,2)
plt.hist(PvsE[:,2],numBins)
plt.title('cohens d')
plt.subplot(2,3,3)
plt.hist(PvsE[:,3],numBins)
plt.title('mean diff')
plt.subplot(2,3,4)
plt.hist(PvsE[:,4],numBins)
plt.title('pooled sd')
plt.subplot(2,3,5)
plt.plot(PvsE[:,2],PvsE[:,3],'o',markersize=.5)
plt.xlabel('cohens d')
plt.ylabel('abs mean diff')
plt.subplot(2,3,6)
plt.plot(PvsE[:,2],PvsE[:,4],'o',markersize=.5)
plt.xlabel('cohens d')
plt.ylabel('pooled sd')

#Now for what matters - does p directly map to d?
plt.plot(PvsE[:,2],PvsE[:,1],'o',color='black',linewidth=2)
plt.xlabel('cohens d')
plt.ylabel('p')

#To interpret p-values as a marker of effect size (d), it does matter whether
#d is low because the mean difference is low or because the pooled SD is high.
#d mixes the two together, so we can't actually know. 
#So be careful, d doesn't straightforwardly map onto mean difference and therefore, 
#p doesn't map on to actual effect size. 


#%% 6 Flexible stopping - the p-value *always* gets below alpha, eventually. 
#Just by flexible stopping alone.
#This is the weaponization of sampling error for bad ends - to pursue careerist goals 
#that disregard or even hurt society by proxy.
#Publishing false positives helps your career in the short term. But it is bad for everyone else.
#It might even be bad for you, when you're eventually caught
#(and spent your entire career publishing noise)
#Flexible stopping is just one - very common - example of p-hacking. 
#Targeted "Outlier" removal and HARKING are commonly used other examples. 
#Very sad. 


# Init:
n = 5 # Starting n - here, 5 - that's the starting number of units of analysis in the sample
p = 1 # Starting p - value - let's say 1 - you could start at some random number. 
#But this is just to initalize at the "worst" case for the researcher. We initialize with the worst
#case. p is far from alpha. As far as it can be. [Should ask in hw: Can it be farther away?]
alpha = 0.05 # What is our alpha level? 0.05 is standard, still. Fisher still sets the standard
smartCheating = 0 # If this is 0, we only flexibly stop. If this is 1, we don't just flexibly stop, 
#we also drop people,  if they increase the p-value. 
#Both together are devastating, and that's not even removing outliers.
#In fact, this is so effective that we need to consider a 3rd case: 2 - in this case, we do a version
#of the last case, but only sometimes. When it matters most. "Smart cheating".
nCont = np.array([]) # Initialize the container that will hold our ns 
pCont = np.array([]) # And one for the corresponding p-values
data = np.random.normal(0,1,[n,2]) # %Randomly draw data from n people from a normal distribution,
# in both conditions, like for an A/B test. Note that there is no effect here. Just randomness.
# We draw 2 columns directly from a standard normal. So on average, there is no mean difference. 
# As both are drawn from the standard normal distribution. Should there be one, it is due to 
# sampling error alone (it can happen).
# Given that, how many p-values should end up significant (below alpha), without cheating?
# As seen above:
# 5% of them. By chance. We can live with that. More generally: Alpha*100 percent  
# But what if we run a t-test *every time* we add a new pair of participants? 
# Does that change things? 
# Let's run a simulation to find out:

# Run simulation:
while p > alpha: # As long as the p-value is not significant yet. We keep doing this. 
#The moment p drops below alpha, we stop, so we need a while loop
    t,p = stats.ttest_ind(data[:,0],data[:,1]) # Do a t-test on the data, columns = A vs. B
    nCont = np.append(nCont,n) # Capture the n for this test 
    pCont = np.append(pCont,p) # And the corresponding p-value
    #Note: We did not pre-initialize nCont and pCont with a certain size. 
    #Because we don't know how long it will take to drop below alpha. 
    #In cases like that, if you must use a loop, don't pre-initialize a size.
    #However, the "append" method is very slow, as the chunks in memory we are looking for get 
    #bigger and bigger
    #Copying them around in memory takes a lot of time

    if smartCheating == 0: # Flexible stopping only
        data = np.concatenate((data,np.random.normal(0,1,[1,2])),axis=0) 
        #Then add data from 1 (one) new participant to the dataset, one per condition, so a pair
    #Note: Concatenate is also very slow, if used over and over again, 
    #because you have to find a bigger chunk of memory and copy the data there, all the time   
    #So the larger the sample size is, the longer this will take
    elif smartCheating == 1:
    #Flexible stopping by itself can be a bit tedious. What if we only 
    #accept new data if it "helps" us?     
        tempP = 1  # Initialize a new p-value - temporary, just for now    
        while tempP > p: # While our new p is larger than our old p
            tempData = np.concatenate((data,np.random.normal(0,1,[1,2])),axis=0) 
            # Same as before: Try new people until they lower our p-value. 
            # Rationalization: Obviously, there is something wrong with those who don't help our p-value
            t,tempP = stats.ttest_ind(tempData[:,0],tempData[:,1]) # Do a t-test on the stop with the provisional new data, 
            #if they make our p-value worse, we won't even enter them into the dataset
            #That's why we call it a temporary p-value
            break #If we found one that lowers it:
        data = np.concatenate((data,tempData),axis=0) # Add them to the dataset if (and only if) they lower the p-value
    elif smartCheating == 2:
    #This was a little bit too effective, what if we pull back a little from that, to make it 
    #more plausible?     
        tempP = 1  # Initialize a new p-value - temporary, just for now    
        while tempP > p: # While our new p is larger than our old p
            tempData = np.concatenate((data,np.random.normal(0,1,[1,2])),axis=0) 
            # Same as before: Try new people until they lower our p-value. 
            # Rationalization: Obviously, there is something wrong with those who don't help our p-value
            t,tempP = stats.ttest_ind(tempData[:,0],tempData[:,1]) # Do a t-test on the stop with the provisional new data, 
            #if they make our p-value worse, we won't even enter them into the dataset
            #That's why we call it a temporary p-value
            break #If we found one that lowers it:
        data = np.concatenate((data,tempData),axis=0) # Add them to the dataset if (and only if) they lower the p-value        
    n = n + 1 # Update the n accordingly (we could simply get it from length(n), but whatever)
    
    if n > 1e4: #If it simply runs too long due to being unlucky
        break #Break the loop
    #This is not something we have to do. Eventually, the p-value *will* drop below alpha, it might
    #just take a hundred thousand participants or more. Due to the considerations above, we simply
    #don't have the time in a teaching lab to wait for that. But it would happen. So we put a break
    #in, in case the researcher gets "unlucky", and sampling error doesn't cooperate.         

# Plot the data:
plt.plot(nCont,pCont,color='red',linewidth=0.5)
plt.plot(nCont,pCont,'o',color='black',markersize=2)
plt.xlabel('Participants')
plt.ylabel('p')
plt.xlim(5,n)
plt.plot([5,n],[alpha,alpha],color='black',linewidth=0.5,linestyle='dashed') # draw decision threshold (significance level) as a line
plt.title('Final p-value = {:.3f}'.format(p))

#One note about the "enhanced" flexible stopping that only accepts new data if it helps: That's a
#little bit too effective - yields significance 100% of the time, with only a few participants. 
#So that's a little bit too obvious. It would imply that all the effects we are testing are like 
#d = 2 or 3. Some PIs might be very happy about this. It implies they are studying something big. 
#But most would probably be a bit suspicious. Most scientists study subtle interventions, not on the
#order of the average male vs. female height. So what most do is probably "smart cheating", in other
#words accept the new data only if it doesn't make the p-value a lot worse. That would be devastating
#because you would get significance for sample sizes around 50, but each time. Which is what you
#see most commonly in the actual literature. So the actual published scientific literature is most
#consistent with "smart cheating". Which is not surprising, because the people doing this are smart.

#We know that there is no effect of what we're looking for because it came from a normal distribution 
#with no mean difference
#That means there is no effect of what we're looking for in reality.
#And yet, if we draw 1 participant at a time, then test, and then stop immediately
#if we get significance (and can publish)
#what do these significant results represent? They are all false positives. 
#All of them.
#Do they happen at a rate of 5%? If we are patient enough, they happen at a rate of 100%
#Hence p-hacking. The researchers found a way to publish even if the effect is not there. 
#This is problematic because society relies on the results of scientific research to be reliable. 
#If science says something is effective, it better be effective.

#Also note that the final p-value ends up just below alpha, which is a tell-tale sign 
#that something like this was done
#As we saw before, "real" p-values are close to 0, if the study is adequately powered.

#The mechanism that drives all of this is sampling error 
#(as is the case for real data from the same population)
#We use sata here, so we KNOW that there is no effect, it is all sampling error
#But if what gets you significance is sampling error only, 
#you do have to stop immediately if you finally get significance
#because if you don't, you're running the risk of going back up above alpha again.

#Is it now clear what p-hacking is, and why science as the "cult of significance" is problematic?
#Obviously, I'm showing this to you here so that you
#a) Realize it is is possible and effective
#b) Recognize the tell-tale signs if you see it in the wild
#c) Never, ever do this yourself. Ever. Please. There is no point in making research less reliable. 


#%% W tier: Funnel plots - these are a meta-analytic tool. 
# Plotting effect size vs. power - probability of a hypothesis test of finding 
# an effect if there is an effect to be found

# As you increase power, the effects cluster around the "real" effect
# If you run low-powered studies, you will be at the bottom of the funnel and
# your effect sizes will jump all over the place. 
# That is also why only a priori power is real power. If you estimate power post hoc
# the effect size estimate is also affected by large sampling error (logically)

# Initialize variables:
sampleSize = np.linspace(5,250,246) # We vary sample size from 5 to 250
effectSize = 0 # The real effect size
repeats = int(1e2) # In reality, you would do many more than that
meanDifference = np.zeros([repeats,len(sampleSize)]) # preallocate

# Calculations:
for r in range(repeats): # loop through each repeat
    for ii in range(len(sampleSize)): # loop through each sample size
        tempSample = int(sampleSize[ii]) # what is our n this time?
        temp = np.random.normal(0,1,tempSample) + effectSize
        temp2 = np.random.normal(0,1,tempSample)
        meanDifference[r,ii] = np.mean(temp) - np.mean(temp2)
        
# Learning effect: Larger n will converge to real effect
# Lower n allows fishing for noise. Instead of doing 1 high powered
# experiment, n = 250, do 10 n = 25 experiments and publish the one
# that becomes significant. Brutal.

# To save time, let's linearize that:
linearizedMeanDiff = np.ndarray.flatten(meanDifference) 
temp = np.matlib.repmat(sampleSize,repeats,1) 
linearizedSample = np.ndarray.flatten(temp)

# Now we can do the funnel plot:
plt.plot(linearizedMeanDiff,linearizedSample,'o',markersize=.5)
plt.xlabel('Observed effect size')
plt.ylabel('Sample size')

#A priori vs. post-hoc power:
#Instead of running 1 adequately powered study at - say - 200 participants
#showing that there is no effect (good luck publishing that). 
#You could run 10 underpowered studies at 20 participants, then count on sampling
#error leading to wildly varying observed effect sizes, and publish the 1 study
#that was significant at that low sample size. And put the other ones in the 
#"file drawer". This is called publication bias. It makes interventions look more
#effective than they are. Telltale sign: Wildly inconsistent effect size estimates
#between studies. It means you are at the bottom of the funnel. 
#Much of the published literature demonstrably looks like that. 
#If you are interested look at what I put on the W tier materials on this. 

     

#%% W tier 2: Simulation: Powerscape
# See: https://blog.pascallisch.net/brighter-than-the-sun-introducing-powerscape/
# This is now basically *all* of the p-curves from 4) superimposed in a 2D plot
# where color is representing the 3rd dimension - the proportion of significant 
# results. 

# Initialize variables:
popSize = int(1e3) # Size of the population
nnMax = 250 # Maximal sample size to be considered
nnMin = 5 # Minimal sample size to be considered
sampleSize = np.linspace(nnMin,nnMax,246) # array of each sample size
effectSize = np.linspace(0,1.5,31) # From 0 to 1.5, in .05 increments
# As std is one, effectSize will be in units of std
pwr = np.empty([len(sampleSize),len(effectSize)]) # initialize power array
pwr[:] = np.NaN # then convert to nan

# Run calculations:
for es in range(len(effectSize)): # loop through each effect size (31 total)
    A = np.random.normal(0,1,[popSize,2]) # Get the population of random 
    # numbers for each effect size - 2 columns, 1000 rows
    A[:,1] = A[:,1] + effectSize[es] # Add effect size to 2nd column/set
    for n in range(len(sampleSize)): # loop through each sample size
        mm = int(2e1) # Number of repeats
        significances = np.empty([mm,1]) # preallocate
        significances[:] = np.NaN
        for ii in range(mm): # Do this mm times for each sample size
            sampInd = np.random.randint(0,popSize,[n+5,2]) # subsample
            # we add 5 to n because n is indexed at 0 but our min n is 5
            drawnSample = np.empty([n+5,2]) # initialize empty
            # drawn_sample starts as 5x2 and with each iteration adds one row
            drawnSample[:] = np.NaN # convert to NaN
            drawnSample[:,0] = A[sampInd[:,0],0] 
            drawnSample[:,1] = A[sampInd[:,0],1]
            t,p = stats.ttest_ind(drawnSample[:,0],drawnSample[:,1])
            if p < .05: # assuming our alpha is 0.05
                significances[ii,0] = 1 # if significant, assign 1
            else:
                significances[ii,0] = 0 # if ~significant, assign 0
        pwr[n,es] = sum(significances)/mm*100 # compute power
        
#% Plot it:

fig = plt.pcolor(pwr) #create a pseudocolor plot with a non-regular rectangular grid
# color = percentage of significant effects

plt.xlabel('real effect size (mean diff in SD)')
plt.ylabel('sample size (n)')
plt.title('powerscape t-test') # color represents proportion significant effects
plt.magma() #Sets color map
plt.colorbar() #Adds color bar legend on the right

#Add the correct x tick labels:
tmp = fig.axes.get_xticks() #Get the tick labels
tmp = np.ndarray.astype(tmp,'int') #Convert to integers, so it can be used as an index
fig.axes.set_xticklabels(effectSize[tmp[0:len(tmp)-1]])    

plt.show() #Show figure


     


