#In this session, we will start to explore how we can make predictions from data.
#This session is divided in several parts. The first part is the "how to" part - it will
#teach you how to do certain critical tasks that are important to do the assignments.

#Today these tasks are divided into simple linear regression, then linear regression with control.
#After that, there is a part focused on understanding/"why" something is the case, implementing some
#of the concepts from the lecture in the lab ("proof per python", simulations).

#Part A: How to make predictions (necessary skills to do the course assignments)

#%% 0. Initialization - anticipating the libraries we will need for this lab
import numpy as np #Always good to be able to do linear algebra
import matplotlib.pyplot as plt #Always good to be able to make plots
from sklearn.linear_model import LinearRegression # We'll use the regression functions 
#of this scientific computing package today. In general, sklearn is full of that kind of thing

#%% 1. Can we predict annual income from IQ? 
#[From now on, we are in the business of answering questions, with data]

#a) Load data:
data = np.genfromtxt('iqIncome.csv',delimiter=',') # Column 1 = IQ, 2 = income in k$/year. 
#If this fails, make sure you are in the right file path (upper right)

#b) Do exploratory data analysis by first computing descriptives:
varMeans = np.mean(data,axis=0) # take the mean of each column
varMedians = np.median(data,axis=0) # take the median of each column
varSD = np.std(data,axis=0) # take the SD of each column
varCorrs = np.corrcoef(data[:,0],data[:,1]) # Calculate the correlation matrix (pearsons r) between the variables
#These are the summary statistics in our dataset we care about.

# Remember: we know that for IQ the *population* distribution is mu = 100 and 
# sigma = 15. Confirm that this is approximately true, for our sample.
# If there is a strong deviation from the population expectation, we might be dealing
# with sampling bias, more on this next week (where we cover formally what the relationship
# between sample and population is, and how we quantify what a "large deviation" is). 
# For now, we note - and are pleased - that the means somewhat conform to expectations. 

# Then plotting the data, which concludes our EDA, for now
plt.plot(data[:,0],data[:,1],'o',markersize=5, color='black') #Remember: Fields are not in quotes, 
#attributes are. Unless the attributes are numbers
plt.xlabel('IQ in points') #Remember to label your axes. 
#Be specific (what does this axis represent, with units)
plt.ylabel('Income in k$/year')  #That goes for the y-axis as well
#Otherwise, this could be a plot of anything - they all look kind of similar - could be stars
#For EDA, this labeling axes part can be a bit casual (because you - who did the analysis 
#know what you are looking at). But as soon as there is a 3rd party involved - someone looking at 
#your figure who was not involved in the analysis, be as specific as possible. 
#And this is the most common case (reports, papers, etc.)

#%% 2. Doing simple linear regression (SLR) by "hand" (code, but step by step)

# Comment convention: I'll say what is going on in a paragraph before the code. 
# I'll add a comment inline (after the code) that explains what the line does/represents
# How much of this you want to maintain for your own coding practice depends on how good
# your memory is / how well you understand code. But for teaching purposes, I'm keeping it.

# Initialize container:
# Usually the data comes in, in some raw form that needs to be reformatted to be useful. 
# Today, this step is minimal, but next week, we will see how essential it is    
# It's a good habit to first explicitly represent your data in a form you will need.
regressContainer = np.empty([len(data),5]) #We initialize an empty data structure "regressContainer"
# so that it has the right shape (=1000 rows, 5 columns)
regressContainer[:] = np.NaN #Once the shape has been set, populate it with "nans", 
#which is our code for missing data (so far), 
#you could also leave it empty, or use 0s, 
#but nan is usually the best choice, unless otherwise specified. Sometimes, 0 is better

# Compute each component for our SLR (OLS) equation:
# Just to be clear: For reasons of time complexity, avoid loops whenever possible, when writing
# production level code. So why are using so many loops here? 
# Because it is easier to see what is going on. 
# My usual workflow is to *develop* the code logic with a loop, 
# then vectorize it later - in *production* for speed. 
# We will practice this. But not today.
       
for ii in range(len(data)): #Go through all of the cases
    regressContainer[ii,0] = data[ii,0] # IQ of an individual person (=row)
    regressContainer[ii,1] = data[ii,1] # income of an individual 
    regressContainer[ii,2] = data[ii,0]*data[ii,1] # IQ * income of an individual
    regressContainer[ii,3] = data[ii,0]**2 # IQ squared of an individual 
    regressContainer[ii,4] = data[ii,1]**2 # income squared of an individual 
    
# See the regression equation for context, if you want to understand what is going on here, 
# There are free links all over the web, e.g. here
# https://www.statisticshowto.com/probability-and-statistics/statistics-definitions/what-is-a-regression-equation/ [scroll down]    
# or here:
# https://byjus.com/maths/linear-regression/    
    
n = len(data) #Sample size - in general, we want to call the sample size "n"    
# Compute m ("slope"): [m because that is the generic line equation slope]
mNumerator = n*sum(regressContainer[:,2]) - sum(regressContainer[:,0])*sum(regressContainer[:,1])
mDenominator = n*sum(regressContainer[:,3]) - (sum(regressContainer[:,0]))**2
m = mNumerator/mDenominator

# Compute b ("y-intercept"): [again, b is the nomenclature from the generic line equation]
bNumerator = sum(regressContainer[:,1]) - m * sum(regressContainer[:,0])
bDenominator = n
b = bNumerator/bDenominator
rSquared = varCorrs[0,1]**2 

# Add the regression line to visualization:
plt.plot(data[:,0],data[:,1],'o',markersize=3) 
plt.xlabel('IQ') 
plt.ylabel('income')  
yHat = m*data[:,0] + b # slope-intercept form, y = mx + b
plt.plot(data[:,0],yHat,color='orange',linewidth=3) # orange line for the fox
plt.title('By Hand: R^2 = {:.3f}'.format(rSquared)) # add title, r-squared rounded to nearest thousandth

#%%

#There are several equivalent statistical formulations that all yield the same slope and intercept.
#Some reuse the summary statistics we already calculated, so this could be efficient:

slope = (varCorrs[0,1] * varSD[1])/(varSD[0]) #This is basically straight from the lecture  - r * sd(y) up for every sd(x) over     
intercept = varMeans[1] - slope*varMeans[0] 
#Compare slope with m from above and the intercept with b - they are the same

#This can also be done with a combination of summary statistics and loops.
#For instance as per this derivation: https://www.colorado.edu/amath/sites/default/files/attached-files/ch12.pdf
#The end result is yet again equivalent:

#Slope    
ssNum = 0   #Initializing sum of numerator deviations
ssDenom = 0 #Initializing sum of denominator deviations

for ii in range(len(data)): #Go through all of the rows
    ssNum = ssNum + (data[ii,0]-varMeans[0])*(data[ii,1]-varMeans[1]) #Calculating SS of numerator deviations   
    ssDenom = ssDenom + (data[ii,0]-varMeans[0])**2 #Calculating SS of denominator deviations

yetAnotherSlopeEstimate = ssNum/ssDenom #Still the same value as above

#Using the slope to compute the intercept
yetAnotherInterceptEstimate = (sum(data[:,1]) - yetAnotherSlopeEstimate * sum(data[:,0]))/len(data)

#Using only summary stats and previously computed parameters (slope) to compute the intercept:
equivalentIntercept = varMeans[1] - yetAnotherSlopeEstimate * varMeans [0] #Still the same number


#%% 3. Now that we understand how single linear regression works under the hood, 
#we can use a function and see if it yields the same outcome. 
#If it does, we can use the function going forward.
#There is a good reason for both of this. 
#First for doing it by hand without using a "black-box" function. 
#The reason to use a function going forward, once you understand the steps involved is that the 
#functions provided in standard libraries like sklearn or scipy or numpy are
#highly optimized for speed. And it's one line, not all of the above.


# Initialize data:
x = data[:,0].reshape(len(data),1) #The function expects the predictor data in *column* form. 
#So we explicitly declare a column here
y = data[:,1] #We wouldn't have to rename them "x" and "y", but we do it anyway, 
#because that is convention. So if someone looks at your code, they won't need a comment to 
#understand what "x" and "y" represents. It's in the name.
#The x's will soon be multiple predictors, so *every* column of that prediction matrix X will 
#be a variable. But at least for now, our outcomes are always a single variable
#So right now, y is a single dimensional array (this is a Python specialty - not true for Matlab, 
#R or Julia). And the regression function will accept this because it expects a single dimensional
# output. However, if you feel better about making it explicit, do so. 
#In general, if you use conventions throughout, and gets used to using them, 
#you will be able to get away with fewer comments.
#It also makes it easier for other people to read your code. 

#Aside, making things explicit:
a = data[:,0] #Not a column vector because in Python, single dimension assignments are neither 
#row nor column vectors, they literally don't have a second dimension
a.shape
#To make a long story short, Python will let you get away with this - where you have a one-dim
#vector. It's like a magnetic monopole. It's neither row nor column. But if your function expects
#a column vector, you have to explicitly make it so. And we use reshape for that. 
b = data[:,0].reshape(len(data),1) #A column vector
b.shape 
#Also, sometimes reshape might coincide with transpose. 
#For instance, if you know you have a row vector and want a column vector
#However, I would not count on that always being the case

# Create and then fit the model to data:
# Remember that we imported linear regression from sklearn. It has many methods. 
# The key one - by which every "optimization" (the sklearn perspective on regression) works 
# is the "fit" method. "Fit" means curve fitting. Of a curve to data. 
# The "curve" we fit today is a simple line. A line has two free parameters - a slope and an
# intercept. The best value of those two parameters - that fit the data the best - is gotten from 
# the data. Specifically from the set of values that minimizes the squared distances between the
# data and the line.  
# Take the x/y input/output pairs and find the parameters of best fit. Those characterize our model 
# Step 1: Building the model: 1 line in Python
ourModel = LinearRegression().fit(x, y) #We could call this anything. 
#I called it "ourModel". It's an object, it will contains lots of useful information 

# Step 2: Inspect the model and make sure it makes sense 
#[Once you have validated your approach, you might be able to skip this step]
rSq = ourModel.score(x, y) # Score = r^2 Note that this is the same as by hand!
slope = ourModel.coef_ # Coeffient = b1. If you have more predictors, there will be more coefficients (one for each).
#Same as before (slope)
intercept = ourModel.intercept_ # And B0 (intercept)
#We now saw that from the function that I recommend you to use going forward gets the same result
#as doing it "by hand" (step by step)

#Now that we built the model, we can move on. "Fit" builds the model. We decided on the following:
#1) The predictor to use (x = IQ)
#2) The outcome to use (y = income)
#3) The curve to use (here = linear)

# Now comes the next step of every modeling exercise: 
# After we build the model - and convinced ourselves that it did what we thought it did: 
# "Evaluating the model" 
#Explicitly take the parameters we just obtained and make predictions from it
yHat = slope * data[:,0] + intercept #Take the predictor variable multiply it with the slope
# and add the intercept to compute the preditions (the yHats)
# These are different steps because technically, we just made a mistake. 
# Not a syntax error, but a much deeper sin:
# We used all the data to build the model. Now we re-used the same data to evaluate the model. 
# This is a big no-no. We do it here to show you how regression works, 
# but going forward 
# We have to split the data into a "training set" (which we use to fit). This yields the parameters
# and a "test set" (used to calculate the errors). This yields the actual predictions.    
# Also a bit scary to see that Python will let you do it. 
# You have to know that splitting the data is important. And how to do that.

# Step 4: Optional, but highly recommended: Plotting the data and the model...
plt.plot(data[:,0],data[:,1],'o',markersize=3) 
plt.xlabel('IQ') 
plt.ylabel('income')  
plt.plot(data[:,0],yHat,color='orange',linewidth=3)
plt.title('Using scikit-learn: R^2 = {:.3f}'.format(rSq)) 

#So both the function and our "by hand" approach yield the exact same output.
#However, if we measured runtime, the function approach would be considerably faster.
#So from now on, we will use the function.


#%% 4. So far simple linear regression. 
# However, we know that regression without control can be misleading.
# We could do it. But it's not advisable.
# So we will now explore several means of statistical control, starting with partial correlation

# Say you are a environmental scientist and you are concerned about community health. 
# It is well known that there is a relationship between the income and the 
# propensity for violence of an individual.
# However, it is unclear what the causal factor is, or indeed what mechanisms underlie 
# this relationship.
# Before we can take it at face value, we have to control for known confounds.

# One big known confound in this case are the lead levels in the water supply.
# Lead is a heavy metal that is known to be biologically active in a bad way - 
# it's taken up by the body (in particular the brain) and it is not inert.
# Elevated lead levels in the water supply are known to depress lifetime earnings. 
# They are also known to increase propensity for violence, likely mediated by brain development
# in childhood. 
# Thus, lead levels in the drinking water supply are a potential confound linking 
# income and violence indirectly, so we should control for that.
# As it is one (1) strong known confounding variable, we will use partial correlation

# Logic: do 2 simple linear regressions for lead levels vs. income and lead 
# levels vs. violent incidents, then correlate the residuals; this correlation is then the 
# partial correlation. It represents the linear relationship between income and violence that -
# by definition - cannot be accounted for by the confound, as the residuals are what the model
# does not predict. We are effectively subtracting the yhats from the ys. Twice.  

# Always the same cascade:
# 1) Load data: income, violent incidents, lead levels
data = np.genfromtxt('leadIncome.csv',delimiter=',') #Literally a csv file
#Columnn 1: Income in k$/year, 
#column 2: lifetime violent incidents, 
#column 3: drinking water lead levels in microGram per deciLiter

#%%

# 2) EDA: Compute summary statistics: 
D1 = np.mean(data,axis=0) # take mean of each column
D2 = np.median(data,axis=0) # take median of each column
D3 = np.std(data,axis=0) # take std of each column

#We're skipping the plotting here, because the number of violent incidents are 
#effectively almost categorical. The granularity is low. So this won't look smooth. 
#Low single digit integers (that's a good thing - no one has like 100 violent lifetime events). 
#As the scatter plot is the only EDA for this we have introduced so far, 
#this would look awkward / clumpy
#There is a better of visualizing this, but that will fit better into the lab content next week. 
#Try it - as an exercise - the scatter plot looks clumpy/terrible here. 
#Because of the granulity of the data itself
#This is not necessarily a problem for the computation of the correlation,
#but it is for visualizing it.

# Compute correlation between income and violence:
r = np.corrcoef(data[:,0],data[:,1]) 
print('Pearson correlation:',np.round(r[0,1],3))
#Interpretation: At first glance, there seems to be a fairly strong and negative 
#relationship between income and violence. How much of the variane in violence is accounted 
#for by income, about?
#About 25%. That's a lot. That's substantial, given how many other known factors there are 
#(stress, heat, neurotransmitters, genetics, etc.)
#So the higher the income, the lower the propensity for violence. 
#Or so it seems.
#Can we stop here and take this at face value?
#Maybe write some sensational headline. We could. But should we? 


#Maybe in an ideal world, we might want to measure more things. 
#But as a data scientist, you often just have the data that you have. This is it.
#Can we make do with what we already have? Unknown confounds: Only with an experiment. 
#What to do? 

#Partial correlation! By doing two SLRs with the confound, then correlating the residuals 

# Initialize data for first SLR (OLS): Predicting income from lead levels
x = data[:,2].reshape(len(data),1)  # predictor is lead levels. Need to reshape as above
y = data[:,0] # outcome is income in $
#Note: Regression is not commutative - the direction matters. 
#If you predict lead levels from income, you will get a different regression line than if you
#predict income from lead levels. So the slope will be different. 
#Suggested exercise for the student: Try it. 
#Do both regression (in both directions) and compare the slopes
#So - how do we know which one we need to use as a predictor? 
#(This is a good question because this confusion might be the primary reason for 
#partial correlation mistakes among students and mayother other people as well)
#Rule: Use the confound you want to control *for* as a predictor for both regressions. 
#This makes good logical sense. We first see what income we can account for by lead levels. 
#Then we see what degree of violence we can account for by lead levels. 
#And then the residuals of those two regressions are - by definition - what cannot be accounted for
#by the lead levels.
#In other words, if they are still correlated, that correlation is not due to lead, the confound.

# 1) Building the model (initialize and fit):
incomeModel = LinearRegression().fit(x, y) #x = lead (predictor), y = income (outcome)

# 2) Evaluating the model ("running the model"):
incomeSlope = incomeModel.coef_ # b1 (here = income)
incomeIntercept = incomeModel.intercept_ # b0 (intercept)
yHatIncome = incomeSlope * x + incomeIntercept #Predicted income from lead levels

# 3) Determining the residuals 
#There are simple ways to have the model (Python) just tell you what the residuals are
#However, just this once, we will compute the residuals explicitly, 
#so you know where they came from in the future
residuals1 = y - yHatIncome.flatten() #Residuals = Literally the distances between the actual 
#outcomes and the predicted outcomes. Importantly, no squaring. The sign is preserved (!)
#Flatten in the line above to enforce that y and yHat have the same dimensionality, 
#which is important for taking element-wise differences
#In general, "flatten" rids you of the matrix structure of the array. 
#It turns a matrix into a vector. For instance, if you a matrix with 1000 rows and a 100 columns,
# and you flatten it, you then would have a vector with 100,000 elements
#Remember: Python natively does not have a concept of column or row vector. 
#Vector is just vector, with a missing 2nd dimension. 

# Initialize data for second SLR: Predicting violence from lead levels
#x = data[:,2].reshape(len(data),1)  # lead levels
#We could comment out the previous line because the predictor value is the same. 
#This is important to recognize, as it is always the case in partial correlation.
#So the commented out code serves a purpose here (to remind you of this fact)
y = data[:,1] # violent incidents - now the outcome variable is literally violence 

# 1) Building (creating and fitting the model):
violenceModel = LinearRegression().fit(x, y) #Same syntax, but y means something else now

# 2) Evaluate the model (like above, just with violence)
violenceSlope = violenceModel.coef_ # Same as above, but for violence
violenceIntercept = violenceModel.intercept_ # Same as above, but for violence
yHatViolence = violenceSlope * x + violenceIntercept

# 3) Compute residuals:
residuals2 = y - yHatViolence.flatten() #This gives us the 2nd residuals

# Last step: Correlate the residuals (what can't be accounted for by the confounds)
partCorr = np.corrcoef(residuals1,residuals2) #This yields the full correlation matrix
print('Partial correlation:',np.round(partCorr[0,1],3)) #Round: Input argument, here the off-diagonal number
# of the correlation matrix, then the number of decimals (not significant digits) you want, here: 3
#Note: If you are unsure as to how to use a given function, just type help(functionName)
#For instance, np.round returns the arguments it expects -
# an input array, the number of decimals, and the output. 
#It also specifies the defaults (after the "=", if an argument is unspecified)

#In other words, accounting for lead levels, now only about 1% of violence is accounted for by income. 
#So: Once we take the known confound into account, the correlation basically drops to 0.
#So lead was an actual confound.
#Therefore, we can conclude that income was simply a marker for lead levels in the drinking water
#(living in nicer neighborhoods one can afford to have cleaner water), not causal.
#Much like SES in the example in the lecture. 

#This is actually interesting in a "karmic justice" kind of sense. 
#Simple linear regression gives you prediction without control. 
#Very dangerous. 
#But if you do two proper simple linear regressions, you can use that to control. 
#If you have ONE known confound. 


#%% Part B: Understanding prediction 
# 5. First revisiting it from a linear algebra perspective
# So far, we treated regression entirely from a statsstics and optimization perspective

#Before we go into the details of this, recall the principles of vector projection from the lecture:
vec1 = np.array([0,0.5]) #Vector 1
vec2 = np.array([1,1]) #Vector 2
magVec1 = np.sqrt(vec1[0]**2 + vec1[1]**2) #Magnitude of vector 1
magVec2 = np.sqrt(vec2[0]**2 + vec2[1]**2) #Magnitude of vector 2 
dotProduct = np.dot(vec1,vec2) #Using a function to get the dot product 
angleBetween = np.degrees(np.arccos(dotProduct/(magVec1*magVec2))) #What is the angle between the vectors?
uVec = vec2/magVec2 # Creating a unit vector out of vec2 by dividing by magnitude

p = magVec1 * np.cos(np.deg2rad(angleBetween)) # The projection direction
projVec = p * uVec # That's the actual projected vector, yielded by p multiplied with the unit vector

plt.plot([0,vec1[0]],[0,vec1[1]],color='purple',linewidth=2) # Plot vec1 in purple
plt.plot([0,uVec[0]],[0,uVec[1]],color='blue',linewidth=2) # Plot uVec in blue
plt.plot([0,projVec[0]],[0,projVec[1]],color='red',linewidth=2) # Plot the projection of vec1 onto vec2 in red
plt.axis('equal') #Make sure aspect ratio is the same

#So far just vector projection. 
#But as you might recall from the lecture, we can use this approach to represent regression.
#Or rather, use projection to do regression.
#%% Now Say we have an experiment with 3 trials - which is nice because two would
# be trivial and we can still visualize 3 dimensions
# We want to know how "performance" is related to lighting (luminance) in a room

xLuminance = np.array([1,2,3]) # A column vector of IV in cd/m^2 (Candela per square meter)
yPerformance = 1.5 * xLuminance + 0.5 + np.random.normal(0,1,len(xLuminance)) * 2

# Make a nice plot of the situation:
plt.plot(xLuminance,yPerformance,'o',markersize=10)
plt.xlabel('Luminance in cd/m^2')
plt.ylabel('Performance in arbitrary units')

# This is legit, but to see how the equation (which works) works
# let's look at this graphically. Or geometrically.
# To do that, we need to express the experiment visually.
# Now, each trial is a dimension.
# Now what? How do we find the solution?
# Plot the entire experiment of inputs and outputs as vectors 
#%%

fig = plt.figure() # init figure
ax = fig.gca(projection='3d') # project into 3d space
ax.plot3D([0,xLuminance[0]],[0,xLuminance[1]],[0,xLuminance[2]],color='blue',linewidth=2) 
ax.plot3D([0,yPerformance[0]],[0,yPerformance[1]],[0,yPerformance[2]],color='green',linewidth=2) 
plt.legend(['Luminance','Performance']) 
ax.set_xlabel('Trial 1') 
ax.set_ylabel('Trial 2') 
ax.set_zlabel('Trial 3') 


#%% Now, let's actually use the formula we derived
# We use the projection formula to find beta to minimize the distance
# between beta*input and output. Output = beta*input + error

beta = np.dot(yPerformance,xLuminance)/np.dot(xLuminance,xLuminance) # Find the beta
prediction = beta * xLuminance # Make a prediction (simplest possible)

# Add this to the plot - the plot thickens:
fig = plt.figure() # init figure
ax = fig.gca(projection='3d') # project into 3d space
ax.plot3D([0,xLuminance[0]],[0,xLuminance[1]],[0,xLuminance[2]],color='blue',linewidth=2) 
ax.plot3D([0,yPerformance[0]],[0,yPerformance[1]],[0,yPerformance[2]],color='green',linewidth=2) 
ax.plot3D([0,prediction[0]],[0,prediction[1]],[0,prediction[2]],color='black',linewidth=5,linestyle='dotted') 
plt.legend(['Luminance','Performance','Prediction']) 
ax.set_xlabel('Trial 1') 
ax.set_ylabel('Trial 2') 
ax.set_zlabel('Trial 3') 


#%% Let's explicitly add the distance between the two (prediction and outcome)

fig = plt.figure() # init figure
ax = fig.gca(projection='3d') # project into 3d space
ax.plot3D([0,xLuminance[0]],[0,xLuminance[1]],[0,xLuminance[2]],color='blue',linewidth=2) 
ax.plot3D([0,yPerformance[0]],[0,yPerformance[1]],[0,yPerformance[2]],color='green',linewidth=2) 
ax.plot3D([0,prediction[0]],[0,prediction[1]],[0,prediction[2]],color='black',linewidth=3,linestyle='dotted')
ax.plot3D([yPerformance[0],prediction[0]],[yPerformance[1],prediction[1]],[yPerformance[2],prediction[2]],color='red',linewidth=2)  
plt.legend(['Luminance','Performance','Prediction','Error']) 
ax.set_xlabel('Trial 1') 
ax.set_ylabel('Trial 2') 
ax.set_zlabel('Trial 3') 

#Now you can literally see (as this is a visual), how close we can get to the outcomes, with our predictors
#Remember: We can't change the direction of the predictor vector, we can just find the optimal scaling factor - the beta
#that gets us as close as possible. We now visualize the minimal distance in red, also as a vector.

#%% Now that we convinced ourselves that this is in fact the correct beta (geometrically)
# we can go back and plot the solution
# We could open the old figure again, but let's start from scratch
# What if we had 20 measurements (20 trials)?
maxLuminance = 10
xLuminance = np.linspace(0.5,maxLuminance,20) # A column vector of IV in cd/m^2 - 20 luminance values
yPerformance = 1.5 * xLuminance + 0.5 + np.random.normal(0,1,len(xLuminance)) * 2 # Noisy integrate and fire
beta = np.dot(yPerformance,xLuminance)/np.dot(xLuminance,xLuminance) # Find the beta
prediction = beta * xLuminance # Make a prediction (simplest possible)
regressionLineX = np.linspace(0,maxLuminance,10) # Gives us 10 equally spaced numbers between 0 and 10. Intrapolation, x-base
regressionLineY = beta * regressionLineX # Find the ys of the regression line
plt.plot(xLuminance,yPerformance,'o',markersize=5) # Plot the data
plt.plot(regressionLineX,regressionLineY,color='black') # Plot regression line
plt.plot([xLuminance,xLuminance],[prediction,yPerformance],color='red') # Residuals

#Exploration for the student: Label the axes and provide a legend.

#Now we did regression - and the optimal regression line is literally optimal, as you can see 
#just with dot products. As the dot product is the engine that underlies projection. 
#And vector projection is the linear algebra "engine" that underlies regression.
#The upshot? You can literally just write down the solution, if you have tons of data.
#The time complexity is amazing. 


#%% 6) Changing perspectives: Explaining how beta is determined by "dropping marbles"
#  - which beta (found by which distance metric) is just right?
# In other words, this is now an explicit optimization perspective.
# So there are 3 perspectives on regression. There is the statistical perspectives (the sum of 
# squares stuff), the linear algebra perspective (projections), and the optimization perspective.

# Let's explore the space of betas
startExploration = beta - 2 #Left edge of the range of betas we explore
endExploration = beta + 2 #Right edge of the range of the betas we explore
numBeta = 200 #How many samples between the edges do we interpolate
testBetas = np.linspace(startExploration,endExploration,numBeta) # we try 200 betas between 
# the edges, linearly spaced between the actual beta and +/- 2. 
# Let's just go through them and try them

distanceSum = np.empty([numBeta,1]) # Init container
distanceSum[:] = np.NaN # Convert to NaN
for ii in range(numBeta): #Trying all of them, one at a time, as a loop
    prediction = testBetas[ii] * xLuminance # Do this numBeta times
    # We now need to introduce a distance metric
    # We start with sum of squares (the most commonly used)
    distanceSum[ii] = sum((prediction-yPerformance)**2) # Sum of squares as a distance metric
    # This is OLS - we use the sum of the squared differences between predictions and actual outcomes as our figure of merit
    # distanceSum[ii] = sum(prediction-yPerformance) # Simple summed deviations
    # distanceSum[ii] = sum(np.log(prediction-yPerformance)) # Absolute summed deviations
    
# Let's plot that  
plt.plot(testBetas,distanceSum,color='blue',linewidth=3)
# We also want to indicate with a line where the original beta was
plt.plot([beta,beta],[0,3000],color='magenta')
plt.xlabel('Beta')
plt.ylabel('Sum of squared differences of predictor&outcome (L2)')

#This traces out a parabola, and the minimum of a parabola is easy to find. 
#In other words, if you did this with "gradient descent", you would never end up in a local minima


#%% 7) Going deeper into regression as optimization - trying different metrics - what 
# is special about the sum of squared differences?
# We are now reusing the exact same code, expect for the fact that we will try a few different distance metrics

startExploration = beta - 2
endExploration = beta + 2
numBeta = 200
testBetas = np.linspace(startExploration,endExploration,numBeta)
distanceSum = np.empty([numBeta,4]) # Init container
distanceSum[:] = np.NaN # Convert to NaN



for ii in range(numBeta):
    prediction = testBetas[ii] * xLuminance
    distanceSum[ii,0] = sum(prediction-yPerformance) # Simple 
    distanceSum[ii,1] = sum((prediction-yPerformance)**2) # Sum of squares - OLS - L2
    distanceSum[ii,2] = sum(abs(prediction-yPerformance)) # Absolute value - L1
    distanceSum[ii,3] = sum(np.log(1 + (prediction-yPerformance)**2)) # Lorentzian

for ii in range(int(np.size(distanceSum)/len(distanceSum))):

    plt.subplot(2,2,ii+1)
    plt.plot(testBetas,distanceSum[:,ii])
    if ii == 0:
        plt.title('Summed differences')
    elif ii == 1:
        plt.title('Sum of squared differences')
    elif ii == 2:
        plt.title('Sum of absolute differences')
    else:
        plt.title('Lorentzian') 
        
#Make sure axis labels don't overlap        
plt.subplots_adjust(top = 0.99, bottom=0.01, hspace=0.3, wspace=0.25)

            

# We note that the Lorentzian might be a good compromise between not being 
# too sensitive to extreme differences in predictions vs. actual outcomes
# But still be smooth/continuous
# L2: Blows up large deviations between prediction and outcome
# L1: Not differentiable everywhere
# So the Lorentzian could be a good compromise

#%% 8) Sweeping the line around to find the minimum, as seen in lecture

for ii in range(numBeta):
    fig = plt.figure() #Open figure, call it fig
    plt.subplot(1,2,1)
    prediction = testBetas[ii]*xLuminance
    plt.plot(xLuminance,yPerformance,'o',markersize=5,color='blue') 
    regressionLineX = np.linspace(0,10,100)
    regressionLineY = testBetas[ii] * regressionLineX
    plt.plot(regressionLineX,regressionLineY,color='black')
    plt.plot([xLuminance,xLuminance],[prediction,yPerformance],linewidth=0.5,color='red')
    plt.xlim(0,10)
    plt.ylim(-5,25)
    plt.xlabel('Luminance in cd/m^2')
    plt.ylabel('Performance (arbitrary units)')
    
    plt.subplot(1,2,2)
    plt.plot(testBetas[0:ii],distanceSum[0:ii,1],'o',markersize=0.5,color='black') 
    plt.xlim(startExploration,endExploration)
    plt.ylim(0,max(distanceSum[:,1]))
    plt.xlabel('Beta')
    plt.ylabel('Sum of squared residuals')
    plt.pause(0.005)
