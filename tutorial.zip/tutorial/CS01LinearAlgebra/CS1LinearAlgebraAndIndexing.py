#In this session, we will introduce basic Python concepts like indexing, using Linear Algebra 

#%% 1) Numpy, arrays and indexing

#Numpy is the principal way of doing Linear Algebra with Python. 
#Its basic data type is the "array". Using arrays via numpy has many advantages.
#Importantly, it is very fast when representing data in arrays and using vectorized operations on it

import numpy as np # import the numpy library, and call it the alias "np", to save typing.

#1D arrays
firstArray = np.array([1,2,3,4,5]) #This creates a 1D array
# Regular parantheses () denote arguments to functions 
# Square brackets [] denote sets

#Indexing:
#In will give a brief presentation on how indexing works in Python conceptually, but meanwhile, we're going to do it in code first.
#Importantly - for historical reasons - Python *indexes from 0* (like most other programming languages, and unlike most scientific computing environments)
#If you are not a coder, it will probably take a while to get used to the fact that the first element in a vector is the 0th element:
accessingTheFirstElement = firstArray[0] #Reach into the vector and retrieve the 0th element, assigned to the variable on the left
print(accessingTheFirstElement) #Output what that element is to the console - this value will be 1.

#Side note: There is a longstanding philosophical debate as to whether indexing with 0 or 1 makes more sense. 
#The community is generally split between genuine coding languages (like C or Python), which - mostly for historical reasons - 
#index from 0 and mathematical/scientific computing environments (like Matlab or R), which index from 1. 
#Even mathematically, what makes more sense depends on what the numbers represent, either ordinality or cardinality (as pointed out by von Neumann)

#Updating arrays
firstArray[0] = 17 #Changing the first element of our vector to the number 17

#Suggestion for exploration: Honestly, if you do this for the first time, practice with this for a bit, right here. 
#There are two conflated concepts that most seasoned coders have simply gotten used to, but can be confusing for a beginner: 
#Namely that each "slot" in an array has two numbers associated with it: It's value and it's index. And that all indices are off by one (relative to how most regular people count).


#Slicing: Slicing is a more generalized form of indexing, namely if you want to retrieve more than one element at a time.
firstSlice = firstArray[0:2] #Take a slice of the vector, from the 0th (inclusive) to the 2nd (exclusive) element, yielding a slice of size 2.
#Again, indexing and slicing is a bit wonky relative to scientific languages like R, Matlab or Julia. But we will have visuals that illustrate this nicely 
#Nevertheless, please practice this a lot and make sure to check that the output is what you think it is. This logical error is so common that it has a name: "Off-by-one errors" (due to the "fencepost problem") is one of the most common logical errors in Python
#It even has a Wikipedia page. So be mindful that this might be an issue: As invalid slicing is a valid statement, Python will not notify you that something went wrong. But you will literally be working with the wrong data.
#As you can see in the slide on indexing, slicing will retrieve everything to the left of the 2nd number. 
secondSlice = firstArray[:2] #This will be the same slice as the first one, if you index from the left edge, you can leave that off

print(firstSlice == secondSlice) #Check that they are indeed the same, element-wise

thirdSlice = firstArray[1:4] #This returns the middle 3 elements of the first array. Here, the starting element and end point on either side of the colon have to be stated explicitly

longArray = np.array(range(100)) #What is going on here is a nested operation. First, we create a range of integers from 0 to n-1. This is a range object. Then we convert that to an numpy array (we could also have converted it to a list)
#This allows us to illustrate another form of slicing, one that involves two colons and 3 numbers:
oddNumbers = longArray[1:100:2] #This picks out all odd numbers from the array

#Suggestion for exploration: Create the syntax that picks out all even numbers from the array. Be careful not to be off by one.    
    

#Copying - sometimes you want to reassign an element of an array without changing the array of origin 
#It is generally a good idea to store your raw data in one variable and never touch it again.
#Do all the computations with a copy of that dataset. 
#This is a good idea in case you make a mistake. Once the data is processed, it might be gone. 
#Nature knows this. There are storage structures (DNA) and processing structures (RNA). And for the same reason. 
#You don't have to do this, but it is strongly recommended. Do whatever you want, but know what you're doing.

newArray = np.copy(firstArray) #Create the new array as a copy of the first array in memory (!). NEW memory is allocated. This doesn't matter much here, for a 5 element array, but it will matter for a billion element array. 
newArray[0] = 69 # Overwrite the 0th element to be 69
print(newArray) #New array is affected by the change
print(firstArray) #Array of origin is untouched. They are unlinked

newArray = firstArray #In contrast, if you don't make a copy, the original array will be affected. This is basically a just a pointer, not new memory. 
newArray[0] = 69
print(newArray) 
print(firstArray) #Array of origin is also affected by the change. Oh no. Unless you wanted this to happen. 

#2D arrays
A = np.array([[1,2,3],[4,5,6]])  #Create array A with 2 rows and 3 columns as a stack of vectors, as seen in the lecture
print(np.ndim(A)) #Number of dimensions of variable A - in this case, 2

print(A.shape) #Outputs the shape (rows, columns) of variable A into the console
A = A.reshape(3,2) #Turn A into a 3,2 (rows, columns) shaped array with the same elements
print(A.shape) #Outputs the shape (rows, columns) of matrix A into the console
#Note: Reshape is *not* transpose. Transpose turns rows into columns and vice versa, reshape literally just takes the stream of numbers and cuts/stacks them differently

A[0][1] #This accesses - and returns to the console - the value of the matrix entry in the first row and the second column (remember, Python indexes from 0, so everything is off by one)
A[0,1] #This does the same as the previous line, but with one square bracket 
A[1,0] = 9 #Change the value in the 2nd row and 1st column of A to 9
A[1,:] #Reach into the 2nd row and return the contents of the entire 2nd row to the console
A[0,:] = 99 #Change the entries in the entire 1st row of A to 99
A[0:2,1] #Output the entries in the first two rows and 2nd column of A

#Again, if you are doing this for the very first time, please do yourself a favor and practice indexing and slicing of multi-dimensional arrays
#Some analogies as to what the dimensions represent could be rows and columns in a spreadsheet or rank and file in chess

#%% 2) Vectors and vector operations

# a) Vector length
arbVec = np.array([1,5]) # Define some arbitrary vector. This one is pretty arbitrary
magVec = np.sqrt(arbVec[0]**2 + arbVec[1]**2) # Magnitude of vector from Pythagoras
print(magVec)

# Trust, but verify - always check whether your code does what is supposed to.
# This is another general code suggestion. In real life, questioning someone might be considered rude or even disrespectful and indicates a lack of trust or faith. 
# In coding, the computer doesn't mind being checked. I would strongly urge you (and we will practice this more later in a more principled fashion) to get used to checking whether code works
# Here, we will do this with a known quantity
knownVec = np.array([3,4]) # This is used in every middle school class when introducing Pythagoras. We would expect 5 as the answer 
magVec2 = np.sqrt(knownVec[0]**2 + knownVec[1]**2) # Answer checks out. So this is legit.
print(magVec2)

# Yet another convention: 
# If you reuse code logic more than once, it is probably wise to write a
# function, *NOT* copy and paste (like we did here). 
# It is a bad idea to copy and paste code because you might forget to update one of the arguments
# Even here. You need to update *both* argVecs to knownVecs. If you have a code segment that needs to
# be updated in 40 places, it is easy to miss one. Better to write a function that takes everything that 
# needs to be updated as arguments. Actually, making this copy and paste, but failing to update is a key source of logical errors
# We will introduce how to write functions later.
# We will also generalize this to vectors with more numbers. 

# b) Creating a unit vector (length =1)
newVec = np.array([7,4]) # Arbitrary new vector
magVec3 = np.sqrt(newVec[0]**2 + newVec[1]**2) # Same logic as before
uniVec = newVec/magVec3 # compute the unit vector by dividing the vector through its length
magVec4 = np.sqrt(uniVec[0]**2 + uniVec[1]**2) # Checking that this worked - we expect an answer of 1
#Remember, always check that this worked
print(magVec4)
print('Did we really create a unit vector?', magVec4==1)

# c) Scalar multiplication of a vector
# Let's say we have our unit vector from before, but we now want to make it longer
scal = 5 #Scale factor
scaledVec = scal * uniVec #Implementing scalar multiplication
magVec5 = np.sqrt(scaledVec[0]**2 + scaledVec[1]**2) # Checking that this worked (Should be 5)
print(magVec5)

# d) Creating a null vector by multiplying with 0 - it should have length zero
nullify = 0 #Zero defeats all
nullVec = nullify * uniVec #Multiplying with zero 
magVec6 = np.sqrt(nullVec[0]**2 + nullVec[1]**2) # Checking that this worked - the zero is undefeated
print(magVec6)

# e) Vector addition
vec1 = np.array([1,4]) #Create an arbitrary vector
vec2 = np.array([5,7]) #Create another arbitrary vector
vec3 = vec1 + vec2 # Add them

#Suggestion for exploration: Create a statement that checks that this worked.

# f) Vector plotting 
import matplotlib.pyplot as plt # First, we need to import the Matlab plotting library
#This is a new library which we import now. Matplotlib is one of the most popular plotting libraries in Python.
#It essentially recreates (by reverse-engineering) the plotting capabilites of Matlab in Python.

# Plot each vector:
plt.plot([0,vec1[0]],[0,vec1[1]],color='purple',linewidth=1) # Plot Vec1 in purple
plt.plot([0,vec2[0]],[0,vec2[1]],color='blue',linewidth=1) # Plot Vec2 in blue
plt.plot([0,vec3[0]],[0,vec3[1]],color='red',linewidth=2) # Plot Vec3 in red
#Suggestion for exploration: Create different vectors and see what their sum plotted looks like
#Also change some of the plotting attributes

# g) The dot product and illustrating how it is immediately useful
# Much of Data Science relies on the dot product in various guises. 
# You're invoking dot products implicitly every day, e.g. every time you do a web search
# We will explore these in later sessions. 
# For now, just an immediate illustration as to how it is useful, and what it is - intuitively. 
# Imagine you are running a web store and you made 302 sales last month. 
# Say you sell 5 different kinds of products. 
# We represent these sales numbers of these 5 products with an array
productSales = np.array([100,50,50,75,27]) # Declare a variable to represent how many products of each kind were sold?
priceList = np.array([[5],[20],[3],[6],[1]]) # Declare a variable to represent how much each type of product costs in dollars?
overallRevenue = np.dot(productSales,priceList) # This is a dot product!
print('Revenue last month from all sales:',overallRevenue[0], 'dollars')
# Imagine you were running Amazon. In principle, you could represent all of their sales last months like this.
# And compute their overall revenue with 1 line of code.
# That is powerful.

#%% 3) Matrices
# So far, we have called vectors 1D arrays and matrices 2D arrays. 
# From now on, we will call them as they would be in linear algebra. 
# Note: Numpy still uses the "array" data type for all of this.

# Creating a matrix:
M = np.array([[1,2,3],[4,5,6]])  #Create matrix M with 2 rows and 3 columns

# Dimensionality
print(M.shape) #Outputs the dimensionality (rows, columns) of matrix M into the console
M = M.reshape(3,2) #Turn M into a 3,2 (rows, columns) shaped matrix with the same elements
print(M.shape) 
# You can turn a matrix intro a vector by the "flatten" method:
MVec = M.flatten() #In other scientific programming languages, this is often called "linearization", arranging all numbers from the matrix in one - often long - line

# And turn it back into a matrix of the original shape:
vecM = MVec.reshape(3,2)

# Transpose
# Remember earlier, we already noted that reshaping is not necessarily = transposing. In fact, it rarely is. 
# So how do we transpose?
vecM = vecM.transpose() #This yields the transpose of vecM by invoking the transpose method of this array
#This was transposing by treating the vecM array as an object (which it is), and calling its transpose "method". In which case it doesn't need an argument, because it refers to itself 
vecM = np.transpose(vecM) #Transposing it back by invoking the numpy transpose function. We do this to illustrate that there are many ways to achieve the same outcome. 
#This is generally true when coding - divergent implementations often yield convergent results.
#The biggest difference is that the numpy implementation - obviously - needs an argument, which you need to provide.  

#Matrix addition
#Note: Matrix addition works if (and only if) the matrices added have the same shape
Q = M + M #Adding two (3,2) matrices. Note that the elements of Q result from element-wise addition of the two matrices M that were added together
mT = M.transpose() #Create the matrix MT (Mtranspose) of shape (2,3)
Q2 = M + mT #This will error out because the matrix dimensions don't agree. 

#Dimensions have to match exactly:
MVec2 = np.copy(MVec) #Create a copy of the flattened Matrix M (now a vector), with the numpy "copy" function    
MVec2 = np.append(MVec2,7) #Add ("append") the value "7" to the end of our copy of MVec - so it is now one element longer
addedVectors = MVec + MVec2 #This will throw an error because the shapes don't match. If you were to add two vectors, one with a million elements and one with a million and one elements, this would not work. Shapes have to match exactly.
#The shapes/dimensionalities have to match exactly because it is adding all entries element-wise. If there any offset, it doesn't know which element to match up with which one. Instead of making assumptions about how they align, it just doesn't do it at all
#This is going to have important implications for data handling, as for real data, we often missing (!) data. In the next code segment.

#%% 4) Accessing matrix elements and representing missing data

#As a reminder, we already did this in line 89 onward, when we called the matrix a "2D array" (which it is)

M[0][1] #This accesses - and returns to the console - the value of the matrix entry in the first row and the second column (remember, Python indexes from 0, so everything is off by one, relative to how most people think)
M[0,1] #This does the same as line 225, but with one square bracket 
M[1,0] = 9 #Change the value in the 2nd row and 1st column of M to 9
M[1,:] #Reach into the 2nd row and return the contents of the entire 2nd row to the console
M[0,:] = 99 #Change the entries in the entire 1st row of M to 99
M[0:2,1] #Output the entries in the first two rows and 2nd column of M

 
#The trouble with holes:
spendingUserA = np.array([5,20,3]) #Create vector with elements 1 to 3 to represent spending of a user on 3 days 
spendingUserB = np.array([10,2]) #Create vector with elements 1 to 2 to represent spending of another user on 2 out of the 3 days. They skipped a day. But we don't know which day they skipped
overallSpending = np.stack((spendingUserA,spendingUserB)) #This command intends to stack the vectors on top of each other to create a matrix that represents the overall spending on both days. However, this command will throw an error.
# Matrixes cannot have holes. Much like nature abhors a vacuum, matrices cannot abide holes because it wouldn't know how to align the stacks (left-aligned or right-aligned) even if there is a single hole. This issue is worse if there are multiple holes. 
# In other words, all rows of a matrix have to have the same number of columns and all columns have to have the save number of rows.
# This is problematic because in data analysis, we have to - more often than not - handle missing data. 
# Here, we might not know whether the 2nd user spent anything on one of the days - we only have data from 2 out of the 3 days (maybe the tracking device malfunctioned on one of the days)
# So we need to find a way to represent the "hole" (which will be useful to represent missing data) explicitly. 
# This is done with a special element, a "nan" - this stands for "not a number", but one that is represented like a number (not a string), so you can do matrix operations on it, much like on any other number (and unlike operations on characters)
# Nans are very valuable, as they are quite useful:
    
spendingUserB = np.array([1,2,np.nan]) #Create vector with elements 1 to 2 to represent spending of user B on the first 2 days. Say that the data from day 3 is missing, and we input a nan explicitly. 
#Now we know which day was skipped by the 2nd user.
overallSpending = np.stack((spendingUserA,spendingUserB)) #Now it works
overallSpending.shape #Confirming that the (2,3) matrix was created successfully, by stacking the two (1,3) vectors, the 2nd one with the explicit hole
#And now, all defined matrix operations (matrix addition, matrix multiplication, etc.) work (again) - which is efficient

#Beware: Missing data is best represented as "nan". If you impute missing data as values (0 or the mean or something else), you might have to retract your paper later:
#https://retractionwatch.com/2021/07/07/critique-topples-nature-paper-on-belief-in-gods/    

#Suggestion for exploration: Create other vectors with "holes" in different locations (first, then second element), then stack them all together to create a (4,3) matrix

#There is a big difference between 0 and nan, when it comes to missing data. Kind of like the difference between absence of evidence (nan) and evidence of absence (0). 

#At this point, you might wonder where these nans come from. How are nans made? 
#Briefly, they are Pythons (and Matlabs, for that matter) answer to an age old philosophical question: What is the result of zero times infinity?
#Is it zero because any number multiplied by zero is zero, or infinite, because that's a lot of zeros (an infinite number of them)? Which way does it go?
#The answer is: 
0 * np.inf #How nans are made, forged in the very essence of mathematics. You can assign the output of this command to a variable to catch the nan, if you want.


# Logically, we should continue with matrix multiplication next - and we will - but understanding that involves control of program flow, which we will do in the next session.
# For now, note that there are several ways to do this with functions, either
np.matmul(M,mT) #by using the numpy function "matmul"
#or the numpy function dot - as matrix multiplication is simply all possible dot products of the component vectors
np.dot(M,mT) #same outcome

#Note that this works because the matrix dimensions match where they touch. Confirm this with the "shape" method.
#Suggestion for exploration: Confirm that matrix multiplication is not necessarily commutative by computing the matrix multiplication of mT and M (in that order)