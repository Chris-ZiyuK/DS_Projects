#In this session, we will introduce basic Python concepts like indexing, using Linear Algebra 

#%% 1) Numpy, arrays and indexing

#Numpy is the principal way of doing Linear Algebra in Python. 
#Its basic data type is the "array". 
#An array is a rectangular (in rows and columns) arrangement of numbers.
#Using arrays via numpy has many advantages.
#Importantly, it is very fast when representing data in arrays and using vectorized operations on it

import numpy as np # import the numpy library, and call it the alias "np", to save typing.

#1D arrays (D = dimension)
firstArray = np.array([1,2,3,4,5]) #This creates a 1D array
# Regular parantheses () denote arguments to functions 
# Square brackets [] denote sets

#Indexing:
#In will give a brief presentation on how indexing works in Python conceptually, 
#but meanwhile, we're going to do it in code first.
#Importantly - for historical reasons (index = pointer offset) - Python *indexes from 0* 
#(like most other programming languages, and unlike most scientific computing environments)
#All scientific ones index from 1 - R, Mathematica, Matlab, Julia, etc. 
#If you are not a coder, it will probably take a while to get used to the fact
#that the first element in a vector (or an array) is the 0th element:
#If you *ever* get used to it. Non-CS people count like this:
#1 - 2 - 3 - 4 - 5
#They don't count like this:
#0 - 1 - 2 - 3 - 4
#There is a reason why a countDown includes 0 - we'll talk about it in a moment
#Important side-note: Every element in an array has an index and a value
#We can use the index of an element to retrieve it's value. Let's do that now.
    
accessingTheFirstElement = firstArray[0] #Reach into the vector, retrieve 1st element, assign to left
print(accessingTheFirstElement) #Output what that element is to the console - this value will be 1.

#In addition to the historical reason as to whether indexing from 0 or 1 makes the most sense
#there are deeper philosophical reasons as to what the numbers represent, as to whether 
#indexing with 0 or 1 makes more sense. As we already discussed, the community is generally split
#between genuine coding languages like C or Python), which - mostly for historical reasons - 
#index from 0 and mathematical/scientific computing environments (like Matlab or R),
#which index from 1. 
#But mathematically, what makes more sense depends on what the numbers represent, 
#either ordinality (in which order something happens) or cardinality (how "mighty" a set is)
#in other words, how many elements it contains. Both of these things were pointed out 
#by John von Neumann. To be clear: If numbers represent ordinality, 1 is the natural starting point
#For instance, "year 0" is the first year. 
#Or if someone runs the fastest, they come in first. Then second.
#Cardinality: 0 is the better starting point. You start with nothing, then add to that. 
#Personal note: It pains me to see people misusing this - just to be cool. Very sad. 
#Tell me you don't understand the difference between ordinality and cardinality without telling me.

#In any case, there is no doubt that indexing being off by one (relative to how most people think)
#is one of the most common sources of logical errors in code, particularly among beginners. 
#For instance, if you want the value of the 5th element of an array in Python, and ask for index 5
#it will fetch the value of the 6th element, without any further comment. Oh no. 
 
#Updating arrays
firstArray[0] = 17 #Changing the first element of our vector to the number 17

#Suggestion for exploration: Honestly, if you do this for the first time, 
#practice with this for a bit, right here. Target some value and figure out how to change it. 
#There are two conflated concepts that most seasoned coders have simply gotten used to, 
#but can be confusing for a beginner: 
#Namely that each "slot" in an array/element of an array has two numbers associated with it: 
#Its value and its index. 
#And that all indices are off by one (relative to how most regular people count).


#Slicing: Slicing is a more generalized form of indexing, 
#namely if you want to retrieve the values of more than one element at a time.
firstSlice = firstArray[0:2] #Take a slice of the vector, from the 0th (inclusive) 
#to the 2nd (exclusive) element, yielding a slice of size 2.
#The colon means: All values from the first index to the 2nd index
#Naively, looking at this, one would think that this would retrieve 3 numbers: The values at index
#0, 1 and 2. But in Python, the 2nd number is exclusive, so it will give you all values UP to that. 

#As you can see, indexing and slicing is a bit wonky relative to 
#genuine scientific programming languages like R, Matlab or Julia. 
#But we will have visuals that illustrate this nicely 
#Nevertheless, please practice this *a lot* and make sure to check 
#that the output is what you think it is. 
#This logical error is so common that it has a name: 
#"Off-by-one errors" (due to the "fencepost problem") 
#is one of the most common logical errors in Python
#It even has a Wikipedia page. 
#So be mindful that this might be an issue: As invalid slicing is a valid statement, 
#Python will not notify you that something went wrong. 
#But you will literally be working with the wrong data. Not the ones you thought you asked for.
#As you can see in the slide on indexing, slicing will retrieve everything to the left 
#of the 2nd number. 
secondSlice = firstArray[:2] #This will be the same slice as the first one, 
#if you index from the left edge, you can leave that off. Saves you typing one number.

print(firstSlice == secondSlice) #Check that they are indeed the same, element-wise

thirdSlice = firstArray[1:4] #This returns the middle 3 elements of the first array. 
#Here, the starting element and end point on either side of the colon have to be stated explicitly
#Because we don't want all numbers, just from index 1 (inclusive to 4 (exclusive)).
#Again, this is a cautionary note why you might want to practice this. 
#Just looking at this - naively, and if you come from MATLAB or R, you would think this 
#command will yield 4 numbers, the first to the 4th numbers in the array.
#In reality, this command will give you 3 numbers, the 2nd to 4th number. 
#All off by one in different ways. 

#When creating arrays, we will rarely type out the contents. We use functions to create
#many numbers at once. 
longArray = np.array(range(100)) #What is going on here is a nested operation. 
#First, we create a range of integers from 0 to n-1. This is a range object. 
#Then we convert that to an numpy array (we could also have converted it to a list).
#This creates 100 numbers from 0 to 99, but at least it does create 100 of them. That's good. 

#This allows us to illustrate another form of slicing, one that involves two colons and 3 numbers:
oddNumbers = longArray[1:100:2] #This picks out all odd numbers from the array

#Suggestion for exploration: Create the syntax that picks out all even numbers from the array. 
#Be careful not to be off by one.    
    
#So far slicing. There is a very important difference how slicing works in Python vs. MATLAB:
#Copying - sometimes you want to reassign an element of an array without changing the array of origin 
#It is generally a good idea to store your raw data in one storage variable and never touch it again.
#Then do all the computations with a copy of that dataset. 
#In general, computations destroy some information (for instance, averaging over a dimension)
#This is also a good idea in case you make a mistake. Once the data is processed, it might be gone. 
#Nature knows this. There are storage structures (DNA) and processing structures (RNA). 
#And for the same reason. 
#You don't have to do this, but it is strongly recommended. 
#Do whatever you want, but know what you're doing.
#This is a best coding practice. 

newArray = np.copy(firstArray) #Create the new array as a copy of the first array in memory (!). 
#NEW memory is allocated. This doesn't matter much here, for a 5 element array, 
#but it will matter for a billion element array. 
newArray[0] = 69 # Overwrite the 1st element of the array and make it 69
print(newArray) #New array is affected by the change
print(firstArray) #Array of origin is untouched. They are unlinked

newArray = firstArray #In contrast, if you don't make a copy, the original array will be affected. 
#Here, "newArray" is basically a just a pointer to the same memory, with a new name, not new memory. 
newArray[0] = 69
print(newArray) 
print(firstArray) #Array of origin is also affected by the change. 
#Oh no. Unless you wanted this to happen. This is also a major source of logical errors

#2D arrays (which we use to represent matrices)
A = np.array([[1,2,3],[4,5,6]])  #Create array A with 2 rows and 3 columns as a stack of vectors,
# as seen in the lecture
print(np.ndim(A)) #Number of "dimensionality" of variable A - in this case, 2

print(A.shape) #Outputs the shape (rows, columns) of variable A into the console
#Note: As "A" is a numpy array, we can get same outcome by invoking the methods of that object:
    
A = A.reshape(3,2) #Turn A into a 3,2 (rows, columns) shaped array with the same elements
print(A.shape) #Outputs the shape (rows, columns) of matrix A into the console
#Note: Reshape is *not* transpose. Reshape cuts the number stream for housekeeping purposes. 
#Transpose is a linear algebra operation and turns rows into columns and vice versa,
#reshape literally just takes the stream of numbers and cuts/stacks them differently.
B = np.copy(A)
C = np.transpose(B)
#In other words, transposing an array turns rows into columns and vice/versa
#"Reshape" just cuts/parses the stream of numbers differently (internally, the array is one long
#stream of numbers that is arranged as rows and columns). If your rows only have 2 columns, you
#will have more rows, if you want to preserve the number of elements in the array. But the order of
#the numbers (from left to right and top to bottom is the same!). Not so in the transpose!
#Subtle - but very important point. Probably also the cause of many a logical error.

#Indexing of 2D arrays:
A[0][1] #This accesses - and returns to the console - the value of the matrix entry in the first 
#row and the second column (remember, Python indexes from 0, so everything is off by one)
A[0,1] #This does the same as the previous line, but with one square bracket. It's equivalent.
A[1,0] = 9 #Change the value in the 2nd row and 1st column of A to 9
A[1,:] #Reach into the 2nd row and return the contents of the entire 2nd row to the console
A[0,:] = 420 #Change the entries in the entire 1st row of A to 99
A[0:2,1] #Output the entries in the first two rows and 2nd column of A

#Again, if you are doing this for the very first time, please do yourself a favor and 
#practice indexing and slicing of multi-dimensional arrays
#Some analogies as to what the dimensions represent could be rows and columns in a spreadsheet 
#or rank and file in chess

#%% 2) Vectors and vector operations

# a) Vector length
arbVec = np.array([1,5]) # Define some arbitrary vector. This one is pretty arbitrary
magVec = np.sqrt(arbVec[0]**2 + arbVec[1]**2) # Magnitude of vector from Pythagoras
print(magVec)

# Trust, but verify - always check whether your code does what is supposed to.
# This is another general code suggestion. Best practice. 
# In real life, questioning someone might be considered rude or even disrespectful 
# and indicates a lack of trust or faith. 
# In coding, the computer doesn't mind being checked. 
# I would strongly urge you (and we will practice this more later in a more principled fashion) 
# to get used to checking whether code works
# Here, we will do this with a known quantity
knownVec = np.array([3,4]) # This is used in every middle school class when introducing Pythagoras. 
#We would expect 5 as the answer 
magVec2 = np.sqrt(knownVec[0]**2 + knownVec[1]**2) # Answer checks out. So this is legit.
print(magVec2)

# Yet another convention / best practice: 
# If you reuse code logic more than once, it is probably wise to write a
# function, *NOT* copy and paste (like we did here). 
# It is a bad idea to copy and paste code because you might forget to update one of the arguments
# Even here. You need to update *both* arbVecs to knownVecs. If you have a code segment that needs to
# be updated in 40 places, it is easy to miss one. 
# Better to write a function that takes everything that 
# needs to be updated as arguments.
# Actually, making this copy and paste, but failing to update is a key source of logical errors
# We will introduce how to write functions later.
# We will also generalize this to vectors with more numbers. 

# b) Creating a unit vector (length =1)
newVec = np.array([7,4]) # Arbitrary new vector
magVec3 = np.sqrt(newVec[0]**2 + newVec[1]**2) # Same logic as before
uniVec = newVec/magVec3 # compute the unit vector by dividing the vector through its length
magVec4 = np.sqrt(uniVec[0]**2 + uniVec[1]**2) # Checking that this worked - we expect an answer of 1
#Remember, always check that this worked
print(magVec4)
print('Did we really create a unit vector?', magVec4==1)

# c) Scalar multiplication of a vector
# Let's say we have our unit vector from before, but we now want to make it longer
scal = 12 #Scale factor
scaledVec = scal * uniVec #Implementing scalar multiplication
magVec5 = np.sqrt(scaledVec[0]**2 + scaledVec[1]**2) # Checking that this worked (Should be 12)
print(magVec5)

# d) Creating a null vector by multiplying with 0 - it should have length zero
nullify = 0 #Zero defeats all, no matter how long it was to begin with
nullVec = nullify * uniVec #Multiplying with zero 
magVec6 = np.sqrt(nullVec[0]**2 + nullVec[1]**2) # Checking that this worked - the zero is undefeated
print(magVec6)

# e) Vector addition
vec1 = np.array([1,4]) #Create an arbitrary vector
vec2 = np.array([5,7]) #Create another arbitrary vector
vec3 = vec1 + vec2 # Add them
#Suggestion for exploration: Create a statement that checks that this worked.

# f) Vector plotting 
import matplotlib.pyplot as plt # First, we need to import the Matlab plotting library
#This is a new library which we import now. 
#Matplotlib is one of the most popular plotting libraries in Python.
#It essentially recreates (by reverse-engineering) the plotting capabilites of Matlab in Python.

# Plot each vector:
plt.plot([0,vec1[0]],[0,vec1[1]],color='purple',linewidth=1) # Plot Vec1 in purple
#By drawing from the origin (0) to the first element of vec1 in x direction and
#by drawing from the origin (0) to the second element of vec1 in y direction
plt.plot([0,vec2[0]],[0,vec2[1]],color='blue',linewidth=1) # Plot Vec2 in blue
plt.plot([0,vec3[0]],[0,vec3[1]],color='red',linewidth=2) # Plot Vec3 in red
#Suggestion for exploration: Create different vectors and see what their sum plotted looks like
#Also change some of the plotting attributes

# g) The dot product and illustrating how it is immediately useful
# Much of Data Science relies on the dot product in various guises. 
# You're invoking dot products implicitly every day, e.g. every time you do a web search
# We will explore these in later sessions. 
# For now, just an immediate illustration as to how it is useful, and what it is - intuitively. 
# Imagine you are running a web store and you sold 302 items last month. 
# Say you sell 5 different kinds of products. 
# We represent these sales numbers of these 5 products with an array
productSales = np.array([100,50,50,75,27]) # This array represents how many of each kind sold
priceList = np.array([[5],[20],[3],[6],[1]]) # This array represents how much each type costs in $
overallRevenue = np.dot(productSales,priceList) # This is a dot product!
# Here, we use the np.dot function to do the dot product. You could also write this by hand - just
# do multiply all the elements, then sum the products.
print('Revenue last month from all sales:',overallRevenue[0], 'dollars')
# Imagine you were running Amazon. In principle, you could represent all of their sales 
# last month just like this.
# And compute their overall revenue with 1 line of code.
# That is powerful. And fast.

#%% 3) Matrices
# So far, we have called vectors 1D arrays and matrices 2D arrays. 
# From now on, we will call them as they would be in linear algebra. 
# Note: Numpy still uses the "array" data type for all of this.

# Creating a matrix:
M = np.array([[1,2,3],[4,5,6]])  #Create matrix M with 2 rows and 3 columns

# Dimensionality
print(M.shape) #Outputs the dimensionality (rows, columns) of matrix M into the console
M = M.reshape(3,2) #Turn M into a 3,2 (rows, columns) shaped matrix with the same elements
print(M.shape) 
# You can turn a matrix into a vector by the "flatten" method:
MVec = M.flatten() #In other scientific programming languages, this is often called "linearization",
#arranging all numbers from the matrix in one - often long - line, a vector

# And turn it back into a matrix of the original shape:
vecM = MVec.reshape(3,2)

# Transpose
# Remember earlier, we already noted that reshaping is not necessarily = transposing. 
#In fact, it rarely is. 
# So how do we transpose?
vecM = vecM.transpose() #This yields the transpose of vecM by invoking 
#the transpose method of this array
#This was transposing by treating the vecM array as an object (which it is), 
#and calling its transpose "method". In which case it doesn't need an argument, 
#because it refers to itself 
vecM = np.transpose(vecM) #Transposing it back by invoking the numpy transpose function.
#As above 
#We do this to illustrate that there are many ways to achieve the same outcome. 
#This is generally true when coding - divergent implementations often yield convergent results.
#The biggest difference is that the numpy implementation - obviously - needs an argument, 
#which you need to provide.  

#Matrix addition
#Note: Matrix addition works if (and only if) the matrices added have the same shape
Q = M + M #Adding two (3,2) matrices. Note that the elements of Q result from element-wise addition
# of the two matrices M that were added together
mT = M.transpose() #Create the matrix MT (Mtranspose) of shape (2,3)
Q2 = M + mT #This will error out because the matrix dimensions don't agree. 
#A cryptic error message too. But it's just because the dimensions don't match.

#Dimensions have to match exactly:
MVec2 = np.copy(MVec) #Create a copy of the flattened Matrix M (now a vector), 
#with the numpy "copy" function    
MVec2 = np.append(MVec2,7) #Add ("append") the value "7" to the end of our copy of MVec -
# so it is now one element longer
addedVectors = MVec + MVec2 #This will throw an error because the shapes don't match. 
#If you were to add two vectors, one with a million elements and one with a million and one elements, 
#this would not work. Shapes have to match exactly.
#The shapes/dimensionalities have to match exactly because it is adding all entries element-wise. 
#If there any offset, it doesn't know which element to match up with which one. 
#Instead of making assumptions about how they align, it just doesn't do it at all
#This is going to have important implications for data handling, as for real data, 
#we often missing (!) data. 
#We will illustrate this and how to handle it in the next code segment.

#%% 4) Accessing matrix elements and representing missing data

#As a reminder, we already did this in before, when we called the matrix a "2D array" (which it is)
#But now as a matrix:
M[0][1] #This accesses - and returns to the console - the value of the matrix entry in the first row and the second column (remember, Python indexes from 0, so everything is off by one, relative to how most people think)
M[0,1] #This does the same as the last line, but with one square bracket 
M[1,0] = 9 #Change the value in the 2nd row and 1st column of M to 9
M[1,:] #Reach into the 2nd row and return the contents of the entire 2nd row to the console
M[0,:] = 420 #Change the entries in the entire 1st row of M to 99
M[0:2,1] #Output the entries in the first two rows and 2nd column of M

#The trouble with holes:
spendingUserA = np.array([5,20,3]) #Create vector with elements 1 to 3 to represent spending 
#of a user on 3 days 
spendingUserB = np.array([10,2]) #Create vector with elements 1 to 2 to represent spending 
#of another user on 2 out of the 3 days. They skipped a day. 
#But we don't know which day they skipped (the first, the second or the third)
overallSpending = np.stack((spendingUserA,spendingUserB)) #This command intends to stack the vectors
# on top of each other to create a matrix that represents the overall spending on both days. 
# However, this command will throw an error.
# Matrixes cannot have holes. Much like nature abhors a vacuum, 
# matrices cannot abide holes because it wouldn't know how to align the stacks 
# (left-aligned or right-aligned) even if there is a single hole. 
# This issue is worse if there are multiple holes. 
# In other words, all rows of a matrix have to have the same number of columns and 
# all columns have to have the save number of rows.
# This is problematic because in data analysis, we have to - more often than not - 
# handle missing data. 
# Here, we might not know whether the 2nd user spent anything on one of the days
#  - we only have data from 2 out of the 3 days (maybe the tracking device malfunctioned 
# on one of the days)
# So we need to find a way to represent the "hole" (which will be useful to represent missing data) 
# explicitly. We need a placeholder. This is done with a special element, 
# a "nan" - this stands for "not a number", but one that is represented like a number
#(not a string), so you can do matrix operations on it, much like on any other number 
#(and unlike operations on characters). Nans are very valuable, as they are quite useful:
    
spendingUserB = np.array([10,2,np.nan]) #Create vector with elements 1 to 2 to represent spending of user B on the first 2 days. 
#Say that the data from day 3 is missing, and we input a nan explicitly. 
#Now we know which day was skipped by the 2nd user.
overallSpending = np.stack((spendingUserA,spendingUserB)) #Now it works
overallSpending.shape #Confirming that the (2,3) matrix was created successfully, by stacking the two (1,3) vectors, the 2nd one with the explicit hole
#And now, all defined matrix operations (matrix addition, matrix multiplication, etc.) work (again) - which is efficient

#Some people represent missing data as 0s. But that can be problematic. 
#Why? 
#Because 0 has a meaning. It doesn't mean "no data". It means "no money was spent".
#Beware: Missing data is best represented as "nan". 
#If you impute missing data as values (0 or the mean or something else), 
#you might have to retract your paper later:
#https://retractionwatch.com/2021/07/07/critique-topples-nature-paper-on-belief-in-gods/    
#The claim of the paper was the concept of god follows societies becoming more complex
#They had lots of missing data from less well developed societies
#They represented this missing data as "0", meaning "no god".
#Oh no.
#Ouch. 
#They to retract the paper. 
#Scientists: "We can trace the origins of god"
#Also scientists: "We can't even handle missing data" 

#Suggestion for exploration: 
#Create other vectors with "holes" in different locations (first, then second element), 
#then stack them all together to create a (4,3) matrix

#There is a big difference between 0 and nan, when it comes to missing data. 
#Kind of like the difference between absence of evidence (nan) and evidence of absence (0). 

#At this point, you might wonder where these nans come from. How are nans made? 
#Briefly, they are Pythons (and MATLABs, for that matter) 
#answer to an age old philosophical question: What is the result of zero times infinity?
#Is it zero because any number multiplied by zero is zero, 
#or infinity, because that's a lot of zeros (an infinite number of them)? Which way does it go?
#Python answers this conundrum!: 
0 * np.inf #How nans are made, forged in the very essence of mathematics itself.
#You can assign the output of this command to a variable to catch the nan, if you want.

# Logically, we should continue with matrix multiplication next - and we will - 
# but understanding that involves control of program flow, which we will do in the next session.
# For now, note that there are several ways to do this with functions, either
np.matmul(M,mT) #by using the numpy function "matmul"
#or the numpy function dot - as matrix multiplication is simply all possible dot products 
#of the component vectors:
np.dot(M,mT) #same outcome

#Note that this works because the matrix dimensions match where they touch. 
#Confirm this with the "shape" method.
#Suggestion for exploration: Confirm that matrix multiplication is not necessarily commutative
# by computing the matrix multiplication of mT and M (in that order)