#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 14 15:23:35 2024

@author: ziyukong
"""

#%% Numpy, Array, and Indexing
import numpy as np

#Create an array
firstArray = np.array([1,2,3,4,5])

#Access the first element in the array
firstElement = firstArray[0]

#Print the first element
print(firstElement)

#Access the second element in the array
secondElement = firstArray[1]

#Print the second element
print(secondElement)

#Change/update the first element in the array
firstArray[0] = 17

print(firstArray)


#Slicing
firstSlice = firstArray[0:2]
print(firstSlice)

secondSlice = firstArray[:2]
print(secondSlice)

print(firstSlice == secondSlice) #Check that they are indeed the same, element-wise


longArray = np.array(range(100))

oddArray = longArray[1:100:2]

evenArray = longArray[0:100:2]

print(longArray)
print(oddArray)
print(evenArray)

newArray = np.copy(firstArray) #This 'np.copy' function will allocate new memory to the variable.
newArray[0] = 69
print(firstArray[0])
print(newArray[0])

#%% Vector and Vector Operations
# a) Vector length
arbVec = np.array([1,5]) # Define some arbitrary vector. This one is pretty arbitrary
magVec = np.sqrt(arbVec[0]**2 + arbVec[1]**2) # Magnitude of vector from Pythagoras
print(magVec)

knownVec = np.array([3,4]) # This is used in every middle school class when introducing Pythagoras. 
#We would expect 5 as the answer 
magVec2 = np.sqrt(knownVec[0]**2 + knownVec[1]**2) # Answer checks out. So this is legit.
print(magVec2)

import math

def getMag(array):
    value = 0
    for e in array:
        value += e**2
    return math.sqrt(value)

newVec = np.array([5,2,3,7,2])

print(getMag(newVec))

# e) Vector addition
vec1 = np.array([1,4]) #Create an arbitrary vector
vec2 = np.array([5,7]) #Create another arbitrary vector
vec3 = vec1 + vec2 # Add them
#Suggestion for exploration: Create a statement that checks that this worked.

from matplotlib import pyplot as plt

# Plot each vector:
plt.plot([0,vec1[0]],[0,vec1[1]],color='purple',linewidth=1) # Plot Vec1 in purple
plt.plot([0,vec2[0]],[0,vec2[1]],color='blue',linewidth=1) # Plot Vec2 in blue
plt.plot([0,vec3[0]],[0,vec3[1]],color='red',linewidth=2) # Plot Vec3 in red
#Suggestion for exploration: Create different vectors and see what their sum plotted looks like
#Also change some of the plotting attributes

# g) The dot product and illustrating how it is immediately useful

productSales = np.array([100,50,50,75,27]) # This array represents how many of each kind sold
priceList = np.array([[5],[20],[3],[6],[1]]) # This array represents how much each type costs in $
overallRevenue = np.dot(productSales,priceList) # This is a dot product!
# Here, we use the np.dot function to do the dot product. You could also write this by hand - just
# do multiply all the elements, then sum the products.
print('Revenue last month from all sales:',overallRevenue[0], 'dollars')
































