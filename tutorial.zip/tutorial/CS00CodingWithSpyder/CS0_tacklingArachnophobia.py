# Code session 0: Tackling arachnophobia - Python and the Spyder environment

# Everything after the pound/hashtag sign (#) is a "comment".
# Think of it as a "note to (your future) self". Python ignores everything after the # sign.
# Comments are rendered in gray by Spyder by default.

# This is the Spyder editor environment. Here is where you write programs.
# Programs are a collection of statements that are interpreted and then executed by the computer.

# Python reads them line by line, from top to bottom.
# And then executes each line immediately.
# This is important if the order of operation matters (ie in an algorithm)  

# This has 3 important implications:
# 1) Python is an "interpreted" language - different from a compiled language. More 
# commands to read will take longer to execute. This won't matter today, but it does 
#matter if you have a lot of data to analyze.

# 2) Order of operations really matters - the machine does not glean your intent. It 
# executes exactly what you wrote, so you need to be careful about your commands. 
# It takes all commands 100% literal. 

# 3) Errors: This is a corollary of 2) - if you don't fully appreciate this, it can lead to
# both logical and syntactical errors. Mostly logical errors, actually. 
# They are ultimately more dangerous.

# a) Syntax error: Make sure to first declare a variable, before you use it, like so:
A = 5 #This is our first variable, and our first value, that we assigned to it
print(A) #'print' is a function. Functions take arguments in parentheses. 
# "Print" outputs the contents of the argument to the console
# If you executed the print line before the assignment line, Python throws a syntax error - 
# specifically it would complain that "name A is not defined" 
# Suggestion for exploration: Try this by deleting the variable "A" in the variable explorer 
# in the upper right, then execute the print line to experience the error

#Variables can generally declared like this. Each variable has:
#A name (here "A") that refers to a location in memory
#A data type (here an "integer")
#A "size" ("shape" of the data). Today, we only do scalars, so size will always be 1
#A value - here "5", because we assigned the value 5 to the place in memory that we call "A"

#On this note: Just because you write a line doesn't mean Python will know about it. 
#Only lines that are executed "matter" insofar as they affect the work space

# b) Logical error: There are many kinds of logical errors.
# For example, sometimes the order of operations matters in the algorithm you are trying to implement
# In other words, Python will do exactly what you told it to do, 
# not necessarily what you wanted it to do - it will not throw an error 
# This is problematic because it will not be doing what you think it is doing. 
# Oh no. 
# Issues pertaining to unintended order of operations is one 
# of the most common sources of logical errors. 
# For instance, some algorithms we'll encounter later presume that you sorted the values first, 
# before determining some percentiles. 
# Reversing this order would yield the wrong answer. 
# This sounds trivial, but we have seen students do just that in the past. 
# Syntax errors tend to be frustrating (particularly to beginners), 
# whereas logical errors are usually more dangerous.
# We will explore both commonly made syntax and logical errors in later code sessions.

# Contemplating these errors also illustrates the essence of what coding actually is. 
# Coding is telling a machine what to do. 
# And it is amazing. 
# It never complains about or tires of the work, nor questions your commands. 
# However, there is a catch. 
# Two actually. 
# First, it doesn't speak your language - you have to learn its language. 
# That's where syntax errors come from. 
# When one is thrown, the computer tells you that it doesn't understand what you want.  
# Second, it doesn't do what you want it do. It does what you actually tell it to do. Literally. 
# Whether that makes sense or not. Remember: It never questions you. 
# In other words, a potential gap in meaning between your intent and what you actually told 
# the CPU could open up. That's what causes logical errors. 
# What could go wrong?

#%% 1 Code sections: Double percentage sign after the hashtag opens a new "code section"
# Code sections ("cells") are used to delineate logically different operations, e.g.
# loading of data, vs. analyzing it vs. plotting it.
# We strongly recommend to organize your code into these logically self-contained sections. 
# You don't have to do this - the code will run with or without sections, but
# using code sections like this will make your code easier to maintain and modify ("code surgery"). 
# It makes for "modular" code. 
# At a maximum, one logical segment should take one the entire screen. 
# If it is longer than that, break it up into smaller segments. 
# Because you want to avoid scrolling within a segment, if you can help it. 
# You want to see everything at one glance. 
# You'll see later (when we write larger and more complex programs, why) 
# Also, it is a good idea to number these code segments. 
# Code sections also help with running the code. You can run a whole cell with shift-enter (on a mac)
# Blocks in Jupyter, code sections and cells here are all the same thing, essentially.  

# One more thing about comments: Whereas this code contains - for didactic purposes -
# a lot more comments than one would normally use for production level code, 
# you can use them strategically, as Python will ignore them. 
# So we would advise to never delete code, just to "comment it out" 
# (in case you want to re-use a segment).
# If there is a large of portion of unused/commented out code,
# we suggest to collate that into a segment of commented out code at the bottom of your program. 
# We call this segment the "quarry" because you can mine it for code nuggets later.  

# How to use the console vs. the editor:
# This is just a recommendation, but here is what we do:
# The console (to the right in the default Spyder layout) executes ONE (1) line at a time. 
# So it is good for prototyping, i.e. to figure out what a given line of code is doing. 
# If we are unsure about the syntax of any given command, 
# we use the console to debug the command until it works before transferring it to the editor.
# The editor (here), where you are reading this, is all about a ledger of commands, 
# executed in line order (to the far left)
# So commands are building on themselves. 
# In other words, copy from the console (once debugged there), and pasted to the editor. 
# One thing about the console: With up-arrow, you can revisit - and then edit the old command

# Finally, whereas we organized this code into sections, 
# if you are student and reading this for the first time
# we strongly recommend to go through and execute this code 
# one line at a time, not the whole section at once.
# Recommended heuristic: Run code in segments during production, but write/understand it line by line 
# The reason for this: If something goes wrong, and you write more than one line at once, 
# say a whole long block of code - and then run it, and something doesn't work, 
# it will be very hard to debug. 
# You won't know where the error is. 
# Strong recommendation: One thing (change) at a time. 
# Particularly as a beginner. Otherwise, things can get very frustrating.
# There is no guarantee that the change will be positive.  
 
#%% 2 Variables and commands
A = 3 #Declare the variable "A" in memory, and assign the number "3" as its value 
#Interlude: In mathematics, the equal sign (=) represents equality (of the left and the right side).
#An equality (in the form of an equation) is a fundamental concept 
#on which much of mathematics is built. 
#The idea behind the equal sign is that nothing can be more equal than two parallel lines 
#(arguably - while well intentioned - they are doing this wrong, as one line is literally on top of
#the other, so || would be an even more equal equal sign), 
#and this idea is central to the logic of mathematics (the notion of an "equation")
#However, in Python (and Matlab, for that matter), the equal sign does NOT represent equality. 
#It represents the assignment operator. 
#In other words - and counterintuitively for western scripts - 
#this reads as "take whatever is on the right side and assign it to the left side".
#Whatever was on the left side before is replaced (and lost) by what is coming in from the right side 
#That is another reason why order of operations matters, 
#once you assigned a value to a variable, its value might have changed, as follows:

B = 2 #Declare the variable B and assign the number 2 to it.
C = A + B #Create variable C as a sum of the values of A and B

#Note that all of these variables have been created with their respective values 
#(confirm by looking at the "variable explorer" tab)
#If you want to output the value their value to the console, 
#you have to explicitly ask for this, by using the "print" function, 
#using the variable name as an argument:
print(C)    

#At this point, you might wonder what *is* the equal sign in Python, if it is not the = sign. 
#That is a valid question. It is the double equal (==) sign in Python (and for that matter in Matlab)
print(A == B) #Testing for equality of A and B, and outputting the result to the console.
#The console should return a "Boolean" in response to the previous line. 
#A boolean is a single binary digit (or "bit", as per John Tukey), 
#and can only take two possible values (0 or false) and (1 or true)
#Here, Python got it right - "A" currently holds the value of 3 and "B" holds the value of 2,
#and as 3 is not equal to 2, the test of equality returns "false" - the values are not equal 


#Let's update the value of variable B for the test to come true (for A and B to tbe truly equal)
B = B + 1 # This line also nicely illustrates the difference between equality (as in math) 
#and an assignment operator. 
#If this was a mathematical equation, it would be necessarily unequal - 
#B (on the left side) would always be smaller than B+1 on the right side 
#(unless B is infinite, which is not a possible value in this reality - it is in math)
#However, this represents an assignment, so this reads as 
#"take the current value of B (2), add 1 to it to yield 3, 
#and assign this result to the left side, updating B.
print(A == B) #Now, A and B are the same value (3) and the test of equality reflects that 
#- returning "true" to the console 

#By the way, the reason I'm emphasizing this is because confusing a single equal sign 
#(the assignment operator) with a double equal sign (the test for equality) is a very common source
# of logical errors. It sounds trivial, but if you are coding in a rush, at 3 am in the morning, 
#stressed out, you might - and will do this next time write code that only executes if certain 
#conditions are met. You will test this with a test for equality. In other words,
#are the conditions equal to what you expect. However, if you - in haste - use a single equal sign
#because you are used to that from math, instead of the double equal that you need,
#this will cause a logical error.
#Specifically, if you just told Python to assign the right side to the left side, 
#they will *always* be equal. 
#In other words, you thought you are doing a test for equality.
#Python thought you asked for an assignment. 
#This is a classic logical error. In a way, a human to machine misunderstanding (of intent)

#Right now, the print lines above return only the most sparse output to the console, 
#the result of the equality test itself. 
#We recommend to be more verbose than that -
#code amnesia (you quickly forgetting what a particular line of code is doing is real), like so:
print('Do variables A and B have the same value?', A==B) 
#Print also returns strings (strings are denoted in Spyder by single square quotes and 
#rendered by default in green) to the console, and contextualizes the answer semantically. 
#You can string them together with commas within the parantheses

#The assignment operator logic can also be used to implement recursive algorithms.
#We will do so later, but note that we can use the same command to further add to ('increment') B:
B = B + 1 #Now, B will be 4    
   
#To summarize, there are two kinds of statements in coding:
#Comments, which are ignored by the computer
#Commands, which are interpreted and executed by the computer    

#%% 3 Naming variables
#In the previous section, we introduced the notion of variables and just used "A", "B" and "C" as names. 
#We actually discourage that when writing your own programs. You can name variables anything you want. 
#So make it something good and descriptive:
    
lascap = A + B + C #Illustrating that you can name variables anything you want.  
sampleSize = 69 #This is better - because the variable name reflects what the variable represents. 
#Generally speaking, we recommend that, as it can save a comment. 
#To elaborate on this briefly, why is the previous line better than the following line, naming wise? 
size = 69 #We strongly discourage the use of simple variable names like that. 
#Python will do it, but confusing variable names is another key source of logical errors 
#(you think the variable refers to something it does not, and size could literally be the size
#of anything). It's really insiduous. It makes sense to you when you just wrote the code. 
#Then you do surgery on it a month later, and now you forgot what the variable actually represents.
#You might have made a logical error.
#One thing variable names cannot have is a space in between them:
sample Size = 69 #Executing this line will throw a syntax error ('invalid syntax') in the console. 
#Do not do this.
#Something else that is dangerous - and strongly discouraged is to use variable names 
#that are already names of functions:
print = 69 #Say you want to make 69 prints of something and represent that with a variable 
#that you call "print". Python will let you do this. 
#But it is unwise. Because you can now no longer use the print function:
print(size) #Will give a somewhat cryptic error message.
#You have to delete the variable print in the variable explorer first, to make the previous line
#work again (shift-click on the variable on a mac, then "remove")
#In general, it is strongly discouraged to use pre-existing function names as variables names, 
#as functions will no longer work, if you do that. 


#One more thing regarding variable names. Python convention (and many CS enthusiasts agree) 
#is to use the underscore (_) to create complex and descriptive variable names, like so:
sample_size_training_data = 100 #This is fine, but we consider that aesthetically unpleasant. 
#You can do this. We recommend "camel case" instead (and use that in our own work 
#as well as throughout this class):
sampleSizeTrainingData = 100 #Do whatever works for you, but this is what we do. 
#It's called "camel case" in the art. It is a stylistic choice. 

#To summarize: There is tremendous choice in naming variables. But many choices are poor, 
#some are dangerous. On the flipside, wise - and descriptive naming of variables cuts
#down on the need for comments and creates very readable and maintainable code.
#So naming variables is a considerable responsibility.

#%% 4 Functions

#We already encountered a built in function - "print".  

# To borrow a metaphor from physics, if variables are your "matter", functions are your "forces"
# Functions operate on their inputs and yield an output. 
# You can write your own functions, and we will teach you how to do so shortly, but for today, 
# we will use pre-existing functions.
# Python does not come with that many built-in functions, but there are a large number of libraries 
# Libraries are collections of functions that you can import and then use
# However, there are so many libraries (thousands), that you have to import the specific library 
# of functions you want to use first, before you can use the functions in this library. 
# This is another example of order of operations being critically important:
import math #This line imports the "math library" (a collection of standard mathematical functions)
# To get a list of available functions in a given library as a pop-up window, type the library
# name in the console after importing the library, put a period (.) and press tab, and wait. 
# To call a function from this library, we need to first indicate the library name, 
#then a period (.), then the function from that library.
# This reaches into a particular library before looking for the specific function name there. 
#Later, we will introduce the concept of aliases to save on typing. 
math.sqrt(4) #Takes and outputs the square root of the input argument (4). 
#Executing this line before the line where we import math yields a syntax error. Try it?
B = 4
#Generally speaking, there are many ways to achieve a given outcome in coding - 
#which is why it is such a great way of creative problem solving - here we would like to highlight
#that the same outcomes can be achieved by mathematical operators as well as functions:
D = B**0.5 #Take the square root of B with an operator 
#(Python uses the double asterisk ** to denote powers) and assign it to the variable "D" 
E = math.sqrt(B) #The same operation, but implemented with a function instead, 
#and assigned to the new variable "E"
#Testing that this worked:
F = D==E #Do a test of equality for D and E and assign the outcome to the variable F, 
#which will contain a boolean.     

#Here is another example - the absolute value function, which is "built-in" 
#- already comes with Python - so we need don't to denote a library:
abs(2) #Taking the absolute value of 2, which is 2
abs(-2) #Taking the absolute value of -2, which is 2

#As we already discussed, and to emphasize, functions operate on and modify inputs to create outputs. 
#The arguments to functions are indicated by regular parantheses ( ).

# If you want to know how any given function works, call for help - another built-in function:
help(abs) #Help on the built-in absolute value function 
help(help) #Help on the built-in help function

help(math.sqrt) #Help on the square root function of the math library
#Of course - this presumes that you know what functions are even in the math library. 
#How would you know that?
help(math) #By calling the help function on the library itself. 
#This explains the library, as well as what functions and constants it contains
#Note that you have to import the library first, before you can call help on it

# Importantly, functions can be chained together, and if you chain them together, the
# "innermost" function - that is surrounded by most parantheses - will be executed first
math.sqrt(-2) # This will yield a complex number which cannot be computed 
#by the math square root function - try it
math.sqrt(abs(-2)) # Keeping it real

# This is called "nesting" of functions. 
# Most statements you will write going forward will 
#consist of combinations of variables and (nested) functions. 

#Note: Python also has a few in-built functions that are special insofar as they are reserved
#keywords that cannot be used as a variable name.
#They are by default rendered in purple in Spyder and usually affect the way Python 
#interprets the next command. 
#We already encountered one example of this - the import function that does not need parentheses
#for the name of the library to import. 
#Another good example is the del keyword. del deletes a variable from the workspace. 
#Above, we could have used del to delete the variable programmatically (without clicking), e.g.
del B #Deletes variable B from the namespace

#You could in theory write a long program that declares many variables
#and deletes them right after. This makes no sense, of course. 
#But Python (and any other programming language, for that matter), will do it without question.
#If you do this in a loop - which we will introduce next time, potentially forever. 
#Highlighting the tremendous power - and responsibility - of coding. 
#You basically now have an electronic servant at your disposal. They will never, ever question you. 
#That's great, but *all* of the responsibility that what you ask this servant to do
#is yours and yours alone. 
#So you have to know what you're doing. Python won't tell you - it doesn't question you. 