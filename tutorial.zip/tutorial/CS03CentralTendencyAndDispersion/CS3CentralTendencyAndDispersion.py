#CS 3 - Central tendency and dispersion
#In this session, we will both characterize datasets and 
#try to understand some of the key concepts and insights from the lecture with simulations
#From now on, we will split the session into these two parts
#Part 1: The bare essentials that you absolutely need to be able to do in order to do the assignments
#Part 2: "W tier" stuff: Not necessary to do the assignment, but perhaps good to know. 

#%% 1) Basic file I/O

# The first thing we have to do in order to characterize data is to import it
# from an external storage file into a Python data structure

# Typical workflow
# Input: data from external files -> import into python (input)
# Data processing
# Output: variables from workspace -> write as external files (output)

# Using numpy to import .csv files:
# CSV-files have emerged as the standard way to store and exchange data for Data Scientists outside
# of using a relational database like SQL. CSV stands for "comma separated values", the convention
# is that "replicates" (usually people, like users but also cities or whatever is the 
# unit of analysis) is in rows, and all attributes ("features") of these replicates are in columns. 
# You don't have to follow this convention and we already covered transpose, so you can switch them
# but note that everyone who reads your code and in fact the function we will be using does assume
# that you are following these conventions. In other words, you can violate the convention, but
# you will have to do extra work. 
# In a csv file - if you open it with a text editor, successive values of the attributes of a 
# replicate are separated by a comma, as a parsing signal, hence "comma separated values"
# In principle, you can use any separator you want - the 2nd most popular choice is "tabs"
# for .tsv files (tab-separated values). csv and tsv pertains to the ending of the filename: .csv
     
# Note: make sure the file is in the correct path (top right of Spyder IDE)
# Otherwise navigate manually using unix commands - such as cd (change directory)
import numpy as np # load numpy so we can access the numpy data import functions
data = np.genfromtxt('determinedIncome.csv',delimiter=',') # load the data file, 
# assign it to a data structure called "data", and spell out that the delimiter is a comma
# Beware: This data file does not have headers. So you don't have to worry about that. However, 
# in the real world, csv files usually have headers. This could cause problems. 
# For instance, for the assignment, we will be looking at real movie rating data. 
# Some movie titles have commas in the title, e.g. "Girl, interrupted" is the title of a movie
# Python doesn't know what a movie is or what a movie title is. 
# All it knows is that you asked it to treat commas as a parsing signal. 
# So it will think that there are two movies, one movie "Girl" and one movie titled "interrupted". 
# Which will then offset everything else by a column. 
# I think I handled this problem already for the purposes of this first data analysis report. 
# But in the real world, be prepared that you will have to handle that. 
# Be prepared that there will be a preprocessing step, where you take all commas out of the titles.

# Later, we will deal with data files that have headers, and then we can interpret what they mean
# So let's handle headers later. When we do that, we will also use data frames - that's the native
# format for data with headers. That's the whole point of handling "tabular" data with pandas.
# Today, we'll just do numpy, so I have to tell you what the colunms mean
# It's not mission critical to know that - everything works the same, but it will add some texture
# to the session if you do.
# In this file, rows represent people
# Column 1 [0 in Python indexing]: IQ score
# Column 2: Hours worked per day (on average), rounded to the nearest hour
# Column 3: Years of formal education, rounded to the nearest year
# Column 4: Compensation in $1k per year, with 2 significant digits

# We don't need this yet, but we might as well mention it now, because this is in the file I/O
# section, which is a technical term, and the "O" stands for output:
# Afer you are done processing your data, you can    
# use numpy to write variables into a .csv file:
# Save data as .csv, by delimiter, with a specified form
np.savetxt("data.csv",data,delimiter=',',fmt='%1.2f') #Arguments: Filename, variables to save, 
#parsing symbol, format. Format here: Floating point number with 2 significant digits

# There are many other ways to load, store and represent data. Some have funny names, like "pickle"
# We are doing this one for now, now so you have one surefire way of getting this done.
# Whatever else happens.
# This one works. 
# More sophisticated (but also harder) ways are to follow, later.

#%% 2) Characterizing central tendency

# Now that we have some data in our workspace, we can try to characterize its central tendency
# The point of this is to summarize this dataset as succintly as possible. Having data from 
# 1500 people is a bit much. We can't just look at it and figure out what is going on.
# For instance, if we had 2 samples with incomes, it would be hard to tell just by looking at them
# which of the 2 samples earns more. But by using measures of central tendency, it will be easy to
# compare, because we can tell which of two numbers is larger. 

#Mean
columnMeans = np.mean(data,axis=0) #Column-wise means - in other words, across the rows
rowMeans = np.mean(data,axis=1) #Row-wise means - in other words, across the columns
print(columnMeans) #The column-wise means represent the average IQ, work-hours, 
# education years and compensation across all people in the dataset
print(rowMeans) #The row-wise means don't represent anything really - mashing IQ, hours worked, 
#education and compensation together. It is a mess.
#However, be mindful that Python doesn't know that. It will take the mean, even if the mean is not
#mean-ingful. That's up to you. That's why the conventions matter.
#For instance, if you had transposed the data (it's an array, you can do that)
#The column wise-mean would be meaningless and the row-wise mean would be meaningful. 
#As a convention, all scientific programming languages take the column-wise mean by default. 
#Otherwise, you have to specific across which axis you want to take the mean over. 
#Axis = what you average *over*. Here (for column-wise), we get one mean per column (4),
#*over* people, by specifying "0" (which is pythons way of saying "first"). In general, rows are the
#first axis, columns are the 2nd axis, and so on. You can have multi-dimensional arrays. 
#If there were missing values (here, we don't have any), we have to make a choice, either
#drop the missing values, impute (guess) something smart, or use a function that can handle nans
#(like nanmean), otherwise, if even a single nan is in the data, that entire row or column becomes
#in the output becomes nan, if you take the mean over it. That's another reason to use numpy
#because in numpy, you have to do this by hand, pandas has all kinds of defaults on how to handle 
#nans that are hidden from the casual user. Many beginners say something like: 
#"Oh, I just use dropna, lol".     
#That way lies absolute disaster.
#Pandas has many defaults that you might not be aware of and that might not to be appropriate for
#your use case. Which is why we use numpy here, as it forces you to make these things explicit. 
#So you at least understand why it matters. But that's for later. 
#However, missing data handling is a very dark and very deep art, so we will cover that in a 
#later session extensively. That's going to be the whole session.
#For now, to do the D1 assignment, you will need to handle missing data somehow, 
#so the easiest way is to use a function that just ignores them: 
columnMeanNoNan = np.nanmean(data,axis=0) #Column-wise means, in the presence of missing data
#As we have no missing data here, this function will yield the same outcome


#Median
columnMedians = np.median(data,axis=0) #Column-wise medians
rowMedians = np.median(data,axis=1) #Row-wise medians
#Again, if you had missing data, you will want to use the corresponding nanmedian function:
columnMedianNoNan = np.nanmedian(data,axis=0) #Column-wise medians, in the presence of missing data

print(columnMedians)
print(rowMedians)
#This looks like it worked. How can we tell? 
#IQ scores, hours worked and years of formal education are only given in whole numbers (integers)
#so we expect the median to also be either an integer or a number between 2 integers 
#Again, only column-wise statistics make sense here.
#Note: The median values are real values in the dataset, the mean values are synthetic (purely
#mathematical - sum all values, divide by number of values), as pointed out in the lecture.

#Mode
#Whereas it is possible to shoehorn numpy in computing the mode 
#(by first finding the unique values in an array, then counting their frequency, 
#then taking the max of that)
#So we could write a line of code with 3 nested functions that returns the value of the index 
#that correponds to the max of the unique counts
#I'll leave that as an exercise for the reader.
#It is sometimes easier to use pre-existing functions to do that. 
#Numpy doesn't have a dedicated "mode" function, but scipy does.
#Scipy is a library of scientific computing functions. We will use it extensively in this class.
#It includes an extensive "stats" module with many statistical functions, including the mode
#Good news: 
#Scipy works with/operates on numpy arrays as inputs. So we can preserve the speed of numpy.
#But we have to import it first, so we can use it
    
from scipy import stats #If you don't use Anaconda, you have to pip install scipy first. 
#Anaconda takes care of all of this plumbing for you
columnModes = stats.mode(data,axis=0) #Get the columnwise modes as an object out of scipy
modalValues = columnModes.mode #Get the actual modal values out of the object - 
#scipy often creates objects, that you have use their methods to get out what you need
#If you do this in the console, you can put a period (".") and then tab-complete to access the
#"methods" of the object.
#This will become more clear as we use more sophisticated scipy functions, like a regression model
#The whole model will be an object. It will have data. It will have predictions, it will have 
#residuals. It will have an accuracy, and so on. 
#Soon
print(modalValues[0]) #Print them to the console
print(modalValues[0][0]) #Print the first element of the array

#%% 3) Dispersion

# compute std across each column:
columnSD = np.std(data,axis=0) #Note: As I said in lecture, the notation for SD is "std", not sd.
#If there are missing data, use this 
columnSDNoNan = np.nanstd(data,axis=0) #Column-wise SDs, in the presence of missing data
#Of course, here we don't have missing data, so the output will be the same, but in the D1 assignment
#you will  need to use this function. In general, expect missing values. 

# compute std across each row:
rowSD = np.std(data,axis=1) #Again, row-wise is not really meaningful here, but this is how you do it
#if you wanted to

# compute std across entire array:
grandSD = np.std(data) #That's not meaninful either, but that's how you would do it.  

#As you noticed, this is incomplete. We didn't cover MAD - but that's on purpose. 
#That will come next time. And you will see then, why. 

#%% W1) EDA (Exploratory data analysis)
#EDA is not strictly necessary, but it is highly, highly recommended, befored doing anything else. 
#Processed data (and taking the mean is data processing) can hide many problems.
#You will want to be aware of these problems. The best way to become aware of them is by doing EDA
#EDA is very important. I usually spend much of my time when analyzing a dataset in EDA, and it is
#usually the first thing I do, before doing anything else. Data almost always has problems that you
#need to be aware of. 

#To do EDA, we import matplotlib - there are other libraries that will help, but this is a simple one
import matplotlib.pyplot as plt


#Before taking the statistics that characterize a dataset at face value, 
#I recommend to visualize the variables first.
#This is one form of EDA.

#One variable: A histogram is usually the way to go to visualize a distribution
numBins = 21 #Number of bins. This is arbitrary, but make sure it is an odd number so that there is
#a central bin, and somewhat related to amount of data you have
plt.hist(data[:,0],bins=numBins) # plot frequency distribution of outcomes in data as a histogram 
#with numBins bins. We expect a normal distribution for IQ (and perhaps others). 
#Check this in the "Plots" tab of the Spyder environment, between the "Help" and "Files" tab.
#The distribution of our first variable indeed seems to be normal. 
#Which makes me feel better about representing it with mean and standard deviation
#It also me feel better about the data itself, as it is supposed to represent IQ,
#and we know IQ is normally distributed. This lends confidence to the notion that the data 
#hasn't been corrupted or that there is sampling bias.


#%% W2) Simulation 1: Understanding the central tendency of a Cauchy distribution 
# by simulating Able Archer 83
# Note: This is not part of any assignment. 
# Only of interest if you want to understand the Cauchy distribution
# A blindfolded archer stands on a rotating platform
# The platform smoothly rotates from -90 degrees to +90 degrees
# The archer fires - in random intervals, but at a given firing rate - at a target
# straight ahead. 

# The target is placed on a screen that is 18 m (the international standard competition
# distance of target archery) away and infinitely wide (apparently, this is
# taking place on a flat earth too, so we can disregard the curvature of the
# earth). In fact, this seems to be taking place in space, as we would like
# to disregard the effects of gravity and friction from air as well (as you
# can see, the crux of simulations is that their results often rely on 
# many simplifying assumptions which might or might not reflect reality). 
# The figure of merit is the distance of where the arrow hits the screen
# relative to the target, in the horizontal direction. 

# For this to make sense, we also have to assume that the arrows are powered - they never not
# reach a target. Also, that there are infinitely many of them - the archer never runs out 
# of arrows. But bear with me. Yet - this is true for all simulations - we have to make 
# simplifying assumptions and represent everything else explicitly. 
# Here, this is ok because we simulate a mathematical principle. In the real world, this might be
# problematic, if we don't adequately implement something. 

#Now - like in every simulation, we have to represent what is going 
#(akin to the gears, or the Monty Hall situation)
targetDistance = 18 # Distance from target in m
numCycles = int(1e3) # How many cycles of platform rotation are we modeling? 
#We have to cast this as integers, as scientific notation will yield floats by default, and cycles
#have to be integers
firingRate = 1 # How often - per rotation cycle - does the archer fire? Once, here
granularity = 1e-3 # What granularity of platform rotations (in degrees) are we modeling? 
#How close to 90 degrees the platform can get. Apparently 89.999 degrees for now
startAngle = -90 + granularity #We actually exclude -90 exactly, 
#as the arrow would *never* hit the screen if it was strictly parallel
stopAngle = 90 - granularity #We can't do 90 degrees either, we have to stop short. 
#If we are fully parallel, then the distance will be infinite - it will never hit the screen 
numSteps = int((abs(startAngle) + stopAngle)/granularity + 1) #We are moving the platform 
#numSteps "clicks"
oneCycle = np.linspace(startAngle,stopAngle,numSteps) # spatial base representing one cycle
# Note - again we can't let it go all the way to -90 or 90, as the archer is then
# firing parallel to the screen, which means it would never hit it, the distance will be infinite

# Now: For each cycle:
# Determining when in the cycle the archer fires - note that we would
# ideally want to model firing intervals as a poisson distribution, as the
# *rate* is constant, and the events are rare. But that's not the primary point of this segment, 
# so for the sake of brevity, we just have the archer fires once per cycle.
# In principle, the archer could also fire multiple times a cycle.
# Which is more regular than one would get from Poisson. 
# Suggestion for exploration: Replace this part with a poisson distribution
totalShots = numCycles*firingRate # How many total shots at target?
whereInCycle = np.random.randint(0,numSteps,totalShots) # Where in the cycle do all shots happen?
conversionCycleTimingToDegrees = oneCycle[whereInCycle] # Use those as indices to the cycle
# Time in the cycle --> At what angle does the archer fire? 

# Now that we have the shot angles, we have to think a bit. Conjuring up
# our trig knowledge from middle school (who knew it would ever come in
# handy to help simulate blindfolded archers firing randomly in space?):
# You can either make a drawing or trust me that the distance from the
# target can be computed as distanceFromTarget = tan(shotAngle)*targetDistance
    
# Note: We have to convert radians to degrees first. Because degrees are
# arbitary (which mathematicians detest) and radians are not, as every
# circle has - by definition - a radius and a circumference.
# 1 radian = a radius length put along the circumference of the circle
# whereas degrees are arbitrary. 360 degrees is supposed to represent the days in a year
# according to Babylonian government mathematicians, thousands of years ago. We kept this because
# 360 has lots of factors. But radians is less arbitrary. 

shotAnglesInRadians = np.radians(conversionCycleTimingToDegrees) # Conversion from degrees to radians
distanceFromTarget = np.tan(shotAnglesInRadians)*targetDistance # These are all the distances
numBins = 10000 #Number of bins in the historgram
plt.hist(distanceFromTarget,numBins) # Plotting this
# Oh no. This looks like a cauchy distribution

#Note: These are *not* outliers. They are only outliers if you *assume* a normal distribution.
#Why would you assume a normal distribution? Here is what I hear a lot: 
#"Oh, I just assume a normal distribution, and then just delete all the outliers, lol"
#Don't do that. You might miss something really important. The "outliers" might mean something.
#If this is a cauchy distribution, it is not an outlier, from the perspective of a 
#cauchy distribution it is a totally valid part of the distribution.
#It is consistent with a cauchy distribution. 
#It is just an outlier if you assume a normal distribution.
#But why would you assume a normal distribution if you are dealing with a blindfolded archer 
#on a rotating platform? 
#In other words, sometimes - when the platform is close to parallel to the screen, 
#and there is a shot You get an extreme value. 
#Which will totally throw off mean and standard deviation.

#%%

# Are measures of central tendency and dispersion converging for this process? 
sumStats = np.empty([totalShots,3]) # initialize a 1000x3 empty container
sumStats[:] = np.NaN # Convert to NaN
for ii in range(totalShots):
    sumStats[ii,0] = ii + 1
    sumStats[ii,1] = np.mean(distanceFromTarget[:ii+1]) #Compute the mean
    sumStats[ii,2] = np.std(distanceFromTarget[:ii+1]) #and SD for increasing sample sizes 
    #from 1 to 1000
    
#If the distances from the target followed a normal distribution, the mean and standard deviation
#Should converge to the long term expected value, as we shoot more and more (we shoot 1k times here) 
#The question is: Does it?   

# Plotting that - note the wild jumps, not that they are subtle. 
# Looks like eye movement traces, tbh
# Suggestion for exploration: If you are unconvinced, increase the number of cycles,
# firing rate and/or reduce granularity (for more extreme outcomes)
# If you have really fine granularity, or 100k cycles, you can get some truly wild plots - it never
# converges on anything. But we don't have time for that here. 
# In any case, this is how we plot this
# First the mean in the left panel
plt.subplot(1,2,1)
plt.plot(sumStats[:,0],sumStats[:,1])
plt.title('Mean')
plt.xlabel('Integrating over n samples')
# Then the SD in the right panel
plt.subplot(1,2,2)
plt.plot(sumStats[:,0],sumStats[:,2])
plt.title('Standard Deviation')
plt.xlabel('Integrating over n samples')

# What are the summary statistics as a function of integrating over "n" samples?

# Take home: it doesn't converge and every new trial can change it considerably.

# Suggestion for exploration: Look up what "Able Archer 83" really is/was. 
# Then thank your lucky stars (or rather, Stanislav Petrov, that you're still here)
# The reason I called it that is because a extreme Cauchy event was prevented on that day - 
# global thermonuclear war. Briefly, it looked to the Russian early warning system as if the US
# was nuking them. That was a false positives, but it came down to one man - Stanislav Petrov - 
# to make that call. Otherwise, the Russians would have launched *their* nukes for real. 

# This will be more meaningful once we contrast this - which we will do when we talk about the
# law of large numbers - literally any other distribution of data *will* converge to a mean and SD
# as sample size increases, and in fact do so rather quickly. 

#%% W3) Simulation 2: The central tendency of a normal distribution by simulating a virtual pegboard

#The Virtual Pegboard - a Galton board for the 21st century
# Let's find out how normal distributions are made - and lost 

#Again, we need to represent everything that matters
balls = int(1e4) # How many balls do we have in play?
xBallOrigin = 0 #Where are the balls dropped from? 
#[e.g. from a hole that is located at x between -10 to 10. 0 represents the center]
pegs = int(1e2) # How many levels of pegs are on the pegboard? You will want more than 20
pegWidth = 0.1 # How wide is a peg? [This moves a ball by this width per peg row, left or right]
#This will determine the SD - how wide the distribution gets
probLeft = 0.5 # What is probability of going right in any given peg? (from 0 to 1) 
finalBallPositions = np.empty([balls,1]) # Initializing container to hold the ball positions
finalBallPositions[:] = np.NaN # Convert to NaN

for ii in range(balls): # Doing this for all the balls (with an outer loop)
#Determine where all the balls land. 
    ballPosition = xBallOrigin #Each ball starts at the source location
    #Now we have to go through all of the pegs
    for jj in range(pegs): # Do a check as to what happens to each ball at each peg 
    #(with an inner loop)
        temp = np.random.uniform(0,1,1) # Draw one random number from a uniform distribution 
        #between 0 and 1
        if temp > probLeft: # Switch: Should we move the ball left left?
            ballPosition = ballPosition + pegWidth # Move the ball to the right  
        else: # Otherwise, go left
            ballPosition = ballPosition - pegWidth # Move the ball to the left 
    finalBallPositions[ii] = ballPosition # Record the final position of each ball 
    #once that ball ran through all of the pegs
    
# Plot the distribution of ball positions:
numBins = 17
plt.hist(finalBallPositions,numBins)
    
# Suggestion for exploration 1: Try different values for number of balls 
# and number of pegs and see how that affects the resulting distribution.  
# What happens if the number of balls or pegs drops too low?

# Suggestion for exploration 2: Try different values for "probability left"
# - which parameter does this control? Shape of the distribution, or the
# location of its peak?

# Suggestion for exploration 3: What aspect of the shape of the distribution
# is affected by the peg width?   


#%% W4) Simulation 3: The virtual pegboard, now with the Matthew effect

#Matthew effect: In many empirical situations, there is a cumulative advantage - 
#it is easier/more likely to succeed more, if you have previously succeeded, 
#even if the previous success was solely due to luck

# Copy and pasting the code from above, but now building in  
# a cumulative advantage

balls = int(1e4) # How many balls do we have in play?
xBallOrigin = 0 #Where are the balls dropped from? 
pegs = int(1e2) # How many pegs are there?
pegWidth = 0.1 # How wide is a peg?
probLeft = 0.5 # What is the probability of going right in any given peg? (from 0 to 1) 
cumulativeEdge = 0.03 # New: How much does the edge accumulate per peg?
finalBallPositions = np.empty([balls,1]) # Initializing container for ball positions
finalBallPositions[:] = np.NaN # Convert to NaN

#Now: Same thing as above, but we now build in a cumulative advantage
for ii in range(balls): # Doing this for all the balls
    ballPosition = xBallOrigin #Each ball starts at the source
    cumAdv = 0 # Starting point of the cumulative advantage
    for jj in range(pegs): # Do a check at each peg
        temp = np.random.uniform(0,1,1) # Draw one random number from a uniform distribution between 0 and 1
        if temp + cumAdv > probLeft: # Should we not go left?
            ballPosition = ballPosition + pegWidth # Move the ball to the right
            #What happens if we went right?
            cumAdv = cumAdv + cumulativeEdge # We just gained some cumulative advantage
            #by going to the right. In real life, this might be the benefits of some
            #success. Like winning a competition where there was some degree of chance
            #Winning that will give you resources. These resources might make it more
            #likely you win the next event. And so on.
        else:
            ballPosition = ballPosition - pegWidth # Move the ball to the left 
            #But what happens if you randomly ended up on the wrong side of the peg?
            cumAdv = cumAdv - cumulativeEdge # We just lost some cumulative advantage
            #by going to the left. Say you lost a competition where there was some
            #chance. You might be sad. Maybe demotivated. Which makes it less likely
            #that you win the next one.
    finalBallPositions[ii] = ballPosition # Record the final position of the ball 

# Plot the distribution of ball positions:
numBins = 15
plt.hist(finalBallPositions,numBins)

# Suggestion for exploration: Experiment with different strengths of the
# cumulative advantage. What distributions emerge?   
# Life lesson: If you want to be lucky, make sure you are lucky early. 
# It matters more early on, as succes compounds.   

#%% W5) Simulation 4: Ergodicity (or the lack thereof) and the risk of ruin

# Here, we will explore the statistical basis of virtue. 
# Virtue (actual virtue, not declared virtue) is very important
# Here, we will show statistically as to why.
# Many real life processes are not ergodic. However, short term incentives only
# might lead organisms to adopt strategies that are not adaptive in
# the long run. In other words, not even in their best interest. 

# This could model all kinds of behaviors. Lying, cheating, stealing, 
# taking excessive risks in general that could lead to physical injury or 
# financial ruin, ruin of reputation, criminal charges, etc.
# Do not do this, here is why:

# Setup:
payoffWithoutRecklessAction = 50 # Expected payoff per attempt without being reckless
payoffWithRecklessAction = 100 # Expected payoff per attempt with being reckless (e.g. cheating)
#Cheating in chess. Cheating in class. Cheating in relationship. Cheating cheaters. 
#The cheaters are looking for an edge. Yes? And it looks like they got it. 
attempts = 200 # How many times is the action performed (e.g. cheating)
    
# Expected values with ergodicity (no risk of ruin):
expectedValueVirtue = attempts * payoffWithoutRecklessAction # In utility points
expectedValueReckless = attempts * payoffWithRecklessAction # This could be anything. 
#Pleasure, money, fame, etc.

#Looks like being reckless pays - in ergodic systems
#Is the expected value of being reckless larger than that of being virtuous?
print(expectedValueReckless > expectedValueVirtue) # Oh no

#So if the system is ergodic, "crime pays", the reckless action outperforms the virtuous action
#This is probably what the cheater has in mind when they tell me that they were just looking for
#an edge. 
#However, what if the system is not ergodic? 
#This is why it is so important to catch and punish cheaters

#%% Non-ergodicity

# But - and this is an important but - most real life systems are not
# ergodic. Meaning: You can get caught. Getting caught doesn't only lead -
# usually - to punishment (being shamed, imprisoned, etc.), but also
# nullifies the ability to keep on playing. For instance, being seriously injured
# midway during an attempt to win a competition prevents the player from
# competing further. We are also not considering the damage reckless behavior
# inflicts on others here. So the real life outcomes are actually even considerably worse.
# Here, fornow we only consider the direct expected outcomes when continuing to play the game
# (whatever the game is). Note that in real life, "ruin" could also nullify
# enjoyment of prior gains (e.g. in cases where ruin = death). 


#%% Let's simulate this:
    
riskOfRuin = 0.05 # How likely is one to get caught performing the reckless action 
#(e.g. cheating, or have the averse outcome (e.g. an accident)) per attempt?
#For now, 1 in 20
runs = 1000 # How often are we running the simulation

# Note that we have to only simulate the reckless behavior, as the virtuous
# organism just gets the expected value (no risk of ruin). 
# Which we already calculated above

sata = np.empty([runs,attempts]) # Setup sata matrix
sata[:] = np.NaN # Convert to NaN

for ii in range(runs): # iterate over each run - with an outer loop
    ruinedYet = 0 # Have I been ruined yet? This needs to be initialized here, at the outer loop, 
    #before the inner one
    for jj in range(attempts): # iterate over each attempt
        ruinedThisAttempt = np.random.uniform(0,1,1) # Drawing a number from a uniform distribution
        #between 0 and 1. Doesn't have to be uniform, btw
        if ruinedThisAttempt < riskOfRuin: # If this number is smaller than the cutoff, 
        #we were ruined (e.g. caught) in this attempt
            ruinedYet = 1 # Now we have been ruined
        if ruinedYet == 1: # If we are ruined
            sata[ii,jj] = 0 # Payoff this attempt - we can no longer play if we are ruined. 
            # Trust is hard to regain once lost. We might not get the chance. 
            # If you lie to someone and they catch you, they might never trust you again.
            # They might not even talk to you.
            # Note that in real life, this value could be negative, if there are punishments. 
        else: #If we don't get caught, we don't get ruined, we just get the payoff with 
        #the cheating edge
            sata[ii,jj] = payoffWithRecklessAction # We can get the - usually higher - payoff of being reckless 
            
#%% Plotting the expected outcomes of being reckless

plt.plot(np.mean(sata,axis=0),color='red',linewidth=1)
plt.plot([1,attempts],[payoffWithoutRecklessAction,payoffWithoutRecklessAction],color='blue',linewidth=0.5)
plt.xlabel('Attempts')
plt.ylabel('Expected payout per attempt')
plt.legend(['Reckless','Ethical'])
# The area under the curve is the expected long-term outcome 
# of either strategy (ethical vs. reckless)      
            
# Which strategy is superior now?
actualExpectedValueReckless = sum(np.mean(sata,axis=0)) # Expected value of being reckless under non-ergodic conditions        
print(expectedValueVirtue > actualExpectedValueReckless) # Now, being reckless underperforms 

# *Enlightened* self-interest: Understanding that ethical values can protect
# your *own* long-term self-interests (being led down the primrose path by
# your (intrinsic or extrinsic) reward system). 

# Suggestion for exploration: Play around with different value of risk of
# ruin to titrate risk. The reckless strategy *can* make sense if there are
# only *very* few attempts, under special situations.
# There are historical examples where this could makes sense. 
# If you are interested, read up on - for instance - the "Fornlorn Hope".
# Or on Doppelsöldner.
# Briefly: In 1600s to 1800s European warfare, opposing armies would line up (literally) on opposing
# sides and fire on each other with muskets or rifles. The probability of being hit and dying is a
# function of in which line you are (first line vs. later echelons). Obviously, the probability of 
# dying is highest in the first line. So how do you get people to go in the first line? The answer?
# You do exactly this. You incentivize that ("doppelsöldner" literally means double pay), the idea 
# is that you are set for life (surviving members of the forlorn hope were promoted) if you make it.
# As far as I know, they were never short of volunteers for these positions. Which makes sense if
# you do this only a few times (or only once). If you keep doing it, you will probably die. 
# Historically. If you take huge risks, make sure to do so only very rarely, if at all. 
# Long term, you will incur the risk of ruin. 
# This is the statistical basis of virtue. Don't do any of this, so you don't have to worry about
# this calculus at all. It protects you from short term incentives that are not even in your own
# best interest, even if it looks like you're getting an edge. 

